import http from 'node:http';
import { encryptConfig, decryptConfig, configFromVault, selectSites, applyConfig, transferLimit } from './transfer.mjs';
import { BlueParser } from './blue-stream.mjs';
import { ClipExports } from './clip-export.mjs';
import { createReadStream } from 'node:fs';
import { networkInterfaces } from 'node:os';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { BlueIrisClient, CameraError, cleanProfile, publicError, JpegParser } from './blueiris.mjs';
import { receiveRecovering, StreamInterrupted } from './recovery.mjs';
import { RequestQueue } from '../src/request-queue.js';

const MAX_LIVE = 9;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const equal = (a, b) => typeof a === 'string' && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
const body = async (req, limit = 32768) => {
  let data = '';
  for await (const chunk of req) { data += chunk; if (Buffer.byteLength(data) > limit) throw new CameraError('Request is too large.'); }
  try { return JSON.parse(data); } catch { throw new CameraError('Invalid request.'); }
};

export function createGateway({ vault, clientFactory = profile => new BlueIrisClient(profile), dist = fileURLToPath(new URL('../dist', import.meta.url)), exportRoot=fileURLToPath(new URL('../.local/exports',import.meta.url)), exportOptions={} }) {
  const exports=new ClipExports(exportRoot,exportOptions);
  const session = randomBytes(32).toString('hex');
  const previewRequests = new RequestQueue(3);
  const clients = new Map(), views = new Map(), refreshing = new Map(), snapshots = new Map(), streams = new Map(), playbacks = new Set();
  let shuttingDown = false;
  let networkSignature = '';
  const client = site => {
    const signature=JSON.stringify(networkInterfaces());
    if(signature!==networkSignature){networkSignature=signature;for(const connection of clients.values())connection.networkChanged?.(true)}
    if (!clients.has(site.id)) clients.set(site.id, clientFactory(site));
    return clients.get(site.id);
  };
  const refresh = site => {
    if (refreshing.has(site.id)) return refreshing.get(site.id);
    const task = (async () => {
      const previous = views.get(site.id);
      views.set(site.id, { ...previous, status: previous?.status || 'connecting', cameras: previous?.cameras || [] });
      try {
        const cameras = await client(site).cameras();
        if (vault.state.sites.some(item => item.id === site.id)) views.set(site.id, { cameras, status: 'online', checkedAt: Date.now() });
      } catch (error) {
        if (vault.state.sites.some(item => item.id === site.id)) views.set(site.id, { ...previous, cameras: previous?.cameras || [], status: 'offline', error: publicError(error), checkedAt: Date.now() });
      }
    })().finally(() => refreshing.delete(site.id));
    refreshing.set(site.id, task);
    return task;
  };
  const snapshotState = () => ({
    sites: vault.state.sites.map(({ password, ...site }) => ({ ...site, connectionLabel:clients.get(site.id)?.connectionLabel || 'Auto', ...(views.get(site.id) || { status: 'connecting', cameras: [] }) })),
    groups: vault.state.groups || [],
    layouts: vault.state.layouts.map(layout => ({ ...layout, rows: layout.rows || Math.min(6, Math.max(1, Math.ceil(layout.cameras.length / layout.columns))) })),
    gateway: { online: true, private: true, maxLive: MAX_LIVE, activeStreams: streams.size + playbacks.size, version: '0.7.0', storage: 'Windows account encryption' }
  });
  const locate = key => {
    for (const site of vault.state.sites) {
      const camera = views.get(site.id)?.cameras.find(camera => camera.key === key);
      if (camera) return { site, camera };
    }
    return null;
  };
  const allowed = req => {
    const port = server.address()?.port;
    const hosts = [`127.0.0.1:${port}`, `localhost:${port}`];
    return hosts.includes(req.headers.host) && (!req.headers.origin || hosts.some(host => req.headers.origin === `http://${host}`));
  };
  const authenticated = req => {
    const cookie = req.headers.cookie?.split(';').map(value => value.trim()).find(value => value.startsWith('darkstar_session='))?.slice('darkstar_session='.length);
    return equal(cookie, session);
  };
  const respond = (res, status, value) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(value));
  };
  const stopStream = key => { const stream = streams.get(key); if (stream) { streams.delete(key); stream.abort.abort(); } };
  const detach = (ws, key) => { const stream = streams.get(key); if (stream) { stream.watchers.delete(ws); if (!stream.watchers.size) stopStream(key); } };
  const sendFrame = (watchers, metadata, frame) => {
    const encoded = Buffer.from(JSON.stringify(metadata)), header = Buffer.alloc(2); header.writeUInt16BE(encoded.length);
    const payload = Buffer.concat([header, encoded, frame]);
    for (const watcher of watchers) if (watcher.readyState === WebSocket.OPEN && watcher.bufferedAmount < 2 * 1024 * 1024) watcher.send(payload, { binary: true });
  };
  const attach = (ws, key) => {
    let entry = streams.get(key);
    if (entry) { entry.watchers.add(ws); return; }
    const found = locate(key);
    if (!found || !found.camera.enabled || streams.size >= 24) return;
    entry = { watchers: new Set([ws]), abort: new AbortController(), lastFrame: Date.now() };
    streams.set(key, entry);
    const thisEntry = entry;
    void (async () => {
      try {
        await receiveRecovering({ signal: thisEntry.abort.signal, open: (position, signal) => client(found.site).media(found.camera.id, true, signal), onFrame: frame => sendFrame(thisEntry.watchers, { key, mode: 'live' }, frame), onRetry: attempt => { for (const watcher of thisEntry.watchers) if (watcher.readyState === WebSocket.OPEN) watcher.send(JSON.stringify({ type: 'stream-status', key, status: 'recovering', attempt })); } });
      } catch (error) {
        if (streams.get(key) === thisEntry && !shuttingDown) for (const watcher of thisEntry.watchers) if (watcher.readyState === WebSocket.OPEN) watcher.send(JSON.stringify({ type: 'stream-error', key, message: error instanceof StreamInterrupted && error.hadFrames ? 'The live connection was interrupted. Reconnect to resume.' : publicError(error.cause || error) }));
      } finally {
        thisEntry.abort.abort();
        if (streams.get(key) === thisEntry) streams.delete(key);
      }
    })();
  };

  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Darkstar-Gateway', '0.7.0');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    const port = server.address()?.port;
    res.setHeader('Content-Security-Policy', `default-src 'self'; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'; connect-src 'self' ws://127.0.0.1:${port} ws://localhost:${port}; frame-ancestors 'none'; base-uri 'none'; form-action 'self'`);
    if (!allowed(req)) return respond(res, 403, { error: 'This gateway only accepts its own local workspace.' });
    let path, requestUrl;
    try { requestUrl = new URL(req.url, `http://${req.headers.host}`); path = decodeURIComponent(requestUrl.pathname); } catch { return respond(res, 400, { error: 'Invalid address.' }); }
    if (path.startsWith('/api/')) {
      if (!authenticated(req)) return respond(res, 401, { error: 'Open the Darkstar workspace to start a session.' });
      if (!['GET', 'HEAD'].includes(req.method) && req.headers.origin !== `http://${req.headers.host}`) return respond(res, 403, { error: 'This change must come from the local workspace.' });
      try {
        if (req.method === 'GET' && path === '/api/state') {
          for (const site of vault.state.sites) if (!views.has(site.id) || Date.now() - (views.get(site.id).checkedAt || 0) > 30000) void refresh(site);
          return respond(res, 200, snapshotState());
        }
        if (req.method === 'POST' && path === '/api/transfer/export') {
          const input = await body(req);
          const config=configFromVault(vault.state,input.preferences);
          return respond(res, 200, await encryptConfig(input.siteIds===undefined?config:selectSites(config,input.siteIds), input.passphrase));
        }
        if(req.method==='POST'&&path==='/api/ptz') {
          const input=await body(req),found=locate(input.key);
          if(!found?.camera.ptz)throw new CameraError('This camera does not advertise PTZ controls.');
          await client(found.site).ptz(found.camera.id,input.button);return respond(res,200,{status:'sent'});
        }
        if(req.method==='POST'&&path==='/api/exports') {
          const input=await body(req),found=locate(input.key);
          if(!found)throw new CameraError('Camera is unavailable.');
          return respond(res,202,exports.start(client(found.site),found.camera,input,(start,end)=>client(found.site).recordings(found.camera.id,start,end)));
        }
        const exportMatch=/^\/api\/exports\/([a-f0-9-]{36})(\/file)?$/.exec(path);
        if(exportMatch) {
          const job=exports.get(exportMatch[1]);if(!job)return respond(res,404,{error:'Export is unavailable. Prepare it again.'});
          if(req.method==='DELETE'){exports.cancel(job.id);return respond(res,200,{status:'cancelled'})}
          if(req.method==='GET'&&!exportMatch[2])return respond(res,200,exports.view(job));
          if(req.method==='GET'&&exportMatch[2]) {
            if(job.status!=='ready')throw new CameraError('This export is not ready.');
            res.writeHead(200,{'Content-Type':'video/mp4','Content-Disposition':'attachment; filename="Darkstar-Export.mp4"','Content-Length':job.size,'Cache-Control':'no-store'});
            const file=createReadStream(job.file);file.on('error',()=>res.destroy());res.on('close',()=>file.destroy());file.pipe(res);return;
          }
        }
        if (req.method === 'POST' && (path === '/api/transfer/review' || path === '/api/transfer/import')) {
          const input = await body(req, transferLimit + 4096);
          const config = await decryptConfig(input.envelope, input.passphrase);
          if (path.endsWith('/review')) return respond(res, 200, { sites: config.sites.map(({ id, name, color }) => ({ id, name, color })), views: config.settings.views.length });
          if (!['merge', 'replace'].includes(input.mode)) throw new CameraError('Choose merge or replace before importing.');
          await Promise.allSettled([...refreshing.values()]);
          await vault.update(state => applyConfig(state, config, input.mode === 'replace'));
          for (const [key] of streams) stopStream(key);
          for (const ws of wss.clients) stopPlayback(ws);
          for (const entry of snapshots.values()) entry.abort.abort();
          snapshots.clear(); views.clear(); refreshing.clear();
          const old = [...clients.values()]; clients.clear();
          for (const connection of old) void connection.logout().catch(() => {});
          return respond(res, 200, { ...snapshotState(), restoredPreferences: vault.state.transferPreferences });
        }
        if (req.method === 'POST' && path === '/api/refresh') {
          await Promise.all(vault.state.sites.map(refresh));
          return respond(res, 200, snapshotState());
        }
        if (req.method === 'POST' && path === '/api/sites/test') {
          const input = await body(req);
          const candidate = cleanProfile(input, vault.state.sites.find(site => site.id === input.id));
          candidate.id ||= randomUUID();
          const tester = clientFactory(candidate);
          try { const cameras = await tester.cameras(); return respond(res, 200, { count: cameras.length, message: `Connected · ${cameras.length} cameras found` }); }
          finally { void tester.logout().catch(() => {}); }
        }
        if (req.method === 'POST' && path === '/api/sites') {
          const input = await body(req);
          const previous = vault.state.sites.find(site => site.id === input.id);
          if (input.id && !previous) throw new CameraError('This site no longer exists.');
          if (!previous && vault.state.sites.length >= 24) throw new CameraError('This workspace supports up to 24 sites.');
          const profile = cleanProfile(input, previous); profile.id ||= randomUUID();
          await vault.update(state => { state.sites = state.sites.some(site => site.id === profile.id) ? state.sites.map(site => site.id === profile.id ? profile : site) : [...state.sites, profile]; });
          for (const [key] of streams) if (key.startsWith(`${profile.id}:`)) stopStream(key);
          if (refreshing.has(profile.id)) await refreshing.get(profile.id);
          clients.delete(profile.id);
          await refresh(profile);
          return respond(res, 200, snapshotState());
        }
        const siteMatch = /^\/api\/sites\/([a-z0-9-]+)$/.exec(path);
        if (siteMatch && req.method === 'DELETE') {
          const id = siteMatch[1];
          await vault.update(state => { state.sites = state.sites.filter(site => site.id !== id); [...state.layouts,...(state.groups||[])].forEach(layout => { layout.cameras = layout.cameras.filter(key => !key.startsWith(`${id}:`)); }); });
          for (const [key] of streams) if (key.startsWith(`${id}:`)) stopStream(key);
          const old = clients.get(id); clients.delete(id); views.delete(id);
          if (old) void old.logout().catch(() => {});
          return respond(res, 200, snapshotState());
        }
        if (req.method === 'POST' && path === '/api/groups') {
          const input=await body(req),name=String(input.name||'').trim();
          if(!name||name.length>80)throw new CameraError('Give this group a name, up to 80 characters.');
          if(input.id&&!(vault.state.groups||[]).some(g=>g.id===input.id))throw new CameraError('This group no longer exists.');
          const cameras=[...new Set(Array.isArray(input.cameras)?input.cameras:[])];
          if(!cameras.length||cameras.length>1000||cameras.some(key=>typeof key!=='string'||!locate(key)))throw new CameraError('Choose between 1 and 1000 available cameras.');
          const group={id:input.id||randomUUID(),name,cameras,updatedAt:Date.now()};
          await vault.update(state=>{state.groups=state.groups||[];if(!input.id&&state.groups.length>=100)throw new CameraError('This workspace supports up to 100 groups.');state.groups=[...state.groups.filter(g=>g.id!==group.id),group];});
          return respond(res,200,{...snapshotState(),savedId:group.id});
        }
        const groupMatch=/^\/api\/groups\/([a-z0-9-]+)$/.exec(path);
        if(req.method==='DELETE'&&groupMatch){await vault.update(state=>{state.groups=(state.groups||[]).filter(g=>g.id!==groupMatch[1]);});return respond(res,200,snapshotState());}
        if (req.method === 'POST' && path === '/api/layouts') {
          const input = await body(req);
          const name = String(input.name || '').trim();
          if (!name || name.length > 80) throw new CameraError('Give this view a name, up to 80 characters.');
          if (input.id && !vault.state.layouts.some(layout => layout.id === input.id)) throw new CameraError('This saved view no longer exists.');
          const cameras = [...new Set(Array.isArray(input.cameras) ? input.cameras : [])];
          if (!cameras.length || cameras.length > 1000 || cameras.some(key => typeof key !== 'string' || !locate(key))) throw new CameraError('Choose between 1 and 1000 available cameras.');
          const columns = Number.isInteger(input.columns) && input.columns >= 1 && input.columns <= 12 ? input.columns : 2;
          const layout = { id: input.id || randomUUID(), name, cameras, columns, rows: Number.isInteger(input.rows) && input.rows >= 1 && input.rows <= 12 ? input.rows : Math.min(6, Math.ceil(cameras.length / columns)), updatedAt: Date.now() };
          await vault.update(state => { if (!input.id && state.layouts.length >= 50) throw new CameraError('This workspace supports up to 50 saved views.'); state.layouts = [...state.layouts.filter(view => view.id !== layout.id), layout]; });
          return respond(res, 200, { ...snapshotState(), savedId: layout.id });
        }
        const layoutMatch = /^\/api\/layouts\/([a-z0-9-]+)$/.exec(path);
        if (req.method === 'DELETE' && layoutMatch) {
          await vault.update(state => { state.layouts = state.layouts.filter(layout => layout.id !== layoutMatch[1]); });
          return respond(res, 200, snapshotState());
        }
        const recordingsMatch = /^\/api\/sites\/([a-z0-9-]+)\/cameras\/(.+)\/recordings$/.exec(path);
        if (req.method === 'GET' && recordingsMatch) {
          const found = locate(`${recordingsMatch[1]}:${recordingsMatch[2]}`);
          if (!found) return respond(res, 404, { error: 'Camera is unavailable.' });
          const start = Number(requestUrl.searchParams.get('start')), end = Number(requestUrl.searchParams.get('end'));
          if (!Number.isFinite(start) || !Number.isFinite(end) || start < 946684800000 || end <= start || end - start > 26 * 3600000 || end > Date.now() + 172800000) throw new CameraError('Choose a valid recording day.');
          return respond(res, 200, await client(found.site).recordings(found.camera.id, start, end));
        }
        const frameMatch = /^\/api\/sites\/([a-z0-9-]+)\/cameras\/(.+)\/frame$/.exec(path);
        if (req.method === 'GET' && frameMatch) {
          const found = locate(`${frameMatch[1]}:${frameMatch[2]}`), position = Number(requestUrl.searchParams.get('position'));
          if (!found) return respond(res, 404, { error: 'Camera is unavailable.' });
          if (!Number.isFinite(position) || position < 946684800000 || position > Date.now() + 172800000) throw new CameraError('Choose a valid recording time.');
          const abort = new AbortController(); res.on('close', () => abort.abort());
          const image = await client(found.site).recordedFrame(found.camera.id, position, abort.signal);
          if (!res.destroyed) { res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'no-store' }); res.end(image); }
          return;
        }
        const imageMatch = /^\/api\/sites\/([a-z0-9-]+)\/cameras\/(.+)\/image$/.exec(path);
        if (req.method === 'GET' && imageMatch) {
          const key = `${imageMatch[1]}:${imageMatch[2]}`;
          const found = locate(key);
          if (!found || !found.camera.enabled) return respond(res, 404, { error: 'Camera is unavailable.' });
          let cached = snapshots.get(key);
          if (!cached || Date.now() - cached.at > 4500) {
            cached = { at: Date.now(), watchers:new Set(), abort:new AbortController(), done:false };
            const entry=cached;
            cached.value=previewRequests.run(()=>client(found.site).snapshot(found.camera.id,entry.abort.signal),entry.abort.signal).then(image=>{entry.done=true;return image},error=>{entry.done=true;if(snapshots.get(key)===entry)snapshots.delete(key);throw error});
            snapshots.set(key, cached);
            if (snapshots.size > 128) snapshots.delete(snapshots.keys().next().value);
            cached.value.catch(() => { if (snapshots.get(key) === cached) snapshots.delete(key); });
          }
          const watcher={};cached.watchers.add(watcher);
          const release=()=>{cached.watchers.delete(watcher);if(!cached.done&&!cached.watchers.size){cached.abort.abort();if(snapshots.get(key)===cached)snapshots.delete(key)}};
          res.once('close',release);
          try { const image = await cached.value; if (!res.destroyed) { res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'no-store' }); res.end(image); } }
          finally { res.off('close',release);release(); }
          return;
        }
        if (req.method === 'GET' && path === '/api/health') return respond(res, 200, { status: 'ready', activeStreams: streams.size + playbacks.size, maxLive: MAX_LIVE });
        if (req.method === 'POST' && path === '/api/shutdown') { respond(res, 200, { status: 'stopping' }); setTimeout(() => server.emit('darkstar-stop'), 30); return; }
        return respond(res, 404, { error: 'Not found.' });
      } catch (error) { if (!res.headersSent) respond(res, error instanceof CameraError ? 400 : 502, { error: publicError(error) }); return; }
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return respond(res, 405, { error: 'Method not allowed.' });
    if (path === '/') res.setHeader('Set-Cookie', `darkstar_session=${session}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200`);
    let file = resolve(dist, path === '/' ? 'index.html' : `.${path}`);
    if (!file.startsWith(resolve(dist) + sep)) return respond(res, 404, { error: 'Not found.' });
    try {
      if (!(await stat(file)).isFile()) throw new Error();
      const content = await readFile(file);
      res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream', 'Cache-Control': path.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-store' });
      res.end(req.method === 'HEAD' ? undefined : content);
    } catch { respond(res, 404, { error: 'Workspace file not found. Build the app before starting the gateway.' }); }
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: 16384 });
  const stopPlayback = ws => { if (ws.playback) { playbacks.delete(ws.playback); ws.playback.abort.abort(); ws.playback = null; } };
  const startPlayback = (ws, message) => {
    stopPlayback(ws);
    for (const key of ws.keys) detach(ws, key); ws.keys.clear();
    const found = locate(message.key), position = Number(message.position), speed = Number(message.speed);
    if (!found || !Number.isFinite(position) || position < 946684800000 || position > Date.now() + 172800000 || ![50,100,200,400].includes(speed) || typeof message.requestId !== 'string' || message.requestId.length > 100 || streams.size + playbacks.size >= 24) {
      ws.send(JSON.stringify({ type: 'stream-error', key: message.key, requestId: message.requestId, message: 'The playback request is unavailable or invalid.' })); return;
    }
    const entry = { abort: new AbortController(), key: message.key };
    ws.playback = entry; playbacks.add(entry);
    void (async () => {
      try {
        await receiveRecovering({ position, speed, signal: entry.abort.signal, open: (cursor, signal) => client(found.site).media(found.camera.id, true, signal, { position: cursor, speed }), onFrame: (frame, cursor) => sendFrame([ws], { key: message.key, mode: 'playback', requestId: message.requestId, position: cursor }, frame), onRetry: (attempt, cursor) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'stream-status', key: message.key, requestId: message.requestId, status: 'recovering', attempt, position: cursor })); } });
      } catch (error) {
        if (!entry.abort.signal.aborted && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'stream-error', key: message.key, requestId: message.requestId, position: error.position ?? position, hadFrames: error.hadFrames || false, message: error.hadFrames ? 'The recording stream was interrupted. Resume from here or choose another time.' : publicError(error.cause || error) }));
      } finally { entry.abort.abort(); playbacks.delete(entry); if (ws.playback === entry) ws.playback = null; }
    })();
  };
  const startAv=(ws,message)=>{
    stopPlayback(ws);for(const key of ws.keys)detach(ws,key);ws.keys.clear();
    const found=locate(message.key),position=message.mode==='playback'?Number(message.position):null,speed=message.mode==='playback'?Number(message.speed):100;
    if(!found||!['live','playback'].includes(message.mode)||![50,100,200,400].includes(speed)||(position!==null&&(!Number.isFinite(position)||position<946684800000||position>Date.now()+172800000))||typeof message.requestId!=='string'||message.requestId.length>100||streams.size+playbacks.size>=24){ws.send(JSON.stringify({type:'stream-error',key:message.key,requestId:message.requestId,message:'Invalid audio/video request.'}));return}
    const entry={abort:new AbortController(),key:message.key};ws.playback=entry;playbacks.add(entry);
    void(async()=>{
      try {
        const response=await client(found.site).avMedia(found.camera.id,entry.abort.signal,position,speed);
        const parser=new BlueParser((metadata,bytes)=>{
          if(ws.bufferedAmount>2*1024*1024)throw new CameraError('Audio/video connection fell behind. Reconnect to resume.');
          sendFrame([ws],{...metadata,key:message.key,mode:message.mode,requestId:message.requestId,av:true},bytes);
        },speed);
        for await(const chunk of response.body){entry.abort.signal.throwIfAborted();parser.push(chunk);if(parser.ended)break}
        if(ws.readyState===WebSocket.OPEN&&!entry.abort.signal.aborted)ws.send(JSON.stringify({type:'stream-ended',key:message.key,requestId:message.requestId}));
      }catch(error){if(!entry.abort.signal.aborted&&ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:'stream-error',key:message.key,requestId:message.requestId,message:publicError(error)}))}
      finally{entry.abort.abort();playbacks.delete(entry);if(ws.playback===entry)ws.playback=null}
    })();
  };
  server.on('upgrade', (req, socket, head) => {
    if (req.url !== '/live' || !allowed(req) || !authenticated(req) || req.headers.origin !== `http://${req.headers.host}`) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
  });
  wss.on('connection', ws => {
    ws.keys = new Set(); ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('message', (data, binary) => {
      if (binary) return;
      try {
        const message = JSON.parse(data.toString());
        if (message.type === 'playback-stop') { stopPlayback(ws); return; }
        if (message.type === 'playback') { startPlayback(ws, message); return; }
        if (message.type === 'av') { startAv(ws,message); return; }
        if (message.type !== 'subscribe' || !Array.isArray(message.keys)) return;
        stopPlayback(ws);
        const keys = new Set(message.keys.filter(key => typeof key === 'string' && locate(key)).slice(0, MAX_LIVE));
        for (const key of ws.keys) if (!keys.has(key)) detach(ws, key);
        for (const key of keys) attach(ws, key);
        ws.keys = keys;
      } catch { ws.close(1008, 'Invalid message'); }
    });
    ws.on('close', () => { for (const key of ws.keys) detach(ws, key); stopPlayback(ws); });
    ws.on('error', () => {});
  });
  const heartbeat = setInterval(() => { for (const ws of wss.clients) { if (!ws.isAlive) ws.terminate(); else { ws.isAlive = false; ws.ping(); } } }, 20000);
  heartbeat.unref();
  return {
    server, snapshotState,
    async listen(port = 47831) { await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve); }); return `http://127.0.0.1:${server.address().port}`; },
    async close() { shuttingDown = true; clearInterval(heartbeat); for (const [key] of streams) stopStream(key); for (const ws of wss.clients) { stopPlayback(ws); ws.terminate(); } await exports.close(); await new Promise(resolve => wss.close(resolve)); const closing=new Promise(resolve=>server.close(resolve));server.closeAllConnections();await closing; }
  };
}


