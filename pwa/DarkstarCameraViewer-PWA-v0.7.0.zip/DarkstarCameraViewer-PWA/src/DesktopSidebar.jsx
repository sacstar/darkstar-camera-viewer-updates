import React from 'react';
import {Video,Grid2X2,CirclePlay,Server,Plus,PanelsTopLeft,Pencil,ShieldCheck,Folder} from 'lucide-react';

export function DesktopSidebar({tab,onTab,sites,views,activeId,onView,onNewView,onEditView,onSite,groups=[],groupFilter,onGroup,onGroups}) {
  return <aside className="desktop-sidebar" aria-label="Workspace sidebar">
    <div className="desktop-brand"><img src="/brand.png" alt="Darkstar Technical" style={{width:48,height:48,objectFit:"contain",background:"#101c2b",borderRadius:8}}/><div><strong>DARKSTAR</strong><span>CAMERA WORKSPACE</span></div></div>
    <nav aria-label="Desktop navigation">{[['cameras','Cameras',Grid2X2],['recordings','Recordings',CirclePlay],['sites','Sites',Server]].map(([id,label,Icon])=><button key={id} className={tab===id?'selected':''} aria-current={tab===id?'page':undefined} onClick={()=>onTab(id)}><Icon size={19}/><span>{label}</span>{id==='sites'&&<small>{sites.length}</small>}</button>)}</nav>
    <div className="desktop-sidebar-section"><div className="desktop-section-heading"><h2>Saved views</h2><button aria-label="Create saved view" title="Create saved view" onClick={onNewView}><Plus size={16}/></button></div>
      <button className={`desktop-view ${!activeId?'selected':''}`} aria-pressed={!activeId} onClick={()=>onView(null)}><Grid2X2 size={16}/><span>All cameras</span></button>
      <div className="desktop-view-list">{views.map(view=><div className={`desktop-view-row ${activeId===view.id?'selected':''}`} key={view.id}><button className="desktop-view" aria-label={`Open saved view ${view.name}`} aria-pressed={activeId===view.id} onClick={()=>onView(view.id)}><PanelsTopLeft size={16}/><span>{view.name}</span><small>{view.cameras.length}</small></button><button className="desktop-edit" aria-label={`Edit saved view ${view.name}`} title={`Edit ${view.name}`} onClick={()=>onEditView(view)}><Pencil size={13}/></button></div>)}</div>
    </div>
    <div className="desktop-sidebar-section desktop-groups"><div className="desktop-section-heading"><h2>Camera groups</h2><button aria-label="Manage camera groups" onClick={onGroups}><Plus size={16}/></button></div><button className={groupFilter==='all'?'selected':''} onClick={()=>onGroup('all')}><Folder size={14}/>All groups</button>{groups.map(g=><button key={g.id} className={groupFilter===g.id?'selected':''} onClick={()=>onGroup(g.id)}><Folder size={14}/><span>{g.name}</span><small>{g.cameras.length}</small></button>)}</div>
    <div className="desktop-sidebar-section desktop-sites"><div className="desktop-section-heading"><h2>Sites</h2></div>{sites.map(site=><button key={site.id} onClick={()=>onSite(site)} aria-label={`Filter cameras to ${site.name}`}><i className={site.status==='online'?'online':''}/><span>{site.name}</span><small>{site.cameras.length}</small></button>)}</div>
    <div className="desktop-sidebar-footer"><ShieldCheck size={15}/><span>Private workspace<small>{sites.filter(site=>site.status==='online').length} of {sites.length} sites connected</small></span></div>
  </aside>;
}

