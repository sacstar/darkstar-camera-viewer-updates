import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Video, RefreshCw, Plus, Search, Settings2, ChevronLeft, ChevronRight, Grid2X2, CirclePlay, Server, Download, Pause, Play, Maximize, WifiOff, LoaderCircle, ShieldCheck, Pencil, Trash2, X, ChevronDown } from 'lucide-react';
import { api } from './api';
import { TransferDialog } from './TransferDialog';
import { useDocumentVisible, usePreview, useVisible } from './hooks';
import { CameraViewer } from './CameraViewer';
import { SitesPage, Modal, SiteEditor, LayoutEditor, ConfirmDialog, IconButton } from './components';
import './style.css';
import './compact.css';
import './desktop.css';
import {DesktopSidebar} from './DesktopSidebar';
import {GripVertical} from 'lucide-react';
import {useCameraArrange} from './useCameraArrange';
import './arrange.css';
import './monitors.css';
import {MonitorDialog,GroupsDialog} from './MonitorDialog';
import {Monitor,FolderPlus} from 'lucide-react';
import {windowSettings,wallGrid} from './multi-window';

const preferences = (()=>{try{return JSON.parse(localStorage.getItem('darkstar-ui-v1'))||{}}catch{return {}}})();
const childParams=new URLSearchParams(location.search);
const childKey=childParams.get('window');
let childPreferences={};try{childPreferences=JSON.parse(sessionStorage.getItem(`darkstar-window-${childKey}`))||{}}catch{}
const windowState=windowSettings(location.search,preferences,childPreferences);
const uiPreferences=windowState.preferences;
const presets = [[1,1],[2,2],[3,3],[4,4],[6,4],[6,6],[8,8],[9,9],[10,10],[12,12]];
const initial = {sites:[],groups:[],layouts:[],gateway:{maxLive:9,version:'0.7.0'}};

function App() {
  const [data,setData]=useState(initial), [ready,setReady]=useState(false), [error,setError]=useState(null), [tab,setTab]=useState('cameras');
  const [activeId,setActiveId]=useState(uiPreferences.activeId||null), [rows,setRows]=useState(uiPreferences.rows||2), [columns,setColumns]=useState(uiPreferences.columns||2), [gridHeight,setGridHeight]=useState(0), [gridWidth,setGridWidth]=useState(0), [tileSizing,setTileSizing]=useState(uiPreferences.tileSizing||"fit");
  const [query,setQuery]=useState(''), [searchOpen,setSearchOpen]=useState(false), [siteFilter,setSiteFilter]=useState('all'), [gridMode,setGridMode]=useState(preferences.uiVersion==='0.3.0'&&preferences.mode==='live'?'live':'preview'), [paused,setPaused]=useState(false);
  const [siteEditor,setSiteEditor]=useState(null), [viewEditor,setViewEditor]=useState(null), [gridEditor,setGridEditor]=useState(false), [confirm,setConfirm]=useState(null), [viewer,setViewer]=useState(null), [saveHelp,setSaveHelp]=useState(false), [transferOpen,setTransferOpen]=useState(false), [installPrompt,setInstallPrompt]=useState(null), [busy,setBusy]=useState(false), [notice,setNotice]=useState(null);
  const board=useRef(null),desktopSearch=useRef(null),windowSeeded=useRef(!childKey||!!childPreferences.rows);
  const [groupFilter,setGroupFilter]=useState(uiPreferences.groupFilter||'all'),[groupEditor,setGroupEditor]=useState(null),[groupsOpen,setGroupsOpen]=useState(false),[monitorsOpen,setMonitorsOpen]=useState(false),[wallMode,setWallMode]=useState(!!uiPreferences.wallMode);
  useEffect(()=>{if(!ready||windowSeeded.current)return;const view=data.layouts.find(v=>v.id===activeId);if(childParams.get('fit')==='1'){const group=(data.groups||[]).find(g=>g.id===groupFilter);const keys=view?view.cameras:group?group.cameras:data.sites.flatMap(s=>s.cameras.map(c=>c.key));const count=group?keys.filter(k=>group.cameras.includes(k)).length:keys.length;if(!count&&data.sites.some(s=>s.status==='connecting'))return;const grid=wallGrid(count,innerWidth,innerHeight);setRows(grid.rows);setColumns(grid.columns);setTileSizing('fit');}else if(view){setRows(view.rows||2);setColumns(view.columns);}windowSeeded.current=true;},[ready,data.layouts,activeId]);
  const [arrangement,setArrangement]=useState(null),[arrangeBusy,setArrangeBusy]=useState(false);
  const guard=action=>{if(arrangement)setConfirm({title:'Discard layout changes?',text:'Your saved view will stay unchanged.',action:async()=>{setArrangement(null);action()}});else action()};
  const arrangementOrder=useCameraArrange(arrangement?.cameras||[],cameras=>setArrangement(value=>value?{...value,cameras}:value),board);
  useEffect(()=>{if(!arrangement)return;const warn=e=>{e.preventDefault();e.returnValue=''};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn)},[!!arrangement]);
  useEffect(()=>{const shortcut=event=>{if(event.key!=="/"||event.ctrlKey||event.metaKey||event.altKey||event.target.closest("input,textarea,select,[contenteditable=true],dialog"))return;if(desktopSearch.current?.getClientRects().length){event.preventDefault();desktopSearch.current.focus()}};window.addEventListener("keydown",shortcut);return()=>window.removeEventListener("keydown",shortcut)},[]);
  const documentVisible=useDocumentVisible();
  const update=value=>{setData(value);setReady(true);setError(null)};
  const reload=async(force=false)=>{try{update(await api(force?'refresh':'state',force?{method:'POST',body:{}}:{}))}catch(error){setReady(true);setError(error.message)}};
  useEffect(()=>{reload();const timer=setInterval(()=>{if(!document.hidden)reload()},10000);return()=>clearInterval(timer)},[]);
  useEffect(()=>{try{(windowState.storage==='session'?sessionStorage:localStorage).setItem(windowState.key,JSON.stringify({groupFilter,wallMode,uiVersion:'0.7.0',activeId,rows,columns,mode:gridMode,tileSizing}))}catch{}},[activeId,rows,columns,gridMode,tileSizing,groupFilter,wallMode]);
  useEffect(()=>{if(notice){const timer=setTimeout(()=>setNotice(null),4500);return()=>clearTimeout(timer)}},[notice]);
  useEffect(()=>{const event=e=>{e.preventDefault();setInstallPrompt(e)};window.addEventListener('beforeinstallprompt',event);if('serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});return()=>window.removeEventListener('beforeinstallprompt',event)},[]);
  const all=data.sites.flatMap(site=>site.cameras.map(camera=>({...camera,siteName:site.name,siteColor:site.color,siteStatus:site.status})));
  const currentView=data.layouts.find(view=>view.id===activeId);
  const groups=data.groups||[],currentGroup=groups.find(g=>g.id===groupFilter);
  const ordered=currentView?(arrangement?.id===currentView.id?arrangement.cameras:currentView.cameras).map(key=>all.find(camera=>camera.key===key)).filter(Boolean):currentGroup?currentGroup.cameras.map(key=>all.find(c=>c.key===key)).filter(Boolean):all;
  const filtered=ordered.filter(camera=>(!currentGroup||currentGroup.cameras.includes(camera.key))&&(siteFilter==='all'||camera.siteId===siteFilter)&&`${camera.name} ${camera.siteName}`.toLowerCase().includes(query.toLowerCase()));
  const cameras=filtered;
  const streaming=!paused&&documentVisible&&!error&&!viewer&&!siteEditor&&!viewEditor&&!gridEditor&&!saveHelp&&!transferOpen&&!groupEditor&&!groupsOpen&&!monitorsOpen&&!confirm&&tab!=='sites';
  useLayoutEffect(()=>{const element=board.current;if(!element)return;const observer=new ResizeObserver(entries=>{setGridHeight(entries[0].contentRect.height);setGridWidth(entries[0].contentRect.width)});observer.observe(element);setGridHeight(element.clientHeight);setGridWidth(element.clientWidth);return()=>observer.disconnect()},[filtered.length,tab,viewer]);
  useEffect(()=>{if(board.current)board.current.scrollTop=0},[activeId,rows,columns,query,siteFilter,groupFilter,tab]);
  const tileHeight=tileSizing==="video"?Math.max(90,(gridWidth-6*(columns-1))/columns*9/16):Math.max(48,(gridHeight-6*(rows-1))/rows);
  const openView=id=>guard(()=>{setActiveId(id);const view=data.layouts.find(view=>view.id===id);if(view){setRows(view.rows||2);setColumns(view.columns)}setSiteFilter('all');setQuery('')});
  const beginArrange=()=>{if(!currentView){setViewEditor({cameras:filtered.slice(0,1000).map(c=>c.key),rows,columns,seeded:filtered.length>1000});return;}setArrangement({...currentView,rows,columns,cameras:[...currentView.cameras]});setSiteFilter('all');setQuery('');};
  const saveArrangement=async()=>{setArrangeBusy(true);try{update(await api('layouts',{method:'POST',body:{...arrangement,rows,columns}}));setArrangement(null);setNotice('Layout order and grid saved');}catch(error){setNotice(error.message)}finally{setArrangeBusy(false)}};
  const cancelArrange=()=>{setRows(arrangement.rows||2);setColumns(arrangement.columns||2);setArrangement(null)};
  const refresh=async()=>{setBusy(true);await reload(true);setBusy(false)};
  const openCamera=camera=>!arrangement&&setViewer({key:camera.key,playback:tab==='recordings',cameras:filtered});
  const removeSite=site=>setConfirm({title:`Remove ${site.name}?`,text:'Only this device’s saved connection is removed. Recordings stay on Blue Iris.',action:async()=>{update(await api(`sites/${site.id}`,{method:'DELETE'}));setNotice('Site removed')}});
  const removeView=view=>setConfirm({title:`Delete ${view.name}?`,text:'This removes the saved layout only.',action:async()=>{update(await api(`layouts/${view.id}`,{method:'DELETE'}));setActiveId(null);setNotice('View removed')}});

  return <>{viewer?<CameraViewer cameras={viewer.cameras} initialKey={viewer.key} playback={viewer.playback} onBack={()=>setViewer(null)}/>:<div className={`apk-app ${wallMode?"monitor-wall":""}`}><DesktopSidebar tab={tab} onTab={value=>guard(()=>setTab(value))} sites={data.sites} views={data.layouts} groups={groups} groupFilter={groupFilter} onGroup={id=>guard(()=>{setGroupFilter(id);setActiveId(null);setTab('cameras')})} onGroups={()=>guard(()=>setGroupsOpen(true))} activeId={currentView?.id} onView={id=>{openView(id);if(tab==="sites")setTab("cameras")}} onNewView={()=>guard(()=>setViewEditor({cameras:[],rows,columns}))} onEditView={view=>guard(()=>setViewEditor(view))} onSite={site=>guard(()=>{setTab("cameras");setActiveId(null);setQuery("");setSiteFilter(site.id)})}/>
    {wallMode&&<div className="wall-toolbar"><strong>{currentView?.name||'All cameras'}{currentGroup?` · ${currentGroup.name}`:''}</strong><button onClick={()=>setPaused(!paused)}>{paused?'Resume':'Pause'}</button><button onClick={()=>{const action=document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();action?.catch(()=>setNotice('Fullscreen unavailable. Use the browser fullscreen control.'));}}>Fullscreen</button><button onClick={()=>setWallMode(false)}>Show controls</button></div>}
    <header className="apk-header"><img src="/brand.png" alt="Darkstar Technical" style={{width:40,height:40,objectFit:"contain",background:"#101c2b",borderRadius:7}}/><div><strong>Darkstar</strong><span>{data.sites.filter(site=>site.status==='online').length} / {data.sites.length} sites connected</span></div><IconButton label="Transfer sites and settings" onClick={()=>guard(()=>setTransferOpen(true))}><Settings2 size={20}/></IconButton><IconButton label="Multi-monitor workspace" onClick={()=>guard(()=>setMonitorsOpen(true))}><Monitor size={20}/></IconButton><IconButton label="Save or install Darkstar" onClick={()=>setSaveHelp(true)}><Download size={20}/></IconButton><IconButton label="Refresh cameras" disabled={busy} onClick={refresh}><RefreshCw size={21} className={busy?'spin':''}/></IconButton><IconButton label="Add server" onClick={()=>guard(()=>setSiteEditor({}))}><Plus size={25}/></IconButton></header>
    <main className={`compact-main ${tab==='sites'?'sites-main':''}`}>
      {error&&<div className="compact-warning"><WifiOff size={16}/><span>{error}</span><button onClick={()=>reload()}>Reconnect</button></div>}
      {tab==='sites'?<SitesPage sites={data.sites} onAdd={()=>setSiteEditor({})} onEdit={setSiteEditor} onRemove={removeSite} onView={site=>{setTab('cameras');setActiveId(null);setSiteFilter(site.id)}} onRefresh={refresh} busy={busy}/>:<>
        <div className="compact-title"><h1>{tab==='recordings'?'Recordings':'Your cameras'}</h1><span>{filtered.length} cameras</span>{data.sites.length>0&&<button className="arrange-start" disabled={!!arrangement} onClick={beginArrange}><GripVertical size={14}/>{currentView?"Arrange":"Create layout"}</button>}</div>
        {data.sites.length>0&&<><div className="compact-toolbar"><label className="compact-site"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 22S4 13 4 8a8 8 0 1 1 16 0c0 5-8 14-8 14z" fill="currentColor"/><circle cx="12" cy="8" r="3" fill="#080e17"/></svg><select disabled={!!arrangement} aria-label="Filter by site" value={siteFilter} onChange={event=>setSiteFilter(event.target.value)}><option value="all">All sites</option>{data.sites.map(site=><option key={site.id} value={site.id}>{site.name}</option>)}</select><ChevronDown size={16}/></label><label className="desktop-search"><Search size={17}/><input disabled={!!arrangement} ref={desktopSearch} aria-label="Search desktop cameras" placeholder="Search cameras or sites" value={query} onChange={event=>setQuery(event.target.value)}/>{query?<IconButton label="Clear desktop search" onClick={()=>setQuery("")}><X size={15}/></IconButton>:<kbd>/</kbd>}</label><span className="toolbar-spacer"/><IconButton label={paused?'Resume cameras':'Pause cameras'} onClick={()=>setPaused(!paused)}>{paused?<Play size={17}/>:<Pause size={17}/>}</IconButton><IconButton className="search-toggle" label="Search cameras" onClick={()=>setSearchOpen(!searchOpen)}><Search size={21}/></IconButton><IconButton label="Custom grid" onClick={()=>setGridEditor(true)}><Settings2 size={22}/></IconButton></div>
          {searchOpen&&<label className="search compact-search"><Search size={16}/><input disabled={!!arrangement} autoFocus aria-label="Find cameras" placeholder="Find cameras across sites" value={query} onChange={event=>setQuery(event.target.value)}/><IconButton label="Clear search" onClick={()=>{setQuery('');setSearchOpen(false)}}><X size={16}/></IconButton></label>}
          <div className="grid-presets">{presets.map(([r,c])=><button key={`${r}:${c}`} className={rows===r&&columns===c?'selected':''} aria-label={`${r*c} camera grid`} onClick={()=>{setRows(r);setColumns(c)}}>{r*c}</button>)}<button className={!presets.some(([r,c])=>r===rows&&c===columns)?'selected':''} onClick={()=>setGridEditor(true)}>Custom</button><label className="desktop-tile-sizing">Tile sizing<select aria-label="Camera tile sizing" value={tileSizing} onChange={event=>setTileSizing(event.target.value)}><option value="fit">Fit screen</option><option value="video">16:9 tiles</option></select></label></div>
          <div className="view-chips"><button className={!currentView?'selected':''} onClick={()=>openView(null)}>All cameras</button>{data.layouts.map(view=><button key={view.id} className={activeId===view.id?'selected':''} onClick={()=>openView(view.id)}>{view.name}</button>)}<button onClick={()=>guard(()=>setViewEditor({cameras:[],rows,columns}))}>+ New view</button></div></>}
        {arrangement&&<div className="arrange-toolbar"><p>Arranging {currentView?.name} · Drag a handle, or focus it and use arrow keys. Grid changes are saved too.</p><button className="button ghost" disabled={arrangeBusy} onClick={cancelArrange}>Cancel arrangement</button><button className="button secondary" disabled={arrangeBusy} onClick={()=>{setViewEditor({...arrangement,id:undefined,name:`${arrangement.name} copy`,rows,columns})}}>Save as new layout</button><button className="button primary" disabled={arrangeBusy} onClick={saveArrangement}>{arrangeBusy?'Saving…':'Save layout'}</button></div>}
        {data.sites.length>0&&<div className="group-toolbar"><select aria-label="Camera group" disabled={!!arrangement} value={groupFilter} onChange={e=>setGroupFilter(e.target.value)}><option value="all">All groups</option>{groups.map(g=><option key={g.id} value={g.id}>{g.name} ({g.cameras.length})</option>)}</select><button disabled={!!arrangement} onClick={()=>setGroupsOpen(true)}>Manage groups</button><button onClick={()=>guard(()=>setWallMode(true))}>Camera wall</button></div>}
        {data.sites.some(site=>site.status==='offline')&&<button className="compact-warning" onClick={()=>setTab('sites')}><WifiOff size={15}/><span>{data.sites.filter(site=>site.status==='offline').length} site connection(s) need attention</span><ChevronRight size={16}/></button>}
        {!ready?<div className="compact-empty"><LoaderCircle className="spin"/><p>Opening your workspace…</p></div>:!data.sites.length?<div className="compact-empty"><Video size={44}/><h2>Every place. One view.</h2><p>Connect a Blue Iris site to get started.</p><button className="button primary" onClick={()=>guard(()=>setSiteEditor({}))}>Connect your first server</button></div>:!filtered.length?<div className="compact-empty"><Video size={30}/><p>{data.sites.some(site=>site.status==='connecting')?'Discovering cameras…':'No cameras in this view. Adjust the filters or edit the view.'}</p></div>:<div className={`compact-camera-grid ${columns>=3?'dense':''}`} ref={board} role="region" aria-label="Camera grid" tabIndex={0} style={{gridTemplateColumns:`repeat(${columns},minmax(0,1fr))`,gridAutoRows:`${tileHeight}px`}}>
          {gridHeight>0?cameras.map(camera=><div key={camera.key} data-sort-key={camera.key} data-editing={!!arrangement} className={`arrange-cell ${arrangementOrder.drag?.key===camera.key?'sort-source':''} ${arrangementOrder.drag?.target===camera.key?'sort-target':''}`}><CompactTile camera={camera} inactive={!streaming} playback={tab==='recordings'} dense={columns>=3} onOpen={()=>openCamera(camera)}/>{arrangement&&<button className="arrange-handle" disabled={arrangeBusy} aria-label={`Move ${camera.name}`} title="Drag to move; arrow keys move one position" {...arrangementOrder.handle(camera.key,camera.name)}><GripVertical size={20}/></button>}</div>):<LoaderCircle className="spin grid-loading"/>}
        </div>}
        {data.sites.length>0&&<div className="compact-grid-footer"><div>{currentView&&!arrangement?<><button onClick={()=>setViewEditor({...currentView,rows,columns})}><Pencil size={13}/>Edit view</button><IconButton label={`Delete ${currentView.name}`} onClick={()=>removeView(currentView)}><Trash2 size={13}/></IconButton></>:<span>{tab==='recordings'?'Choose a camera to browse recordings':paused?'Camera feeds paused':'JPEG previews · open a camera for live video'}</span>}</div><div className="scroll-hint"><ChevronDown size={16}/><span>Scroll</span></div></div>}
      </>}
    </main>
    <nav className="apk-bottom-nav" aria-label="Main navigation">{[['cameras','Cameras',Grid2X2],['recordings','Recordings',CirclePlay],['sites','Sites',Server]].map(([value,label,Icon])=><button key={value} className={tab===value?'selected':''} onClick={()=>guard(()=>setTab(value))}><Icon size={23}/><span>{label}</span></button>)}</nav>
  </div>}
  {monitorsOpen&&<MonitorDialog views={data.layouts} groups={groups} currentView={activeId} currentGroup={groupFilter} onClose={()=>setMonitorsOpen(false)}/>}
  {groupsOpen&&<GroupsDialog groups={groups} onClose={()=>setGroupsOpen(false)} onNew={()=>{setGroupsOpen(false);setGroupEditor({cameras:[]})}} onEdit={g=>{setGroupsOpen(false);setGroupEditor(g)}} onUse={g=>{setGroupFilter(g.id);setActiveId(null);setGroupsOpen(false)}} onDelete={g=>{setGroupsOpen(false);setConfirm({title:`Delete group ${g.name}?`,text:'The cameras and saved layouts stay unchanged.',action:async()=>{update(await api(`groups/${g.id}`,{method:'DELETE'}));if(groupFilter===g.id)setGroupFilter('all');setNotice('Group deleted')}})}}/>}
  {groupEditor&&<LayoutEditor kind="group" layout={groupEditor} sites={data.sites} cameras={all} onClose={()=>setGroupEditor(null)} onSaved={value=>{update(value);setGroupEditor(null);setGroupFilter(value.savedId);setActiveId(null);setNotice('Group saved')}}/>}
  {transferOpen&&<TransferDialog sites={data.sites} preferences={{activeId,rows,columns,mode:gridMode,tileSizing,groupFilter}} onClose={()=>setTransferOpen(false)} onImported={value=>{update(value);const restored=value.restoredPreferences;setGroupFilter(restored.groupFilter||'all');setActiveId(restored.activeId);setRows(restored.rows);setColumns(restored.columns);setGridMode(restored.mode);setTileSizing(restored.tileSizing);setSiteFilter('all');setQuery('');setNotice('Sites and settings imported');}}/>}
  {siteEditor&&<SiteEditor site={siteEditor} onClose={()=>setSiteEditor(null)} onSaved={value=>{update(value);setSiteEditor(null);setNotice('Site connection saved')}}/>}
  {viewEditor&&<LayoutEditor layout={viewEditor} sites={data.sites} cameras={all} onClose={()=>setViewEditor(null)} onSaved={value=>{update(value);setViewEditor(null);setArrangement(null);const view=value.layouts.find(view=>view.id===value.savedId);setActiveId(view.id);setRows(view.rows);setColumns(view.columns);setSiteFilter('all');setQuery('');setNotice('View saved')}}/>}
  {gridEditor&&<GridEditor rows={rows} columns={columns} onClose={()=>setGridEditor(false)} onSave={(r,c)=>{setRows(r);setColumns(c);setGridEditor(false)}}/>}
  {confirm&&<ConfirmDialog {...confirm} onClose={()=>setConfirm(null)} onError={setNotice}/>}
  {saveHelp&&<Modal title="Save Darkstar" subtitle="YOUR CAMERA APP" onClose={()=>setSaveHelp(false)}><div className="help-content"><div className="help-feature"><Download/><div><h3>Save it on this computer</h3><p>Run Setup-Darkstar.cmd in the extracted folder. It checks and installs prerequisites, creates your Desktop shortcut, and opens Darkstar. After setup, use the Darkstar Camera Viewer shortcut.</p></div></div>{installPrompt&&<button className="button primary" onClick={async()=>{await installPrompt.prompt();await installPrompt.userChoice;setInstallPrompt(null)}}>Install browser app</button>}<div className="help-feature"><ShieldCheck/><div><h3>Your sites and views stay saved</h3><p>Connections and camera views are encrypted for your Windows account. Keep this installation’s .local folder when updating.</p></div></div><p className="help-limit">Desktop edition v0.7.0 with live/playback audio, server-advertised PTZ, video zoom and stitched MP4 exports. This local address works on this workstation. Phone and remote access need separate HTTPS and private-network setup. Audio/video uses WebCodecs in current Edge or Chrome. First stitched export downloads a checksum-verified media runtime.</p></div></Modal>}
  <div className="arrange-sr" role="status">{arrangementOrder.announcement}</div>{arrangementOrder.drag&&<div className="arrange-ghost" style={{left:arrangementOrder.drag.x+14,top:arrangementOrder.drag.y+14}}>Move {arrangementOrder.drag.label}</div>}
  {notice&&<div className="compact-notice" role="status">{notice}<IconButton label="Dismiss message" onClick={()=>setNotice(null)}><X size={14}/></IconButton></div>}
  </>;
}

function CompactTile({camera,inactive,playback,dense,onOpen}) {
  const [ref,visible]=useVisible();
  const available=camera.enabled&&camera.siteStatus==='online';
  const preview=usePreview(camera,visible&&!inactive&&available);
  const image=preview.url;
  const label=!camera.enabled?'DISABLED':camera.siteStatus!=='online'?'SITE OFFLINE':inactive?'PAUSED':preview.error?'UNAVAILABLE':!image?'CONNECTING':playback?'BROWSE RECORDINGS':'PREVIEW';
  return <button className="compact-camera-tile" ref={ref} onClick={onOpen} aria-label={`Open ${camera.name} at ${camera.siteName}`}>
    {image?<img src={image} alt={`${camera.name} preview`}/>:<Video className="tile-placeholder" size={dense?22:34}/>}<span className="tile-gradient"/>{(!dense||!available)&&<span className="tile-label">{label}</span>}<span className="tile-caption"><strong>{camera.name}</strong><small>{camera.siteName}</small></span>
  </button>;
}
function GridEditor({rows,columns,onClose,onSave}) {const [r,setRows]=useState(rows),[c,setColumns]=useState(columns);return <Modal title="Camera grid" onClose={onClose}><div className="form-content"><div className="form-row"><label className="field">Visible rows<select aria-label="Visible grid rows" value={r} onChange={e=>setRows(Number(e.target.value))}>{Array.from({length:12},(_,i)=>i+1).map(value=><option key={value}>{value}</option>)}</select></label><label className="field">Columns<select aria-label="Grid columns" value={c} onChange={e=>setColumns(Number(e.target.value))}>{Array.from({length:12},(_,i)=>i+1).map(value=><option key={value}>{value}</option>)}</select></label></div><p className="muted small">{r*c} panes in view. Scroll vertically for more cameras.</p></div><div className="modal-footer"><button className="button secondary" onClick={onClose}>Cancel</button><button className="button primary" onClick={()=>onSave(r,c)}>Apply grid</button></div></Modal>}

createRoot(document.getElementById('root')).render(<App/>);



import './media-controls.css';





