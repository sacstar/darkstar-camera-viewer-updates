import { test } from 'node:test';
import assert from 'node:assert/strict';
import { encryptConfig, decryptConfig, validateConfig, applyConfig, configFromVault } from '../server/transfer.mjs';
import { transferFixture as config, transferPhrase as phrase } from './transfer-fixture.mjs';

test('portable backups roundtrip credentials, colors, site priority and layouts without plaintext', async () => {
  const backup = await encryptConfig(config, phrase);
  assert.ok(!JSON.stringify(backup).includes('fixture-secret'));
  assert.deepEqual(await decryptConfig(backup, phrase), config);
  await assert.rejects(decryptConfig(backup, 'wrong-but-long-enough'));
  const changed = structuredClone(backup); const bytes = Buffer.from(changed.data, 'base64'); bytes[0] ^= 1; changed.data = bytes.toString('base64');
  await assert.rejects(decryptConfig(changed, phrase));
  await assert.rejects(decryptConfig({ ...backup, iterations: 1 }, phrase));
});
test('merge retains other sites, replaces matching IDs and preserves portable preferences', () => {
  const state = { sites: [{ ...config.sites[0], password: 'old' }, { ...config.sites[1], id: 'existing' }], layouts: [{ ...config.settings.views[0], id: 'existing-view' }] };
  applyConfig(state, config, false);
  assert.deepEqual(state.sites.map(site => site.id), ['fixture-south', 'fixture-north', 'existing']);
  assert.equal(state.sites[1].password, config.sites[0].password); assert.equal(state.layouts.length, 2);
  const exported = configFromVault(state);
  assert.equal(exported.settings.pwa.tileSizing, 'video'); assert.equal(exported.settings.selectedView, 'fixture-doors');
  applyConfig(state, config, true); assert.equal(state.sites.length, 2); assert.equal(state.layouts.length, 1);
});
test('invalid camera references, duplicate IDs and embedded URL credentials are rejected', () => {
  for (const mutate of [value => value.sites.push(value.sites[0]), value => value.sites[0].url = 'http://user:secret@example.test', value => value.settings.views[0].cameras = ['missing:camera'], value => value.settings.rows = 0]) {
    const value = structuredClone(config); mutate(value); assert.throws(() => validateConfig(value));
  }
});
