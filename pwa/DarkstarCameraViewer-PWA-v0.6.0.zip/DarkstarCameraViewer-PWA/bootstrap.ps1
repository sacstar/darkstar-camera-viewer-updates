#Requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Start','Setup','Save','Check','Stop')][string]$Action = 'Start',
    [switch]$PrivateRuntime,
    [string]$RuntimeDirectory = (Join-Path $env:LOCALAPPDATA 'DarkstarCameraViewer\runtime'),
    [switch]$NoInstall,
    [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$lock = $null
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or [Environment]::OSVersion.Version.Major -lt 10) { throw 'Darkstar requires Windows 10 or Windows 11.' }
    Import-Module (Join-Path $root 'prerequisites.psm1') -Force -DisableNameChecking
    if ($Action -eq 'Stop') {
        $port = if ($env:DARKSTAR_PORT) { [int]$env:DARKSTAR_PORT } else { 47831 }
        $origin = "http://127.0.0.1:$port"
        try { $response = Invoke-WebRequest $origin -UseBasicParsing -SessionVariable session -TimeoutSec 3 } catch { Write-Host 'Darkstar is not running on its local port.'; exit 0 }
        if ($response.Headers['X-Darkstar-Gateway'] -notmatch '^0\.[12345]\.') { throw 'This port does not belong to Darkstar. Nothing was stopped.' }
        Invoke-RestMethod "$origin/api/shutdown" -Method Post -WebSession $session -Headers @{ Origin = $origin } -ContentType 'application/json' -Body '{}' -TimeoutSec 10 | Out-Null
        $running = $true
        for ($attempt = 0; $attempt -lt 30; $attempt++) {
            try { Invoke-WebRequest $origin -UseBasicParsing -TimeoutSec 1 | Out-Null; Start-Sleep -Milliseconds 100 } catch { $running = $false; break }
        }
        if ($running) { throw 'The gateway has not finished stopping.' }
        Write-Host 'Darkstar gateway stopped.'
        exit 0
    }
    Get-NodeArchitecture | Out-Null
    Write-Host 'Darkstar prerequisite check'
    foreach ($required in @('dist\index.html','dist\manifest.webmanifest','dist\icon.ico','server\index.mjs','package.json','package-lock.json','launch.mjs','verify-dependencies.mjs','save-shortcut.mjs','public\icon.ico','Start-Darkstar.cmd')) {
        if (-not (Test-Path -LiteralPath (Join-Path $root $required) -PathType Leaf)) { throw "Missing app file: $required. Extract the entire Darkstar ZIP into a normal folder, then run setup there." }
    }
    $html = [IO.File]::ReadAllText((Join-Path $root 'dist\index.html'))
    foreach ($asset in [regex]::Matches($html, '(?:src|href)="/(assets/[^"?]+)"')) {
        if (-not (Test-Path -LiteralPath (Join-Path $root ('dist\' + $asset.Groups[1].Value)) -PathType Leaf)) { throw 'Built app assets are missing. Extract the entire ZIP before running setup.' }
    }
    Write-Host '[OK] Complete app package'
    if ($Action -ne 'Check' -and -not $NoInstall) {
        $local = Join-Path $root '.local'
        New-Item -ItemType Directory -Path $local -Force | Out-Null
        $deadline = [DateTime]::UtcNow.AddSeconds(120)
        while (-not $lock) {
            try { $lock = [IO.File]::Open((Join-Path $local 'setup.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
            catch [IO.IOException] { if ([DateTime]::UtcNow -gt $deadline) { throw 'Another Darkstar setup is busy. Close it or wait for it to finish, then retry.' }; Start-Sleep -Milliseconds 500 }
        }
    }
    $runtime = Get-CompatibleNode -Root $root -PrivateRuntime:$PrivateRuntime -RuntimeDirectory $RuntimeDirectory
    if (-not $runtime) {
        if ($Action -eq 'Check' -or $NoInstall) { throw 'Node.js 22+ with npm is missing. Run Setup-Darkstar.cmd to install prerequisites automatically.' }
        $runtime = Install-PrivateNode -Root $root -RuntimeDirectory $RuntimeDirectory
    }
    Write-Host "[OK] Node.js $($runtime.Version) with npm"
    # Only the current launcher process receives this PATH; system/user PATH is unchanged.
    $env:PATH = $runtime.Directory + ';' + $env:PATH
    Push-Location $root
    try {
        $fingerprint = (Get-FileHash -LiteralPath (Join-Path $root 'package-lock.json') -Algorithm SHA256).Hash
        $marker = Join-Path $root '.local\dependencies.sha256'
        $previous = if (Test-Path -LiteralPath $marker) { (Get-Content -LiteralPath $marker -Raw).Trim() } else { '' }
        & $runtime.Node (Join-Path $root 'verify-dependencies.mjs') --quiet
        $packagesValid = $LASTEXITCODE -eq 0
        if (-not $packagesValid -or ($previous -and $previous -ne $fingerprint)) {
            if ($Action -eq 'Check' -or $NoInstall) { throw 'App packages need installation or repair. Run Setup-Darkstar.cmd.' }
            Write-Host 'Installing locked app packages from npm. The first run needs Internet access...'
            & $runtime.Node $runtime.Npm ci --omit=dev --ignore-scripts --no-fund
            if ($LASTEXITCODE -ne 0) { throw 'Package installation failed. Check Internet/proxy access and write permissions, then run setup again.' }
            & $runtime.Node (Join-Path $root 'verify-dependencies.mjs')
            if ($LASTEXITCODE -ne 0) { throw 'Installed app packages did not pass verification. Run setup again.' }
        }
        if ($Action -ne 'Check' -and -not $NoInstall) { Set-Content -LiteralPath $marker -Value $fingerprint -Encoding Ascii }
        Write-Host '[OK] Required app packages'
        $browser = Get-DarkstarBrowser
        if (-not $browser) { throw 'No web browser was found. Install Microsoft Edge or Google Chrome, then run setup again.' }
        Write-Host "[OK] $browser"
        if ($Action -in @('Save','Setup')) {
            & $runtime.Node (Join-Path $root 'save-shortcut.mjs')
            if ($LASTEXITCODE -ne 0) { throw 'The Desktop shortcut could not be created.' }
        }
        if ($Action -in @('Start','Setup')) {
            $arguments = @((Join-Path $root 'launch.mjs'), '--app')
            if ($NoBrowser) { $arguments += '--no-browser' }
            & $runtime.Node @arguments
            if ($LASTEXITCODE -ne 0) { throw 'The app could not start. Check its local port and the logs in .local.' }
        }
        Write-Host 'Darkstar prerequisite check passed.'
    } finally { Pop-Location }
} catch {
    Write-Host ''
    Write-Host ('Darkstar: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($lock) { $lock.Dispose() }
}
