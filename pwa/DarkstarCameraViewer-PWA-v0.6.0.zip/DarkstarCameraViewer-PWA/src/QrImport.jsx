import React, {useEffect, useRef, useState} from 'react';
import jsQR from 'jsqr';
import {parseBlueIrisSetup} from './setup-qr';

export function QrImport({onImport}) {
  const [scanning,setScanning]=useState(false), [error,setError]=useState(null);
  const video=useRef(null), active=useRef(false), stream=useRef(null), picker=useRef(null);
  const stop=()=>{active.current=false;stream.current?.getTracks().forEach(track=>track.stop());stream.current=null;setScanning(false)};
  useEffect(()=>()=>{active.current=false;stream.current?.getTracks().forEach(track=>track.stop())},[]);
  const decode=source=>{
    const width=source.videoWidth||source.width, height=source.videoHeight||source.height;
    if(!width||!height)return false;
    const ratio=Math.min(1,2048/Math.max(width,height)),canvas=document.createElement('canvas');
    canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);
    const context=canvas.getContext('2d',{willReadFrequently:true});context.drawImage(source,0,0,canvas.width,canvas.height);
    const pixels=context.getImageData(0,0,canvas.width,canvas.height),code=jsQR(pixels.data,pixels.width,pixels.height);
    if(!code)return false;
    const profile=parseBlueIrisSetup(code.data);stop();onImport(profile);return true;
  };
  const image=async file=>{
    setError(null);if(!file)return;stop();
    try{if(file.size>10*1024*1024)throw new Error('Choose a QR image smaller than 10 MB.');
      const bitmap=await createImageBitmap(file);try{if(!decode(bitmap))throw new Error('No readable QR code was found in that image.')}finally{bitmap.close()}
    }catch(e){setError(e.message)}finally{if(picker.current)picker.current.value=''}
  };
  const scan=async()=>{
    setError(null);active.current=true;setScanning(true);
    try{const camera=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});
      if(!active.current){camera.getTracks().forEach(track=>track.stop());return}
      stream.current=camera;video.current.srcObject=camera;await video.current.play();
      const tick=()=>{if(!active.current)return;try{if(decode(video.current))return}catch(e){setError(e.message);stop();return}setTimeout(tick,200)};tick();
    }catch{setError('Camera access is unavailable. Allow camera access or choose a QR image.');stop()}
  };
  return <div className="qr-import"><div className="qr-actions"><button type="button" className="button secondary" onClick={()=>picker.current.click()}>QR image</button><button type="button" className="button secondary" onClick={scanning?stop:scan}>{scanning?'Stop scanning':'Scan QR'}</button></div><input ref={picker} aria-label="Blue Iris QR image" type="file" accept="image/*" hidden onChange={e=>image(e.target.files[0])}/>{scanning&&<video ref={video} muted playsInline aria-label="QR camera preview"/>}<small>Decode locally. Review imported addresses and credentials before saving.</small>{error&&<p role="alert" className="form-message error">{error}</p>}</div>;
}
