export class RequestQueue {
  constructor(limit=3) { this.limit=limit; this.active=0; this.pending=[]; }
  run(operation,signal) {
    if(signal?.aborted)return Promise.reject(new DOMException('Request cancelled','AbortError'));
    return new Promise((resolve,reject)=>{
      const task={operation,signal,resolve,reject,started:false};
      task.cancel=()=>{if(task.started)return;this.pending=this.pending.filter(item=>item!==task);reject(new DOMException('Request cancelled','AbortError'))};
      signal?.addEventListener('abort',task.cancel,{once:true});this.pending.push(task);this.drain();
    });
  }
  drain() {
    while(this.active<this.limit&&this.pending.length){
      const task=this.pending.shift();task.signal?.removeEventListener('abort',task.cancel);
      if(task.signal?.aborted){task.reject(new DOMException('Request cancelled','AbortError'));continue}
      task.started=true;this.active++;
      Promise.resolve().then(()=>{if(task.signal?.aborted)throw new DOMException('Request cancelled','AbortError');return task.operation()}).then(task.resolve,task.reject).finally(()=>{this.active--;this.drain()});
    }
  }
}
