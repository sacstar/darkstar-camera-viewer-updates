export async function api(path, options = {}) {
  const settings = { ...options, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...options.headers }, body: options.body === undefined ? undefined : JSON.stringify(options.body) };
  let response = await fetch(`/api/${path}`, settings);
  if (response.status === 401) { await fetch('/', { cache: 'no-store', credentials: 'same-origin' }); response = await fetch(`/api/${path}`, settings); }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'The gateway could not complete this request.');
  return data;
}
