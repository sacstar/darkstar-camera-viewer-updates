export function dayBounds(day) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) throw new Error('Choose a valid date.');
  const start = new Date(`${day}T00:00:00`);
  if (!Number.isFinite(+start) || localDate(start) !== day) throw new Error('Choose a valid date.');
  const end = new Date(start); end.setDate(end.getDate() + 1);
  return { start: +start, end: +end };
}
export function localDate(date = new Date()) { return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; }
export function recordingAt(recordings, position) { return recordings.filter(clip => position >= clip.start && position < clip.end).at(-1) || null; }
export function timelineWindow(bounds, anchor, zoom) {
  const length = zoom === 'day' ? bounds.end - bounds.start : Math.min(Number(zoom) * 60000, bounds.end - bounds.start);
  return { start: Math.max(bounds.start, Math.min(anchor - length / 2, bounds.end - length)), length };
}
export function eventKind(item) {
  const flags = Number(item.flags) || 0, memo = String(item.memo || '');
  const cancelled = (flags & 2 ** 23) !== 0;
  const personMemo = /\b(person|people|human)\b/i.test(memo) && !/\b(no\s+(person|people|human)|(?:person|human)\s*:\s*0(?:\.0+)?%)/i.test(memo);
  if (!cancelled && ((flags & 2 ** 26) !== 0 || personMemo)) return 'person';
  if ((flags & 2 ** 17) !== 0 || /\bmotion\b/i.test(memo)) return 'motion';
  return 'alert';
}
export function parseRecordings(data, cameraId) {
  if (!Array.isArray(data)) throw new Error('The server did not return recordings.');
  return [...new Map(data.filter(item => item && item.path && Number(item.date) > 0 && Number(item.msec) > 0).map(item => [item.path, { path: String(item.path), cameraId: String(item.camera || cameraId), start: Math.trunc(Number(item.date) * 1000), end: Math.trunc(Number(item.date) * 1000) + Number(item.msec), duration: Number(item.msec) }])).values()].sort((a,b)=>a.start-b.start);
}
export function parseEvents(data) {
  return (Array.isArray(data) ? data : []).filter(item => item && Number(item.date) > 0).map(item => ({ start: Math.trunc(Number(item.date) * 1000), duration: Math.max(1000, Number(item.msec) || 1000), kind: eventKind(item), label: String(item.memo || 'Server alert') })).sort((a,b)=>a.start-b.start);
}
