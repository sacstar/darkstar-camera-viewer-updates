import React,{useRef,useState,useEffect} from 'react';
export function VideoZoom({cameraKey,children,onSwipe}) {
  const [view,setView]=useState({scale:1,x:0,y:0}),state=useRef(view),points=useRef(new Map()),gesture=useRef(null),node=useRef(null),tap=useRef(0);
  state.current=view;
  useEffect(()=>{setView({scale:1,x:0,y:0});points.current.clear();gesture.current=null},[cameraKey]);
  const reset=()=>setView({scale:1,x:0,y:0});
  const metrics=()=>{const p=[...points.current.values()];return p.length>1?{x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2,d:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y)}:{...p[0],d:0}};
  return <div ref={node} className="video-zoom" data-zoom={view.scale.toFixed(1)} aria-label="Zoomable camera video" onDoubleClick={reset}
    onPointerDown={event=>{if(event.target.closest('button'))return;node.current.setPointerCapture(event.pointerId);points.current.set(event.pointerId,{x:event.clientX,y:event.clientY});const metric=metrics();gesture.current={...metric,startX:metric.x,startY:metric.y,multi:points.current.size>1,moved:false};}}
    onPointerMove={event=>{
      if(!points.current.has(event.pointerId))return;
      points.current.set(event.pointerId,{x:event.clientX,y:event.clientY});const metric=metrics(),previous=gesture.current;if(!previous)return;
      const multi=points.current.size>1,scale=Math.max(1,Math.min(8,state.current.scale*(multi&&previous.d?metric.d/previous.d:1)));
      if(multi||scale>1.01){event.preventDefault();const width=node.current.clientWidth,height=node.current.clientHeight;setView(old=>({scale,x:Math.max(-width*(scale-1)/2,Math.min(width*(scale-1)/2,old.x+metric.x-previous.x)),y:Math.max(-height*(scale-1)/2,Math.min(height*(scale-1)/2,old.y+metric.y-previous.y))}))}
      gesture.current={...previous,...metric,multi:previous.multi||multi,moved:previous.moved||Math.hypot(metric.x-previous.startX,metric.y-previous.startY)>10};
    }}
    onPointerUp={event=>{
      const g=gesture.current;points.current.delete(event.pointerId);
      if(!points.current.size&&g){if(!g.multi&&state.current.scale<=1.01){const dx=event.clientX-g.startX,dy=event.clientY-g.startY;if(Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.4)onSwipe(dx<0?1:-1)}if(!g.multi&&!g.moved){if(Date.now()-tap.current<300)reset();tap.current=Date.now()}gesture.current=null}else if(g)gesture.current={...g,...metrics()};
    }} onPointerCancel={()=>{points.current.clear();gesture.current=null}}>
    <div className="video-transform" style={{transform:`translate(${view.x}px,${view.y}px) scale(${view.scale})`}}>{children}</div>
    {view.scale>1.01&&<button className="zoom-reset" onClick={reset}>{view.scale.toFixed(1)}× · reset</button>}
  </div>;
}
