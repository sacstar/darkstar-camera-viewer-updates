import React, { useState } from 'react';
import { api } from './api';
import { Modal } from './components';

export function TransferDialog({ sites=[], preferences, onImported, onClose }) {
  const [siteIds,setSiteIds]=useState(sites.map(site=>site.id)),[prepared,setPrepared]=useState(null);
  const [passphrase, setPassphrase] = useState(''), [confirm, setConfirm] = useState(''), [envelope, setEnvelope] = useState(null), [review, setReview] = useState(null), [mode, setMode] = useState('merge'), [busy, setBusy] = useState(false), [message, setMessage] = useState('');
  const run = async action => { setBusy(true); setMessage(''); try { await action(); } catch (error) { setMessage(error.message); } finally { setBusy(false); } };
  const exportFile = (intent='download') => run(async () => {
    if (passphrase.length < 12 || passphrase.length > 256 || passphrase !== confirm) throw new Error('Use matching passphrases of 12 to 256 characters.');
    const data = await api('transfer/export', { method: 'POST', body: { preferences, passphrase,siteIds } });
    const file=new File([JSON.stringify(data)],'Darkstar-Viewer-Backup.json',{type:'application/json'});setPrepared(file);
    if(intent==='share'){setPassphrase('');setConfirm('');setMessage('Encrypted file prepared. Tap Share prepared backup to choose an app, or download it.');return}
    const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
    const link = document.createElement('a'); link.href = url; link.download = 'Darkstar-Viewer-Backup.json'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    setPassphrase(''); setConfirm(''); setMessage('Encrypted backup downloaded. Keep its passphrase separately.');
  });
  const share=()=>run(async()=>{if(!navigator.canShare?.({files:[prepared]}))throw new Error('File sharing is unavailable in this browser. Download the encrypted file and attach it using email, Messenger or another app.');await navigator.share({files:[prepared],title:'Encrypted Darkstar settings'});setMessage('Share sheet closed. The receiving app controls whether the file was sent.');});
  const readFile = event => run(async () => {
    setReview(null); setEnvelope(null); const file = event.target.files?.[0]; if (!file) return;
    if (file.size > 2 * 1024 * 1024) throw new Error('This backup is too large.');
    try { setEnvelope(JSON.parse(await file.text())); } catch { throw new Error('Choose a Darkstar Viewer backup file.'); }
  });
  const inspect = () => run(async () => setReview(await api('transfer/review', { method: 'POST', body: { envelope, passphrase } })));
  const restore = () => run(async () => {
    const result = await api('transfer/import', { method: 'POST', body: { envelope, passphrase, mode } });
    setPassphrase(''); setEnvelope(null); onImported(result); onClose();
  });
  return <Modal title="Transfer sites and settings" onClose={() => { if (!busy) onClose(); }}>
    <div className="form-content">
      <p className="form-intro">Use the same encrypted backup in Android or this PWA. It includes site logins, local/WAN addresses, colors, site order, grid settings and saved camera views. It does not include video.</p>
      <fieldset className="backup-sites" disabled={busy}><legend>Sites included ({siteIds.length}/{sites.length})</legend><div><button className="button ghost" onClick={()=>setSiteIds(sites.map(s=>s.id))}>Select all</button><button className="button ghost" onClick={()=>setSiteIds([])}>Clear</button></div>{sites.map(site=><label className="check-line" key={site.id}><input type="checkbox" checked={siteIds.includes(site.id)} onChange={event=>setSiteIds(ids=>event.target.checked?[...ids,site.id]:ids.filter(id=>id!==site.id))}/><i style={{background:site.color}}/>{site.name}</label>)}<small>Excluded site logins and camera references are removed. No selection exports display settings only.</small></fieldset>
      <label className="field">Transfer passphrase<input aria-label="Transfer passphrase" type="password" autoComplete="new-password" maxLength={256} value={passphrase} disabled={busy} onChange={event => { setPassphrase(event.target.value); setReview(null); }}/><small>At least 12 characters. Required on the destination device; it is not saved.</small></label>
      <label className="field">Confirm passphrase for export<input aria-label="Confirm passphrase for export" type="password" autoComplete="new-password" value={confirm} disabled={busy} maxLength={256} onChange={event => setConfirm(event.target.value)}/></label>
      <button className="button secondary" disabled={busy} onClick={()=>exportFile()}>Export encrypted backup</button>
      <button className="button secondary" disabled={busy} onClick={()=>exportFile('share')}>Quick share settings</button>
      {prepared&&<div className="prepared-share"><button className="button primary" disabled={busy} onClick={share}>Share prepared backup</button><button className="button secondary" onClick={()=>{const url=URL.createObjectURL(prepared),link=document.createElement('a');link.href=url;link.download=prepared.name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}}>Download prepared backup</button></div>}
      <hr/>
      <label className="field">Import backup<input type="file" accept=".dsv,.json,application/json" disabled={busy} onChange={readFile}/></label>
      <button className="button secondary" disabled={busy || !envelope || !passphrase} onClick={inspect}>Review import</button>
      {review && <section aria-label="Import review"><h3>{review.sites.length} sites · {review.views} saved views</h3><ul>{review.sites.map(site => <li key={site.id}>{site.name}</li>)}</ul>
        <label className="field">Import mode<select value={mode} disabled={busy} onChange={event => setMode(event.target.value)}><option value="merge">Merge — add sites and update matching IDs</option><option value="replace">Replace all sites and saved views</option></select></label>
        <p className="muted small">{mode === 'replace' ? 'Replace removes the current configuration. Export it first if you need to keep it.' : 'Imported settings take priority. Existing sites and views with different IDs are kept.'}</p>
        <button className="button primary" disabled={busy} onClick={restore}>{mode === 'replace' ? 'Replace configuration' : 'Import configuration'}</button>
      </section>}
      {message && <p role="status">{message}</p>}
    </div><div className="modal-footer"><button className="button secondary" disabled={busy} onClick={onClose}>Close</button></div>
  </Modal>;
}
