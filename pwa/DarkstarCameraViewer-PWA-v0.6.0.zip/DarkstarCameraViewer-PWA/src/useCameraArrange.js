import {useEffect,useRef,useState} from 'react';
import {moveCamera} from './layout-order';

// Drag only from handles so touching the rest of a tile still scrolls the grid.
export function useCameraArrange(keys,onChange,containerRef) {
  const latest=useRef({keys,onChange});latest.current={keys,onChange};
  const cleanup=useRef(()=>{}),[drag,setDrag]=useState(null),[announcement,setAnnouncement]=useState('');
  useEffect(()=>()=>cleanup.current(),[]);
  function handle(key,label) {
    return {
      onPointerDown(event) {
        if(!event.isPrimary||event.button!==0)return;
        event.preventDefault();event.stopPropagation();cleanup.current();
        const pointerId=event.pointerId,origin={x:event.clientX,y:event.clientY};
        let point=origin,target=null,started=false,frame;
        const container=containerRef.current;
        if(!container)return;
        const hit=()=>{
          const element=document.elementFromPoint(point.x,point.y)?.closest('[data-sort-key]');
          target=element&&container.contains(element)?element.dataset.sortKey:null;
          if(started)setDrag({key,target,label,x:point.x,y:point.y});
        };
        const tick=()=>{
          if(started){const bounds=container.getBoundingClientRect();
            if(point.x>=bounds.left&&point.x<=bounds.right&&point.y>=bounds.top-36&&point.y<=bounds.bottom+36){
              const delta=point.y<bounds.top+42?-12:point.y>bounds.bottom-42?12:0;
              if(delta){container.scrollTop+=delta;hit();}
            }
          }
          frame=requestAnimationFrame(tick);
        };
        const move=e=>{if(e.pointerId!==pointerId)return;point={x:e.clientX,y:e.clientY};
          if(Math.hypot(point.x-origin.x,point.y-origin.y)>6)started=true;
          if(started){e.preventDefault();hit();}
        };
        const stop=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',cancel);window.removeEventListener('keydown',escape);cancelAnimationFrame(frame);setDrag(null);cleanup.current=()=>{};};
        const cancel=()=>{stop();setAnnouncement('Move cancelled.');};
        const up=e=>{if(e.pointerId!==pointerId)return;hit();if(started&&target){const {keys,onChange}=latest.current;const next=moveCamera(keys,key,target);onChange(next);setAnnouncement(`${label} moved to position ${next.indexOf(key)+1}.`);}stop();};
        const escape=e=>{if(e.key==='Escape'){e.preventDefault();cancel();}};
        window.addEventListener('pointermove',move,{passive:false});window.addEventListener('pointerup',up);window.addEventListener('pointercancel',cancel);window.addEventListener('keydown',escape);cleanup.current=stop;frame=requestAnimationFrame(tick);
      },
      onKeyDown(event) {
        if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
        event.preventDefault();event.stopPropagation();const {keys,onChange}=latest.current;
        const index=keys.indexOf(key),direction=['ArrowLeft','ArrowUp'].includes(event.key)?-1:1;
        const to=event.key==='Home'?0:event.key==='End'?keys.length-1:Math.max(0,Math.min(keys.length-1,index+direction));
        onChange(moveCamera(keys,key,keys[to]));setAnnouncement(`${label} moved to position ${to+1}.`);
      }
    };
  }
  return {handle,drag,announcement};
}
