export function parseBlueIrisSetup(raw) {
  if (typeof raw !== 'string' || raw.length > 8192) throw new Error('This setup QR code is too large.');
  const lines = raw.replace(/\r\n/g, '\r').replace(/\n/g, '\r').split('\r');
  if (lines.length === 10 && lines.at(-1) === '') lines.pop();
  if (lines.length !== 9 || lines[0] !== 'Blue') throw new Error('This is not a supported Blue Iris setup QR code.');
  const address = (flag, value) => {
    if (!['0', '1'].includes(flag)) throw new Error('The QR code contains an invalid connection type.');
    if (!value.trim()) return '';
    const scheme = flag === '1' ? 'https:' : 'http:';
    let url;
    try { url = new URL(value.includes('://') ? value.trim() : `${scheme}//${value.trim()}`); } catch { throw new Error('The QR code contains an invalid address.'); }
    if (url.protocol !== scheme || url.username || url.password || url.search || url.hash) throw new Error('The QR code contains conflicting or unsupported connection settings.');
    return url.href.replace(/\/+$/, '');
  };
  const url = address(lines[3], lines[4]), wanUrl = address(lines[5], lines[6]);
  if (!url && !wanUrl) throw new Error('The QR code contains no server address.');
  if (!lines[7].trim()) throw new Error('The QR code contains no username.');
  return {name:lines[1].trim() || 'Blue Iris', url, wanUrl, username:lines[7], password:lines[8]};
}
