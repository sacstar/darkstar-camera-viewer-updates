import React,{useEffect,useState} from 'react';
import {Modal} from './components';
import {api} from './api';
import {localTimestamp} from './export-plan';

export function ClipExportDialog({camera,playhead,data,onClose}) {
  const [start,setStart]=useState(localTimestamp(playhead)),[end,setEnd]=useState(localTimestamp(Math.min(Date.now(),playhead+60000))),[motion,setMotion]=useState(false),[before,setBefore]=useState('5'),[after,setAfter]=useState('5'),[stream,setStream]=useState('main'),[allowSilent,setAllowSilent]=useState(false),[job,setJob]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  useEffect(()=>{
    if(!job?.id||job.status!=='active')return;
    let disposed=false,timer;const poll=async()=>{try{const value=await api(`exports/${job.id}`);if(!disposed){setJob(value);if(value.status==='active')timer=setTimeout(poll,1000)}}catch(error){if(!disposed)setError(error.message)}};timer=setTimeout(poll,500);
    return()=>{disposed=true;clearTimeout(timer)};
  },[job?.id,job?.status]);
  const prepare=async()=>{setBusy(true);setError('');try{setJob(await api('exports',{method:'POST',body:{key:camera.key,start:+new Date(start),end:+new Date(end),motion,before:Math.round(Number(before)*1000),after:Math.round(Number(after)*1000),stream,allowSilent}}))}catch(error){setError(error.message)}finally{setBusy(false)}};
  const save=async()=>{
    setError('');
    try {
      if(!window.showSaveFilePicker){const link=document.createElement('a');link.href=`/api/exports/${job.id}/file`;link.download='Darkstar-Export.mp4';link.click();setError('Download started. Your browser controls the save folder; enable “Ask where to save each file” to choose a location.');return}
      const handle=await window.showSaveFilePicker({suggestedName:'Darkstar-Export.mp4',types:[{description:'MP4 video with audio',accept:{'video/mp4':['.mp4']}}]});
      setBusy(true);const response=await fetch(`/api/exports/${job.id}/file`,{cache:'no-store'});if(!response.ok)throw new Error('Export is no longer available. Prepare it again.');
      const output=await handle.createWritable();try{await response.body.pipeTo(output)}catch(error){await output.abort().catch(()=>{});throw error}setError('MP4 saved to the selected location.');
    }catch(error){setError(error.name==='AbortError'?'No location selected. Your export is still ready.':error.message)}finally{setBusy(false)}
  };
  const share=async()=>{setBusy(true);setError('');try{const response=await fetch(`/api/exports/${job.id}/file`);if(!response.ok)throw new Error('Export is unavailable.');const file=new File([await response.blob()],'Darkstar-Export.mp4',{type:'video/mp4'});if(!navigator.canShare?.({files:[file]}))throw new Error('File sharing is unavailable in this browser. Save the MP4 and attach it from your preferred app.');await navigator.share({files:[file],title:'Camera export'})}catch(error){setError(error.name==='AbortError'?'Sharing cancelled. Your MP4 is still ready.':error.message)}finally{setBusy(false)}};
  const cancel=async()=>{if(job?.status==='active'){await api(`exports/${job.id}`,{method:'DELETE'}).catch(()=>{});setJob({...job,status:'error',message:'Local export cancelled; Blue Iris may finish an already queued job.'})}else onClose()};
  const active=busy||job?.status==='active',ready=job?.status==='ready';
  const field=(label,value,set)=> <div className="fine-time"><label className="field">{label}<input aria-label={label} type="datetime-local" step="0.001" value={value} disabled={active} onChange={event=>set(event.target.value)}/></label><div>{[-1000,-100,100,1000].map(delta=><button key={delta} className="button ghost" disabled={active} onClick={()=>{const ms=+new Date(value);if(Number.isFinite(ms))set(localTimestamp(ms+delta))}}>{delta>0?'+':'−'}{Math.abs(delta)/1000}s</button>)}<button className="button ghost" disabled={active} onClick={()=>set(localTimestamp(playhead))}>Playhead</button></div></div>;
  return <Modal title="Export recording" onClose={()=>{if(!active)onClose()}}><div className="form-content clip-export">
    {!ready&&<><p className="muted small">Device time · {Intl.DateTimeFormat().resolvedOptions().timeZone}</p>{field('Export start',start,setStart)}{field('Export end',end,setEnd)}
      <label className="check-line"><input type="checkbox" checked={motion} disabled={active||!data.eventsAvailable} onChange={e=>setMotion(e.target.checked)}/>Motion/person events only</label>
      {motion&&<div className="form-row"><label className="field">Seconds before<input type="number" min="0" max="60" step="0.1" value={before} disabled={active} onChange={e=>setBefore(e.target.value)}/></label><label className="field">Seconds after<input type="number" min="0" max="60" step="0.1" value={after} disabled={active} onChange={e=>setAfter(e.target.value)}/></label></div>}
      <label className="field">Video source<select aria-label="Export video source" value={stream} disabled={active} onChange={e=>setStream(e.target.value)}><option value="main">Main · original recorded resolution</option><option value="sub">Substream · if recorded</option></select></label>
      <p className="small">Audio is included and checked before saving.</p><label className="check-line"><input type="checkbox" checked={allowSilent} disabled={active} onChange={e=>setAllowSilent(e.target.checked)}/>Allow video-only if no audio was recorded</label>
      <p className="muted small">Pieces are stitched chronologically into one MP4 with audio. Matching codecs and resolution are required. Blue Iris may align boundaries to source keyframes.</p></>}
    {job&&<p role="status">{job.message}</p>}{ready&&<><p className="muted small">{job.pieces} piece(s) · {(job.size/1024/1024).toFixed(1)} MB · prepared locally for this browser session. Save before restarting the gateway.</p><button className="button primary" disabled={busy} onClick={save}>Choose MP4 save location</button>{job.size<=200*1024*1024&&<button className="button secondary" disabled={busy} onClick={share}>Share MP4</button>}</>}
    {error&&<p role="status">{error}</p>}
  </div><div className="modal-footer"><button className="button secondary" onClick={cancel}>{job?.status==='active'?'Cancel export':'Close'}</button>{!ready&&<button className="button primary" disabled={active} onClick={prepare}>{active?'Preparing…':'Prepare stitched MP4'}</button>}</div></Modal>;
}
