import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, CalendarDays, ChevronLeft, ChevronRight, RefreshCw, Play, Pause, SkipBack, SkipForward, RotateCcw, RotateCw, LoaderCircle, AlertCircle, Maximize, Minimize } from 'lucide-react';
import { IconButton } from './components';
import { api } from './api';
import { dayBounds, localDate, recordingAt } from './playback-model';
import { useViewerStream } from './viewer-stream';
import {useNativeAv} from './native-av';
import {VideoZoom} from './VideoZoom';
import {PtzControls} from './PtzControls';
import {ClipExportDialog} from './ClipExportDialog';
import {Volume2,VolumeX,Move,Download} from 'lucide-react';
import {TimelineAxis,motionAxis} from './timeline-axis';
import {GestureTimeline} from './GestureTimeline';

const time = (value, seconds = false) => new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', ...(seconds ? { second: '2-digit' } : {}), hour12: false });
const empty = { recordings: [], events: [], eventsAvailable: true };

export function CameraViewer({ cameras, initialKey, playback: initialPlayback, onBack }) {
  const [key, setKey] = useState(initialKey), [mode, setMode] = useState(initialPlayback ? 'playback' : 'live'), [day, setDay] = useState(localDate()), [data, setData] = useState(empty), [loading, setLoading] = useState(false), [loadError, setLoadError] = useState(null);
  const [position, setPosition] = useState(Date.now() - 60000), [requested, setRequested] = useState(Date.now() - 60000), [playing, setPlaying] = useState(true), [speed, setSpeed] = useState(100), [revision, setRevision] = useState(0), [dayRevision, setDayRevision] = useState(0), [zoom, setZoom] = useState(7200000), [motionOnly,setMotionOnly]=useState(false), [scrubbing,setScrubbing]=useState(false), [anchor, setAnchor] = useState(Date.now() - 60000), [listCount, setListCount] = useState(20), [fullscreen, setFullscreen] = useState(false);
  const [audioEnabled,setAudioEnabled]=useState(false),[ptzOpen,setPtzOpen]=useState(true),[exportOpen,setExportOpen]=useState(false);
  const canvas=useRef(null);
  const index = Math.max(0, cameras.findIndex(camera => camera.key === key)), camera = cameras[index], bounds = dayBounds(day);
  const touch = useRef(null), loadedDay = useRef(null), positionRef = useRef(position), clipsRef = useRef(data.recordings), wantInitial = useRef(true);
  positionRef.current = position; clipsRef.current = data.recordings;
  const previewTimer=useRef(null),resumeAfterScrub=useRef(true);
  const axis=useMemo(()=>motionOnly?motionAxis(data,bounds):new TimelineAxis([bounds]),[data,day,motionOnly]);
  const axisRef=useRef(axis),motionRef=useRef(motionOnly);axisRef.current=axis;motionRef.current=motionOnly;
  useEffect(()=>()=>clearTimeout(previewTimer.current),[]);
  useEffect(()=>{if(motionOnly&&!loading&&axis.duration&&!axis.sectionAt(positionRef.current))seek(axis.snap(positionRef.current),playing)},[axis,loading]);
  function seek(value, resume = true) { const next = Math.max(bounds.start, Math.min(Math.trunc(motionOnly?axis.snap(value):value), bounds.end - 1)); setPosition(next); setRequested(next); setAnchor(next); setPlaying(resume); setRevision(value => value + 1); }
  function goPlayback() { setMode('playback'); setRequested(position); setPlaying(true); setRevision(value => value + 1); }
  function move(direction) { const next = Math.max(0,Math.min(cameras.length-1,index+direction)); if (next !== index) { setKey(cameras[next].key); setRequested(position); setRevision(value=>value+1); } }
  useEffect(() => { const event = e => { if (e.key === 'Escape') onBack(); }; window.addEventListener('keydown',event); return () => window.removeEventListener('keydown',event); }, [onBack]);
  useEffect(() => {
    if (mode !== 'playback') return;
    const abort = new AbortController(); let disposed = false;
    setLoading(true); setLoadError(null); setData(empty); setListCount(20);
    api(`sites/${camera.siteId}/cameras/${encodeURIComponent(camera.id)}/recordings?start=${bounds.start}&end=${bounds.end}`, { signal: abort.signal }).then(result => {
      if (disposed) return;
      setData(result); loadedDay.current = `${camera.key}:${day}`;
      if (result.recordings.length && (wantInitial.current || positionRef.current < bounds.start || positionRef.current >= bounds.end)) {
        const latest = result.recordings.at(-1); seek(latest.start + Math.min(1000, latest.duration / 2), true);
      }
      wantInitial.current = false;
    }).catch(error => { if (!disposed) setLoadError(error.message); }).finally(() => { if (!disposed) setLoading(false); });
    return () => { disposed = true; abort.abort(); };
  }, [camera.key, day, mode, dayRevision]);
  const recording = recordingAt(data.recordings, position);
  const canPlay = mode === 'live' || (!loading && !!recording && (!motionOnly || !!axis.duration));
  const onMediaPosition=value=>{
    if(motionRef.current){const activeAxis=axisRef.current,section=activeAxis.sectionAt(positionRef.current);if(section&&value>=section.end){const following=activeAxis.sections.find(s=>s.start>=section.end);if(following){seek(following.start,true)}else{seek(section.end-1,false)}return}}
    const current=recordingAt(clipsRef.current,positionRef.current);
    if(current&&value>=current.end){setPosition(current.end-1);setRequested(current.end-1);setPlaying(false)}else setPosition(value);
  };
  const avActive=audioEnabled&&playing&&canPlay&&!scrubbing;
  const jpeg=useViewerStream({camera,mode,playing:playing&&canPlay&&!audioEnabled,position:requested,revision,speed,onPosition:onMediaPosition});
  const native=useNativeAv({camera,mode,position:requested,speed:mode==='live'?100:speed,revision,enabled:avActive,canvas,onPosition:onMediaPosition});
  const stream=avActive?native:jpeg;
  const toggleAudio=async()=>{try{if(!audioEnabled)await native.prepareAudio();setAudioEnabled(!audioEnabled);setRequested(position);setRevision(v=>v+1)}catch(error){setLoadError(error.message)}};
  const events = data.events.length ? data.events.map(event=>event.start) : data.recordings.map(clip=>clip.start);
  const previous = events.filter(value=>value < position-1000).at(-1), next = events.find(value=>value > position+1000);
  const span=Math.min(zoom,Math.max(1,axis.duration));
  const beginScrub=()=>{clearTimeout(previewTimer.current);resumeAfterScrub.current=playing;setScrubbing(true);setPlaying(false)};
  const scrub=(value,visibleSpan)=>{setPosition(value);setZoom(visibleSpan);clearTimeout(previewTimer.current);previewTimer.current=setTimeout(()=>{setRequested(value);setRevision(v=>v+1)},250)};
  const finishScrub=value=>{clearTimeout(previewTimer.current);seek(value,scrubbing?resumeAfterScrub.current:playing);setScrubbing(false)};
  const noRecording = mode === 'playback' && !loading && !recording;
  const changeDay = value => { try { const range = dayBounds(value); if (value > localDate()) return; wantInitial.current = true; setDay(value); setPosition(range.start); setRequested(range.start); setAnchor(range.start); setPlaying(false); setRevision(value=>value+1); } catch {} };
  return <div className={`apk-viewer ${mode === 'playback' ? 'with-playback' : ''}`}>
    <header className="viewer-header"><IconButton label="Back to cameras" onClick={onBack}><ArrowLeft size={24}/></IconButton><div><h1>{camera.name}</h1><p>{camera.siteName} · {index+1} / {cameras.length}</p></div><div className="viewer-modes"><button className={mode==='live'?'selected':''} onClick={()=>{setMode('live');setPlaying(true);setRevision(value=>value+1)}}>Live</button><button className={mode==='playback'?'selected':''} onClick={goPlayback}>Playback</button></div><IconButton label={fullscreen?'Exit fullscreen':'Fullscreen camera'} onClick={()=>{(document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()).then(()=>setFullscreen(!!document.fullscreenElement)).catch(()=>{})}}>{fullscreen?<Minimize size={18}/>:<Maximize size={18}/>}</IconButton></header>
    <div className="viewer-tools"><button className={audioEnabled?'selected':''} aria-label={audioEnabled?'Mute audio':'Enable audio'} disabled={mode==='live'&&!camera.audio} onClick={toggleAudio}>{audioEnabled?<Volume2 size={16}/>:<VolumeX size={16}/>}Audio</button>{mode==='live'&&camera.ptz&&<button aria-pressed={ptzOpen} onClick={()=>setPtzOpen(!ptzOpen)}><Move size={16}/>PTZ</button>}{mode==='playback'&&<button disabled={loading||!data.recordings.length} onClick={()=>setExportOpen(true)}><Download size={16}/>Export MP4</button>}<small>{audioEnabled?(mode==='playback'&&speed!==100?'Audio at 1� speed':native.audio===false?'No audio supplied':'Audio enabled'):'Pinch video to zoom'}</small></div>
    {mode==='playback'&&<div className="viewer-date"><label><CalendarDays size={18}/><span>{new Date(`${day}T12:00:00`).toLocaleDateString([],{weekday:'short',month:'short',day:'numeric'})}</span><input type="date" aria-label="Recording date" value={day} max={localDate()} onChange={event=>changeDay(event.target.value)}/></label><span>Device time</span><IconButton label="Reload recordings" onClick={()=>{setRequested(position);setDayRevision(value=>value+1);setRevision(value=>value+1)}}><RefreshCw size={18}/></IconButton></div>}
    <div className="viewer-video" tabIndex={0} aria-label="Camera video" onKeyDown={event=>{if(event.key==='ArrowLeft'){event.preventDefault();move(-1)}if(event.key==='ArrowRight'){event.preventDefault();move(1)}}}>
      <VideoZoom cameraKey={camera.key} onSwipe={move}>
        {!avActive&&jpeg.url&&<img src={jpeg.url} alt={`${camera.name} ${mode==='playback'?'recorded':'live'} video`}/>}
        <canvas ref={canvas} className="native-video" aria-label="Camera video with audio" style={{display:avActive?'block':'none'}}/>
      </VideoZoom>
      {mode==='live'&&camera.ptz&&ptzOpen&&<PtzControls key={camera.key} camera={camera}/>}
      <button className="camera-step previous" aria-label="Previous camera" disabled={index===0} onClick={()=>move(-1)}><ChevronLeft size={30}/></button><button className="camera-step next" aria-label="Next camera" disabled={index===cameras.length-1} onClick={()=>move(1)}><ChevronRight size={30}/></button>
      {(loading || (stream.status==='connecting'&&!stream.url&&!noRecording))&&<div className="video-state"><LoaderCircle className="spin" size={28}/><span>{loading?'Loading recordings…':'Connecting video…'}</span></div>}
      {stream.status==='recovering'&&<div className="recovery-status" role="status"><LoaderCircle size={16} className="spin"/>Reconnecting {stream.attempt || 1} / 3 · holding your position</div>}
      {(loadError||noRecording||stream.error)&&!loading&&<div className="video-overlay"><AlertCircle size={23}/><strong>{loadError?'Recordings unavailable':noRecording?'No recording at this time':'Video interrupted'}</strong><p>{loadError||(!noRecording&&stream.error)||'Choose another time or recording.'}</p>{noRecording&&data.recordings.length>0?<button className="button primary" onClick={()=>seek(data.recordings.reduce((best,clip)=>Math.abs(clip.start-position)<Math.abs(best.start-position)?clip:best).start)}>Jump to nearest recording</button>:!loadError&&!noRecording&&<button className="button primary" onClick={()=>{const cursor=stream.currentPosition();seek(cursor,true);stream.reconnect()}}>Resume from here</button>}</div>}
      <span className="viewer-hint">Swipe to change camera</span>{mode==='live'&&<span className={`viewer-live-badge ${stream.status==='ready'?'ready':''}`}>{!playing?'PAUSED':stream.status==='ready'?'LIVE':stream.status==='recovering'?'RECONNECTING':'CONNECTING'}</span>}
    </div>
    {mode==='live'?<div className="live-view-controls"><button className="button secondary" onClick={()=>{setRequested(position);setPlaying(!playing)}}>{playing?<Pause size={16}/>:<Play size={16}/>} {playing?'Pause':'Resume'}</button><span>Live video · {camera.siteName}</span></div>:<section className="playback-panel">
      <div className="playback-heading"><time aria-label="Playback position">{time(position,true)}</time><select aria-label="Timeline range" value={zoom} onChange={event=>setZoom(Number(event.target.value))}>{[30000,60000,300000,900000,1800000,3600000,7200000,21600000,bounds.end-bounds.start].map((value,index)=><option key={index} value={value}>{['30s','1m','5m','15m','30m','1h','2h','6h','Full day'][index]}</option>)}{![30000,60000,300000,900000,1800000,3600000,7200000,21600000,bounds.end-bounds.start].includes(zoom)&&<option value={zoom}>{Math.round(zoom/1000)}s</option>}</select><button className="go-live" onClick={()=>{setMode('live');setPlaying(true)}}>Go live</button></div>
      <button className={`motion-filter ${motionOnly?"selected":""}`} aria-pressed={motionOnly} onClick={()=>{const enabled=!motionOnly;setMotionOnly(enabled);if(enabled){const compressed=motionAxis(data,bounds);if(compressed.duration){const target=compressed.snap(position);setPosition(target);setRequested(target);setRevision(v=>v+1)}}}}>Motion only</button><GestureTimeline data={data} axis={axis} position={position} span={span} motionOnly={motionOnly} onBegin={beginScrub} onScrub={scrub} onFinish={finishScrub} onScale={setZoom}/>{motionOnly&&!axis.duration&&<p role="status" className="events-note">{data.eventsAvailable?"No motion or person windows in the listed recordings.":"Motion-only playback needs alert metadata. Switch to all footage."}</p>}
      <div className="timeline-legend"><span><i className="recorded"/>Recorded</span><span><i className="motion"/>Motion</span><span><i className="person"/>Person</span><span><i className="alert"/>Other alert</span><span><i className="gap"/>Gap</span></div>
      {!data.eventsAvailable&&<p className="events-note">Recording playback is available; this account could not load alert markers.</p>}
      <div className="playback-controls"><IconButton label="Previous event" disabled={previous===undefined} onClick={()=>seek(previous)}><SkipBack size={22}/></IconButton><button className="skip-button" aria-label="Back ten seconds" disabled={!data.recordings.length} onClick={()=>seek(position-10000)}><RotateCcw size={25}/><small>10</small></button><button className="playback-toggle" aria-label={playing?'Pause playback':'Resume playback'} disabled={!canPlay} onClick={()=>{setRequested(position);setPlaying(!playing);setRevision(value=>value+1)}}>{playing?<Pause size={24}/>:<Play size={24}/>}</button><button className="skip-button" aria-label="Forward ten seconds" disabled={!data.recordings.length} onClick={()=>seek(position+10000)}><RotateCw size={25}/><small>10</small></button><IconButton label="Next event" disabled={next===undefined} onClick={()=>seek(next)}><SkipForward size={22}/></IconButton><select aria-label="Playback speed" value={speed} onChange={event=>{setRequested(position);setSpeed(Number(event.target.value));setRevision(value=>value+1)}}><option value={50}>0.5×</option><option value={100}>1×</option><option value={200}>2×</option><option value={400}>4×</option></select></div>
      <div className="desktop-recording-label">Recordings<span>{data.recordings.length} clips</span></div><div className="recording-list" role="region" aria-label="Recordings list" tabIndex={0}>{[...data.recordings].reverse().slice(0,listCount).map(clip=><button key={clip.path} className={recording?.path===clip.path?'current':''} onClick={()=>seek(clip.start,true)}><Play size={16}/><span>{time(clip.start)} – {time(clip.end)}</span><small>{Math.max(1,Math.round(clip.duration/60000))} min</small></button>)}{data.recordings.length>listCount&&<button onClick={()=>setListCount(listCount+20)}>Show more recordings</button>}</div>
    </section>}
    {exportOpen&&<ClipExportDialog camera={camera} playhead={position} data={data} onClose={()=>setExportOpen(false)}/>}
  </div>;
}

