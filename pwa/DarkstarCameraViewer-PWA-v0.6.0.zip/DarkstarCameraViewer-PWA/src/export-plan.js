export function planExport(data,{start,end,motion=false,before=5000,after=5000}) {
  if(![start,end,before,after].every(Number.isSafeInteger)||start<946684800000||end<=start||end-start>86400000||before<0||before>60000||after<0||after>60000)throw new Error('Choose a positive range up to 24 hours and context from 0 to 60 seconds.');
  if(motion&&!data.eventsAvailable)throw new Error('Motion metadata is unavailable for this camera/date.');
  const ranges=motion?data.events.filter(e=>['motion','person'].includes(e.kind)&&e.start<end&&e.start+e.duration>start).map(e=>({start:Math.max(start,e.start-before),end:Math.min(end,e.start+e.duration+after)})).sort((a,b)=>a.start-b.start):[{start,end}];
  const merged=[];
  for(const range of ranges){const last=merged.at(-1);if(last&&range.start<=last.end)last.end=Math.max(last.end,range.end);else merged.push({...range})}
  const pieces=[];
  for(const range of merged){let cursor=range.start;const eligible=data.recordings.filter(c=>c.end>range.start&&c.start<range.end).sort((a,b)=>a.start-b.start);
    while(cursor<range.end){const clip=eligible.filter(c=>c.start<=cursor&&c.end>cursor).sort((a,b)=>Number(/\.bvr$/i.test(b.path))-Number(/\.bvr$/i.test(a.path))||b.end-a.end)[0];
      if(!clip){const next=eligible.find(c=>c.start>cursor);if(!next)break;cursor=next.start;continue}
      const stop=Math.min(range.end,clip.end);pieces.push({clip,start:cursor,end:stop});cursor=stop;
    }
  }
  if(!pieces.length)throw new Error(motion?'No recorded motion/person events overlap this range.':'No listed recordings overlap this range.');
  if(pieces.length>100)throw new Error('More than 100 clip pieces. Narrow the time range.');
  return pieces;
}
export function localTimestamp(ms){const d=new Date(ms);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}T${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}.${String(d.getMilliseconds()).padStart(3,'0')}`}
