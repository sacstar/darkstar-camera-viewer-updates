import { spawn } from 'node:child_process';
import { readFile, writeFile, rename, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

export async function dpapi(action, data) {
  if (process.platform !== 'win32') throw new Error('This local gateway requires Windows protected credential storage.');
  const script = await readFile(new URL('./vault.ps1', import.meta.url), 'utf8');
  return new Promise((resolve, reject) => {
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let output = ''; const timer = setTimeout(() => { child.kill(); reject(new Error('Credential vault timed out.')); }, 15000);
    child.stdout.setEncoding('utf8'); child.stdout.on('data', data => { output += data; });
    child.stderr.on('data', () => {});
    child.on('error', () => { clearTimeout(timer); reject(new Error('Windows credential storage is unavailable.')); });
    child.on('close', code => { clearTimeout(timer); code === 0 ? resolve(output) : reject(new Error('Windows could not open or protect the local settings vault.')); });
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify({ action, data }));
  });
}

export class Vault {
  constructor(directory = fileURLToPath(new URL('../.local', import.meta.url))) { this.directory = directory; this.file = join(directory, 'vault.json'); this.state = { sites: [], layouts: [] }; this.tail = Promise.resolve(); }
  async open() {
    let content;
    try { content = await readFile(this.file, 'utf8'); } catch (error) { if (error.code === 'ENOENT') return; throw error; }
    const envelope = JSON.parse(content);
    if (envelope.version !== 1 || typeof envelope.protected !== 'string') throw new Error('Invalid settings vault.');
    const state = JSON.parse(await dpapi('unprotect', envelope.protected));
    if (!Array.isArray(state.sites) || !Array.isArray(state.layouts)) throw new Error('Invalid settings vault.');
    this.state = state;
  }
  update(change) {
    const task = this.tail.then(async () => {
      const next = structuredClone(this.state);
      const result = await change(next);
      const protectedData = await dpapi('protect', JSON.stringify(next));
      await mkdir(this.directory, { recursive: true });
      const temporary = `${this.file}.tmp`;
      await writeFile(temporary, JSON.stringify({ version: 1, protected: protectedData }), { mode: 0o600 });
      await rename(temporary, this.file);
      this.state = next;
      return result;
    });
    this.tail = task.catch(() => {});
    return task;
  }
}
