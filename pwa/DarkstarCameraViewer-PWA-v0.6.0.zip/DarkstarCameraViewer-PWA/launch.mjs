import { spawn } from 'node:child_process';
import { mkdir, open, writeFile, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

if (Number(process.versions.node.split('.')[0]) < 22) { console.error('Darkstar requires Node.js 22 or newer. Install it from https://nodejs.org and try again.'); process.exit(1); }

const root = fileURLToPath(new URL('./', import.meta.url));
const origin = `http://127.0.0.1:${Number(process.env.DARKSTAR_PORT || 47831)}`;
const check = async () => {
  try { const response = await fetch(origin, { signal: AbortSignal.timeout(1000) }); await response.body?.cancel(); return /^0\.[12345]\./.test(response.headers.get('x-darkstar-gateway') || ''); } catch { return false; }
};
if (process.argv.includes('--stop')) {
  if (!await check()) { console.log('Darkstar is not running on its local port.'); process.exit(0); }
  const response = await fetch(origin);
  const cookie = response.headers.get('set-cookie').split(';')[0]; await response.body?.cancel();
  const stopped = await fetch(`${origin}/api/shutdown`, { method: 'POST', headers: { Cookie: cookie, Origin: origin, 'Content-Type': 'application/json' }, body: '{}' });
  if (!stopped.ok) throw new Error('The gateway could not be stopped.');
  await stopped.body?.cancel();
  for (let attempt = 0; attempt < 30 && await check(); attempt++) await delay(100);
  if (await check()) throw new Error('The gateway has not finished stopping.');
  console.log('Darkstar gateway stopped.');
} else {
  if (!await check()) {
    await mkdir(join(root, '.local'), { recursive: true });
    const output = await open(join(root, '.local/gateway.log'), 'a');
    const errors = await open(join(root, '.local/gateway-error.log'), 'a');
    const child = spawn(process.execPath, ['server/index.mjs'], { cwd: root, detached: true, windowsHide: true, stdio: ['ignore', output.fd, errors.fd] });
    child.unref(); await output.close(); await errors.close();
    await writeFile(join(root, '.local/runtime.json'), JSON.stringify({ pid: child.pid, url: origin }));
    let ready = false;
    for (let attempt = 0; attempt < 40; attempt++) { await delay(250); if (await check()) { ready = true; break; } }
    if (!ready) { console.error('Darkstar could not start. Check the local gateway log or whether its port is already in use.'); process.exit(1); }
  }
  console.log(`Darkstar is ready: ${origin}`);
  if (!process.argv.includes('--no-browser')) {
    let browser;
    if (process.argv.includes('--app')) {
      const candidates = [join(process.env.ProgramFiles || 'C:/Program Files','Google/Chrome/Application/chrome.exe'), join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe'), join(process.env['ProgramFiles(x86)'] || 'C:/Program Files (x86)', 'Microsoft/Edge/Application/msedge.exe'), join(process.env.ProgramFiles || 'C:/Program Files', 'Microsoft/Edge/Application/msedge.exe')];
      for (const candidate of candidates) { try { await access(candidate); browser = candidate; break; } catch {} }
    }
    const child = spawn(browser || 'explorer.exe', browser ? [`--app=${origin}`] : [origin], { windowsHide: true, detached: true, stdio: 'ignore' }); child.on('error', () => {}); child.unref();
  }
}
