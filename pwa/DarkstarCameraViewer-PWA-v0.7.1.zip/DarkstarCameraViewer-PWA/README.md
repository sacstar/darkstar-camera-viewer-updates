# Darkstar Camera Viewer PWA 0.7.1 — Desktop edition

## Gateway repair and visible version in 0.7.1

The header and camera-wall toolbar show v0.7.1. If an older gateway is already running, Start stops with repair instructions rather than silently opening that older app. Run **Repair-Darkstar.cmd** from the new package, choose **Update an existing PWA folder**, then select your original installation folder. It backs up the encrypted vault, replaces app files, and restarts the gateway. The alternative restarts this folder without copying app files. Existing settings and the original vault remain intact. An unrelated service on the port is not stopped. Refresh open browser windows after repair.

## Startup fix retained from 0.6.1

The launcher and Windows Stop shortcut now recognize current and future gateway versions. Version 0.6.0 could start the server successfully but still report a startup failure because those checks only recognized versions 0.1 through 0.5. Replace the app files while keeping .local, then run Start-Darkstar.cmd again. Do not uninstall Node.js or delete saved settings for this error.

## Drag cameras and save custom layouts

Choose an existing saved view, then **Arrange** above the grid. Drag each tile by its dotted handle; dragging near the top/bottom edge scrolls the grid. Mouse and touch are supported. Focus a handle and use arrow keys to move one position, or Home/End to move to the beginning/end. Escape cancels an active drag. Touching elsewhere on the grid still scrolls normally.

Change the grid preset or Custom rows/columns while arranging, then **Save layout** to save both camera order and grid dimensions. **Cancel arrangement** leaves the saved view unchanged. **Save as new layout** creates a separate named copy. Switching views/navigation with an unfinished arrangement asks before discarding it.

From All cameras, **Create layout** opens the visual editor with up to the first 36 matching cameras selected. Add/remove cameras across sites, choose 1–12 visible rows and columns, drag the panel cards, name it, and **Save view**. Up to 50 saved views and 1,000 cameras per view are supported. The editor wraps to two preview columns on narrow screens for usable controls; the saved column count is applied on the camera grid. Cameras retain the existing viewport-only preview loading behavior.

For updates from 0.6.0, first copy the release contents into the existing installation folder. Then run the corrected Stop-Darkstar.cmd followed by Start-Darkstar.cmd. Keep the existing .local folder and its vault.json; do not delete it or replace it with another account's vault. Refresh the browser after restarting. This GitHub package includes source and built frontend files. It is a Windows local-gateway PWA, not a publicly hosted camera dashboard.

## Audio, PTZ, video zoom and stitched MP4 export

Select a camera and tap Audio for live or recorded H.264 video with sound. Use current Edge or Chrome with WebCodecs; audio plays at 1x speed. Audio off retains the JPEG viewer. A source without recorded audio cannot supply sound. Pinch video from 1x to 8x, pan while zoomed, and double tap or use Reset to return to 1x. Camera swipes navigate while zoomed out. PTZ controls appear when Blue Iris advertises support; tap to nudge, go Home, or Stop. These server flags may include virtual PTZ. Commands are sent once without replaying on another endpoint.

Playback's Export MP4 opens precise device-time start/end fields with millisecond entry, 0.1s/1s adjustment buttons and playhead shortcuts. Choose the main recorded stream or recorded substream, full range or motion/person events, and before/after context. Audio is requested and sample tables are checked before saving. Missing audio blocks the export unless you explicitly allow video-only output.

Multiple recording/event pieces are stitched chronologically into ONE MP4 with audio, without re-encoding matching codecs/resolution. Quiet gaps between selected events are removed. A recording format change produces a clear error instead of joining incompatible streams. Native Blue Iris keyframe alignment can extend or shift requested boundaries; millisecond input does not guarantee frame accuracy. Exports preserve the recorded codec, including H.265 when recorded. Each browser/player must support that codec.

Choose MP4 save location uses the system file picker in supported browsers. Other browsers use a normal download and their configured download folder. Cancelling the picker retains the prepared export. Save before restarting the gateway; exports are session-scoped and cached privately under .local/exports. Stale folders older than 24 hours are removed when another export starts. Share MP4 is available for files up to 200 MB where Web Share supports files; otherwise save and attach the file in your preferred app. Browser activation rules and recipient attachment support still apply.

The first stitched export automatically downloads a SHA-256-verified Windows x64 FFmpeg runtime from the pinned imageio-ffmpeg 0.7.0 PyPI wheel into %LOCALAPPDATA%/DarkstarCameraViewer/runtime/media. No Python or administrator rights are required. Internet access and approximately 90 MB of runtime disk space are needed once. The runtime stays outside the source ZIP. Run ensure-media.ps1 to install it ahead of time. On other platforms set DARKSTAR_FFMPEG to an installed FFmpeg executable; this app's credential vault still requires Windows.

## Transfer Android sites and settings

The header's Transfer sites and settings button imports encrypted backups from Android v0.4.0 or another PWA installation. Choose the backup JSON, enter its transfer passphrase, select Review import, then Merge or Replace configuration. Merge retains other destination sites/views and updates matching IDs; imported grid/view preferences take priority. Replace removes the current configuration, so export it first if needed.

The same dialog exports selected site logins, local/WAN addresses, colors, site priority, grid/view preferences and camera layouts. Select which sites to include; camera references to excluded sites are removed, and selecting none exports display settings only. Quick share prepares an encrypted file; Share prepared backup opens supported OS share sheets. If the browser or recipient app cannot share JSON attachments, download and attach the file yourself. Use a passphrase of 12-256 characters and confirm it for export. The shared format works in Android and PWA v0.4.0+. Preserve .local when updating an existing installation.

Backups use the shared darkstar-viewer-backup v1 envelope: PBKDF2-HMAC-SHA256, 210,000 iterations, random 16-byte salt, AES-256-GCM, random 12-byte IV, and fixed authenticated format context. Limits are 24 sites, 50 views, 1,000 camera references per view and a 2 MB encrypted file. PWA display mode and tile sizing travel with the backup; Android preserves those values for a later PWA import. Android-only camera grid behavior remains native to Android.

Includes QR setup import, local/WAN fallback, fixed-center drag/zoom timeline and motion-only playback. This PWA package does not replace or update the Android APK.

## Save and open

On the configured workstation, the **Darkstar Camera Viewer** desktop shortcut starts the local gateway and opens an app-style Chrome window (or Edge if Chrome is unavailable). It is a saved Windows shortcut; browser-managed PWA registration is optional and has not been claimed as automatically performed.

For a clean installation, extract the entire package into a writable folder and run **Setup-Darkstar.cmd**. It checks the app files, finds Node.js 22+ with npm, installs missing prerequisites, creates the Desktop shortcut, and opens the app. Internet access is needed for the first install.

If compatible Node.js/npm is missing, setup installs the latest official Windows LTS ZIP into **%LOCALAPPDATA%\DarkstarCameraViewer\runtime** for the current user after verifying SHA-256 against Node.js's published checksum. It supports x64 and ARM64 Windows 10/11, needs no administrator rights, and leaves global Node.js and system PATH unchanged. Packages install from the lockfile without install scripts. Built browser assets are included.

**Start-Darkstar.cmd** and the Desktop shortcut check/repair prerequisites before opening. **Save-to-Desktop.cmd** checks prerequisites and saves the shortcut without launching. **Check-Prerequisites.cmd** reports readiness without installing anything. **Stop-Darkstar.cmd** stops the gateway without requiring or installing Node.js. Chrome or Edge opens an app-style window; otherwise Windows opens its default browser.

For diagnostics, run `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\bootstrap.ps1 -Action Check`. A `-PrivateRuntime` switch uses only the dedicated runtime cache; `-RuntimeDirectory` overrides that cache location; `-NoInstall` prevents repairs and `-NoBrowser` starts the gateway without a browser. Runtime and downloaded packages are excluded from the clean ZIP; keep .local on updates to preserve settings. If a download is interrupted or verification fails, setup stops with an error and can be rerun.

Chrome/Edge may offer browser installation through Darkstar's Save button or the browser's install controls. A browser-installed shortcut alone cannot start a stopped gateway. Use the provided desktop shortcut for gateway startup when opening the app.

The address is `http://127.0.0.1:47831`. No login task, service, public tunnel, firewall change, or Docker installation is created. The app starts when its launcher is opened.

## Camera groups and monitor windows

Manage groups creates up to 100 named groups containing up to 1,000 cameras each, selected across sites. Groups, ordering and the selected group travel in encrypted settings backups; excluded sites are also removed from group camera lists. Use the monitor button to choose a saved layout and group for a separate window. Each window keeps its selection independently; optional camera-wall mode minimizes controls. Auto-fit uses the number of cameras in that window. Browser placement needs permission and supports manual Windows Snap as a fallback. The Windows software edition uses native monitor discovery. Physical multi-monitor and mixed-DPI behavior still need real-device qualification.

## Desktop workspace

At widths of 1100 pixels or more, a persistent sidebar provides navigation, saved views, quick view editing and site filters. The workspace fills the monitor. Search stays visible; press / outside text fields to focus it. Grids offer Fit screen or 16:9 tile sizing, saved in this browser. In playback, the camera occupies the left pane; timeline and playback controls remain visible in a right panel while only the recording list scrolls. Smaller windows retain the compact responsive layout.

## Dashboard and video

- Cameras, Recordings, and Sites navigation mirrors the APK.
- Presets: 1, 4, 9, 16, 24, 36, 64, 81, 100 and 144 panes; custom grids allow 1-12 rows and columns.
- Named views select and order cameras across sites. PWA 0.1 profiles and views remain compatible.
- Every preset and custom grid scrolls continuously in the vertical direction, with no page arrows. Visible rows set density; a 48-pixel minimum tile height keeps small windows usable. Only tiles intersecting the grid viewport start previews. Offscreen refreshes stop, queued requests are cancelled before starting, and no more than three preview requests run concurrently. An already-issued request may finish. Full camera frames are preserved with letterboxing.
- Previews are the default, matching the APK, and refresh every five seconds. Grid images request the substream when available, with a cached compatibility fallback for older servers. They remain JPEG previews; opening a camera starts live video or playback.
- Enlarged viewing uses only the selected camera. Camera arrows and horizontal swipes navigate within the active view and stop at its boundaries.
- Blue Iris nine-field setup QR import supports image selection and browser camera scanning. Decoding happens locally; imported fields are reviewed before saving. Directory lookup IDs are discarded. Camera scanning needs browser camera permission; its physical-camera path is untested.
- Each site accepts a local address and an optional WAN address (WAN-only is also supported). The Windows gateway prefers local, falls back after transport failures, and probes local again after 60 seconds while using WAN. Network-interface changes reset selection on the next request. Authentication rejection stops fallback, and runtime license hashes reject a mismatched alternate server when both report identity. This changes the gateway upstream route, not phone/browser access to the dashboard.
- The timeline keeps a fixed center playhead. Drag to seek, rest briefly for a debounced preview, release to preserve the prior playing/paused state, pinch to zoom or use the zoom buttons / keyboard + and -. Ranges span 30 seconds to the local day. Motion only joins motion/person windows with five seconds of context, clipped to listed recordings; quiet intervals disappear while real timestamps remain. Playback advances between retained windows and pauses at the last window. Unknown alerts are excluded from motion-only windows.
- Playback includes date selection in device time, timeline seeking, 10-second skips, previous/next event, 0.5x/1x/2x/4x speed, pause/resume, recording selection, 30-second through full-day ranges, and Go live.
- Blue recording coverage has its own lane. Orange means motion, yellow means person detection, and gray means other alerts. Unknown alerts are not labeled motion. Server flags and explicit memo text determine classification; cancelled and zero-confidence person memo classifications are excluded.
- Transient stream failures retry three times with increasing delays. Recording recovery resumes at the last delivered position, excludes disconnected time, and retains the last image. Resume from here is offered after retry exhaustion. Access rejection is not repeatedly retried.

The playhead is an elapsed-time estimate, not a forensic frame timestamp. Clip start and playable duration approximate wall-clock coverage; cut/combine clips may differ. A dark interval means no recording was listed, not independently proven recording absence. The camera timestamp visible in recorded imagery is authoritative. Blue Iris may send preparing-video placeholders. Minimum event-marker widths are visual aids, not exact event durations.

## Settings and privacy

Settings and saved layouts are encrypted for the current Windows account in `.local/vault.json` using DPAPI. Keep this installation's `.local` folder when updating. The vault is not portable to another account or computer. Clean packages exclude saved credentials and camera inventory.

Passwords and upstream Blue Iris sessions stay behind the gateway. Usernames and addresses remain visible in the connection editor. The offline cache excludes credentials, private API responses, and camera images. Requests use session cookies, host/origin checks, no-store media responses, bounded frames, and stream limits. HTTPS certificates are validated and are not bypassed.

The gateway binds to **127.0.0.1 only**. The address works on this workstation, not on a phone or other computer. Remote use needs trusted HTTPS, private routing, and a deliberate authentication/access setup. Do not expose this local-user pilot by binding it to all interfaces or publicly forwarding its port.

## Build and tests

Run `npm ci`, `npm test`, `npm run build`, then `npm start`. The production gateway serves `dist/`; rebuild and reload after frontend changes. The included Node tests cover the protocol, API protections, cross-site views, recording media, recovery/cancellation, event classification, daylight-saving dates, and actual Windows DPAPI storage. See the delivered build-status report for actual browser/server results.

Implementation: React, Vite, Node.js and WebSocket multiplexing. The selected live viewer uses a gateway stream; playback subscriptions keep independent positions. Guardrails: 24 sites, 50 saved views, 1,000 cameras per view, three concurrent preview requests, and 24 overall gateway streams. These are limits, not performance guarantees.

## Limits

One real Blue Iris server was available. Two-site behavior and controlled disconnects use fixtures. Two real remote sites, physical-phone installation and cellular/WAN access remain unverified. Browser-size checks do not prove physical-device behavior.

Physical PTZ motor movement, phone speaker audibility, OS share-sheet recipient delivery, multiple real sites, push notifications, shared-user permissions and remote HTTPS remain unverified or outside this local pilot. Test fixtures verify browser behavior separately from real-server checks. This is not a long-running load certification.

QR decoder: [jsQR](https://github.com/cozmo/jsQR), bundled locally under Apache-2.0. No QR image is uploaded to a decoding service.

Protocol reference: [Blue Iris user manual](https://blueirissoftware.com/BlueIris.PDF). Event flags match the verified Android implementation; third-party UI3 source is not distributed.









