@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0bootstrap.ps1" (
  echo Extract the entire Darkstar ZIP into a folder before running setup.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1" -Action Setup %*
set "DARKSTAR_EXIT=%ERRORLEVEL%"
if not "%DARKSTAR_EXIT%"=="0" pause
exit /b %DARKSTAR_EXIT%
