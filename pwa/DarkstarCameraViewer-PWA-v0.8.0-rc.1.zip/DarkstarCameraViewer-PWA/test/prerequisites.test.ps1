$ErrorActionPreference = 'Stop'
Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'prerequisites.psm1') -Force -DisableNameChecking
$script:passed = 0
function Assert-True($Condition, $Message) { if (-not $Condition) { throw $Message }; $script:passed++ }
function Assert-Throws([scriptblock]$Operation, $Message) { $threw = $false; try { & $Operation } catch { $threw = $true }; Assert-True $threw $Message }
$directory = Join-Path ([IO.Path]::GetTempPath()) ('Darkstar-prerequisites-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $directory | Out-Null
try {
    Assert-True (Test-CompatibleNodeVersion 'v22.0.0') 'Node 22 must be accepted'
    Assert-True (Test-CompatibleNodeVersion 'v26.13.1') 'Newer stable Node must be accepted'
    Assert-True (-not (Test-CompatibleNodeVersion 'v20.0.0')) 'Old Node must be rejected'
    Assert-True (-not (Test-CompatibleNodeVersion 'v26.0.0-rc.1')) 'Prerelease Node must be rejected'
    Assert-True (-not (Test-CompatibleNodeVersion 'garbage')) 'Invalid Node version must be rejected'
    Assert-True ($null -eq (Get-CompatibleNode -Root $directory -PrivateRuntime -RuntimeDirectory (Join-Path $directory 'runtime'))) 'Private-only detection must not fall back to global Node'
    $releases = @(
        [pscustomobject]@{version='v22.10.0';lts='Test';files=@('win-x64-zip','win-arm64-zip')},
        [pscustomobject]@{version='v26.1.0';lts='Test';files=@('win-x64-zip')},
        [pscustomobject]@{version='v28.0.0';lts=$false;files=@('win-x64-zip')},
        [pscustomobject]@{version='v99.0.0/unsafe';lts='Test';files=@('win-x64-zip')}
    )
    Assert-True ((Select-NodeRelease $releases 'x64').Version -eq 'v26.1.0') 'Choose stable supported LTS for x64'
    Assert-True ((Select-NodeRelease $releases 'arm64').Version -eq 'v22.10.0') 'Respect ARM64 availability'
    Assert-Throws { Select-NodeRelease @() 'x64' } 'No suitable LTS must fail closed'
    $archive = Join-Path $directory 'download.zip'
    [IO.File]::WriteAllText($archive, 'Fixture archive data')
    $checksum = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
    Assert-NodeChecksum $archive ($checksum + '  node-test.zip') 'node-test.zip'
    $script:passed++
    Assert-Throws { Assert-NodeChecksum $archive (('0' * 64) + '  node-test.zip') 'node-test.zip' } 'Wrong checksum must reject the download'
    Assert-Throws { Assert-NodeChecksum $archive ($checksum + '  other.zip') 'node-test.zip' } 'Missing exact checksum must be rejected'
    Assert-Throws { Assert-NodeChecksum $archive (($checksum + '  node-test.zip' + "`n") * 2) 'node-test.zip' } 'Ambiguous checksum must be rejected'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    Add-Type -AssemblyName System.IO.Compression
    $traversal = Join-Path $directory 'traversal.zip'
    $zip = [IO.Compression.ZipFile]::Open($traversal, [IO.Compression.ZipArchiveMode]::Create)
    try { $zip.CreateEntry('node-test/../../escape.txt') | Out-Null } finally { $zip.Dispose() }
    Assert-Throws { Expand-NodeRuntime $traversal (Join-Path $directory 'extracted') 'node-test' } 'Archive traversal must fail before extraction'
    Assert-True (-not (Test-Path -LiteralPath (Join-Path $directory 'escape.txt'))) 'Traversal must not create outside files'
    Write-Host "Bootstrap helper checks passed: $script:passed"
} finally {
    $temporaryRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
    $resolved = [IO.Path]::GetFullPath($directory)
    if ($resolved.StartsWith($temporaryRoot, [StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $resolved) -match '^Darkstar-prerequisites-[a-f0-9]{32}$') { Remove-Item -LiteralPath $resolved -Recurse -Force }
}

