import { test } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import http from 'node:http';
import { WebSocket } from 'ws';
import { createGateway } from '../server/gateway.mjs';
import { encryptConfig } from '../server/transfer.mjs';
import { transferFixture, transferPhrase } from './transfer-fixture.mjs';

test('encrypted transfer review exposes no credentials, imports transactionally and rejects wrong passphrases', async () => {
  const f = await fixture();
  try {
    await f.add('Existing');
    const envelope = await encryptConfig(transferFixture, transferPhrase);
    const before = JSON.stringify(f.vault.state);
    const denied = await f.request('transfer/import', 'POST', { envelope, passphrase: 'incorrect-but-long-enough', mode: 'replace' });
    assert.equal(denied.response.status, 400); assert.equal(JSON.stringify(f.vault.state), before);
    const review = await f.request('transfer/review', 'POST', { envelope, passphrase: transferPhrase });
    assert.equal(review.value.sites.length, 2); assert.ok(!JSON.stringify(review.value).includes('fixture-secret'));
    const imported = await f.request('transfer/import', 'POST', { envelope, passphrase: transferPhrase, mode: 'merge' });
    assert.equal(imported.response.status, 200); assert.equal(imported.value.sites.length, 3);
    assert.equal(imported.value.sites[0].id, 'fixture-south'); assert.equal(imported.value.restoredPreferences.rows, 6);
    assert.equal(f.vault.state.sites[1].password, transferFixture.sites[0].password);
    assert.ok(!JSON.stringify(imported.value).includes('fixture-secret'));
    const exported = await f.request('transfer/export', 'POST', { passphrase: transferPhrase, preferences: { rows: 2, columns: 2 } });
    assert.equal(exported.value.format, 'darkstar-viewer-backup');
    await f.request('transfer/import', 'POST', { envelope, passphrase: transferPhrase, mode: 'replace' });
    assert.equal(f.vault.state.sites.length, 2);
  } finally { await f.gateway.close(); }
});

const fixture = async () => {
  const vault = { state: { sites: [], layouts: [] }, async update(change) { const next = structuredClone(this.state); await change(next); this.state = next; } };
  let aborted = 0;
  const controls = { delay: 0 };
  const gateway = createGateway({ vault, clientFactory: profile => ({
    async cameras() { if (controls.delay) await new Promise(resolve => setTimeout(resolve, controls.delay)); if (profile.url.includes('offline.test')) throw new Error('fixture-private-password'); return [{ key: `${profile.id}:front`, siteId: profile.id, id: 'front', name: 'Front entrance', enabled: true, online: true }]; },
    async snapshot() { return Buffer.from([255, 216, 1, 255, 217]); },
    async recordings(id,start,end) { return { recordings:[{path:'fixture',cameraId:id,start,end,duration:end-start}],events:[{start:start+1000,duration:1000,kind:'motion'}],eventsAvailable:true }; },
    async recordedFrame() { return Buffer.from([255,216,2,255,217]); },
    async media(id, live, signal) { let timer; return { body: { async *[Symbol.asyncIterator]() { try { while (!signal.aborted) { yield Buffer.from([255, 216, 1, 255, 217]); await new Promise(resolve => { timer = setTimeout(resolve, 30); signal.addEventListener('abort', resolve, { once: true }); }); } } finally { clearTimeout(timer); aborted++; } } } }; },
    async logout() {}
  }) });
  const origin = await gateway.listen(0);
  const root = await fetch(origin); const cookie = root.headers.get('set-cookie').split(';')[0];
  const request = async (path, method = 'GET', value) => {
    const response = await fetch(`${origin}/api/${path}`, { method, headers: { Cookie: cookie, Origin: origin, 'Content-Type': 'application/json' }, body: value === undefined ? undefined : JSON.stringify(value) });
    return { response, value: await response.json() };
  };
  const add = async name => (await request('sites', 'POST', { name, url: `http://${name.toLowerCase()}.test`, username: 'viewer', password: 'fixture-private-password' })).value;
  return { gateway, origin, cookie, request, add, vault, controls, getAborted: () => aborted };
};

test('gateway rejects unauthenticated calls, foreign origins, and host rebinding', async () => {
  const f = await fixture();
  try {
    assert.equal((await fetch(`${f.origin}/api/state`)).status, 401);
    assert.equal((await fetch(`${f.origin}/api/state`, { headers: { Cookie: f.cookie, Origin: 'https://other.test' } })).status, 403);
    const rebound = await new Promise((resolve, reject) => { http.get(`${f.origin}/api/state`, { headers: { Cookie: f.cookie, Host: 'other.test' } }, response => { response.resume(); resolve(response.statusCode); }).on('error', reject); });
    assert.equal(rebound, 403);
    assert.equal((await fetch(`${f.origin}/api/refresh`, { method: 'POST', headers: { Cookie: f.cookie }, body: '{}' })).status, 403);
    assert.equal((await f.request('state')).response.status, 200);
  } finally { await f.gateway.close(); }
});

test('mixed-site layouts save ordered selections, survive reload, edit and remove correctly', async () => {
  const f = await fixture();
  try {
    await f.add('North'); const state = await f.add('South');
    assert.equal(state.sites.length, 2); assert.ok(!JSON.stringify(state).includes('fixture-private-password'));
    const keys = state.sites.map(site => site.cameras[0].key);
    const saved = await f.request('layouts', 'POST', { name: 'All entrances', cameras: [keys[1], keys[0], keys[1]], columns: 2 });
    assert.equal(saved.response.status, 200); assert.deepEqual(saved.value.layouts[0].cameras, [keys[1], keys[0]]);
    assert.equal((await f.request('state')).value.layouts[0].name, 'All entrances');
    const id = saved.value.savedId;
    await f.request('layouts', 'POST', { id, name: 'Priority doors', cameras: keys, columns: 1 });
    assert.equal((await f.request('state')).value.layouts[0].name, 'Priority doors');
    assert.equal((await f.request('layouts', 'POST', { name: 'Unknown camera', cameras: ['bad:camera'] })).response.status, 400);
    await f.request(`sites/${state.sites[0].id}`, 'DELETE');
    assert.deepEqual((await f.request('state')).value.layouts[0].cameras, [keys[1]]);
    await f.request(`layouts/${id}`, 'DELETE'); assert.equal((await f.request('state')).value.layouts.length, 0);
  } finally { await f.gateway.close(); }
});

test('an offline site does not disrupt connected sites and images are never cacheable', async () => {
  const f = await fixture();
  try {
    await f.add('North'); const state = await f.add('Offline');
    assert.equal(state.sites[0].status, 'online'); assert.equal(state.sites[1].status, 'offline');
    assert.ok(!state.sites[1].error.includes('fixture-private-password'));
    const response = await fetch(`${f.origin}/api/sites/${state.sites[0].id}/cameras/front/image`, { headers: { Cookie: f.cookie } });
    assert.equal(response.status, 200); assert.equal(response.headers.get('cache-control'), 'no-store'); assert.equal(response.headers.get('content-type'), 'image/jpeg');
    assert.equal((await fetch(`${f.origin}/api/sites/${state.sites[0].id}/cameras/arbitrary/image`, { headers: { Cookie: f.cookie } })).status, 404);
  } finally { await f.gateway.close(); }
});

test('one websocket multiplexes two site feeds and releases upstreams when paused', async () => {
  const f = await fixture(); let ws;
  try {
    await f.add('North'); const state = await f.add('South');
    const keys = state.sites.map(site => site.cameras[0].key);
    ws = new WebSocket(`${f.origin.replace('http:', 'ws:')}/live`, { headers: { Cookie: f.cookie, Origin: f.origin } });
    await once(ws, 'open');
    const received = new Set();
    const frames = new Promise((resolve, reject) => { const timeout = setTimeout(() => reject(new Error('No multiplexed frames')), 4000); ws.on('message', (data, binary) => { if (binary) { const length = data.readUInt16BE(0); received.add(JSON.parse(data.subarray(2, 2 + length)).key); if (received.size === 2) { clearTimeout(timeout); resolve(); } } }); });
    ws.send(JSON.stringify({ type: 'subscribe', keys })); await frames;
    assert.equal((await f.request('health')).value.activeStreams, 2);
    ws.send(JSON.stringify({ type: 'subscribe', keys: [] }));
    for (let i = 0; i < 30 && (await f.request('health')).value.activeStreams; i++) await new Promise(resolve => setTimeout(resolve, 20));
    assert.equal((await f.request('health')).value.activeStreams, 0);
    ws.close();
  } finally { ws?.terminate(); await f.gateway.close(); }
});

test('routine refresh keeps healthy sites online while awaiting a response', async () => {
  const f = await fixture();
  try {
    await f.add('North');
    f.controls.delay = 150;
    const refreshing = f.request('refresh', 'POST', {});
    await new Promise(resolve => setTimeout(resolve, 30));
    assert.equal((await f.request('state')).value.sites[0].status, 'online');
    assert.equal((await refreshing).value.sites[0].status, 'online');
  } finally { await f.gateway.close(); }
});

test('recordings and paused frames remain private and saved grids support six rows and columns', async()=>{
  const f=await fixture();
  try{
    const state=await f.add('North'),site=state.sites[0],start=Date.now()-86400000,end=Date.now();
    const result=await f.request(`sites/${site.id}/cameras/front/recordings?start=${start}&end=${end}`);
    assert.equal(result.response.status,200);assert.equal(result.value.recordings.length,1);assert.equal(result.response.headers.get('cache-control'),'no-store');
    assert.equal((await f.request(`sites/${site.id}/cameras/front/recordings?start=${start}&end=${end+86400000}`)).response.status,400);
    const response=await fetch(`${f.origin}/api/sites/${site.id}/cameras/front/frame?position=${start}`,{headers:{Cookie:f.cookie}});assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');assert.equal(response.headers.get('content-type'),'image/jpeg');
    const saved=await f.request('layouts','POST',{name:'Dense grid',cameras:[site.cameras[0].key],rows:6,columns:6});assert.equal(saved.value.layouts[0].rows,6);assert.equal(saved.value.layouts[0].columns,6);
  }finally{await f.gateway.close()}
});

test('playback websocket delivers request-specific positions and rejects invalid speeds',async()=>{
  const f=await fixture();let ws;
  try{
    const state=await f.add('North'),key=state.sites[0].cameras[0].key;
    ws=new WebSocket(`${f.origin.replace('http:','ws:')}/live`,{headers:{Cookie:f.cookie,Origin:f.origin}});await once(ws,'open');
    const waitMessage=()=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('No playback response')),3000);ws.once('message',(value,binary)=>{clearTimeout(timer);resolve({value,binary})})});
    let pending=waitMessage();ws.send(JSON.stringify({type:'playback',key,position:Date.now()-60000,speed:900,requestId:'invalid'}));const denied=await pending;assert.equal(JSON.parse(denied.value).type,'stream-error');
    const position=Date.now()-60000;pending=waitMessage();ws.send(JSON.stringify({type:'playback',key,position,speed:200,requestId:'seek-test'}));const frame=await pending;assert.equal(frame.binary,true);const length=frame.value.readUInt16BE(0),metadata=JSON.parse(frame.value.subarray(2,2+length));assert.equal(metadata.requestId,'seek-test');assert.equal(metadata.mode,'playback');assert.ok(metadata.position>=position);ws.send(JSON.stringify({type:'playback-stop'}));
  }finally{ws?.terminate();await f.gateway.close()}
});
