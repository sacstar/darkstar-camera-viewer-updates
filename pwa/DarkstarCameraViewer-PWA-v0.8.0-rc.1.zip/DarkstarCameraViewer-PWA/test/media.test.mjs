import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdtemp,copyFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import http from 'node:http';
import {once} from 'node:events';
import {WebSocket} from 'ws';
import {BlueParser,muLaw} from '../server/blue-stream.mjs';
import {BlueIrisClient} from '../server/blueiris.mjs';
import {inspectMp4,stitchMp4,ClipExports} from '../server/clip-export.mjs';
import {planExport} from '../src/export-plan.js';
import {selectSites,encryptConfig,decryptConfig} from '../server/transfer.mjs';
import {transferFixture,transferPhrase} from './transfer-fixture.mjs';
import {createGateway} from '../server/gateway.mjs';

const fixture=name=>new URL(`fixtures/${name}`,import.meta.url);
test('Blue audio/video parser handles arbitrary chunk boundaries, timestamps, codec and mu-law',async()=>{
  const bytes=await readFile(fixture('synthetic-blue.bin')),packets=[],parser=new BlueParser((meta,data)=>packets.push({meta,data}));
  for(let at=0;at<bytes.length;at+=17)parser.push(bytes.subarray(at,at+17));
  assert.equal(packets.filter(p=>p.meta.kind==='video').length,30);assert.equal(packets.filter(p=>p.meta.kind==='audio').length,30);
  assert.equal(parser.format.rate,16000);assert.match(packets[0].meta.codec,/^avc1\./);assert.equal(muLaw(Buffer.from([255,127])).readInt16LE(0),0);
  assert.throws(()=>new BlueParser(()=>{}).push(Buffer.alloc(60)));
});
test('motion export merges context and splits at recordings; selected backup removes excluded references',async()=>{
  const start=1700000000000,data={recordings:[{path:'a.bvr',start,end:start+10000},{path:'b.bvr',start:start+10000,end:start+20000}],events:[{kind:'motion',start:start+9000,duration:2000},{kind:'person',start:start+11500,duration:1000}],eventsAvailable:true};
  const pieces=planExport(data,{start,end:start+20000,motion:true,before:1000,after:1000});assert.deepEqual(pieces.map(p=>[p.start-start,p.end-start]),[[8000,10000],[10000,13500]]);
  assert.throws(()=>planExport(data,{start,end:start}),/positive/);
  const filtered=selectSites(transferFixture,[transferFixture.sites[0].id]);assert.equal(filtered.sites.length,1);assert.ok(filtered.settings.views.every(v=>v.cameras.every(key=>key.startsWith(filtered.sites[0].id+':'))));
  assert.deepEqual(await decryptConfig(await encryptConfig(filtered,transferPhrase),transferPhrase),filtered);
});
test('PTZ mutations are sent once and do not fall back; binary clip path preserves literal @',async()=>{
  const seen=[];const mp4=await readFile(fixture('av-fixture.mp4'));
  const server=http.createServer(async(req,res)=>{
    if(req.url.startsWith('/clips/')){seen.push(req.url);res.writeHead(200,{'Content-Type':'video/mp4'});res.end(mp4);return}
    let text='';for await(const part of req)text+=part;const p=JSON.parse(text);seen.push(p);
    let data;if(p.cmd==='login')data=p.response?{result:'success'}:{result:'fail',session:'fixture'};
    else if(p.cmd==='camlist')data={result:'success',data:[{optionValue:'cam',optionDisplay:'Camera',ptz:true,audio:true,width2:640}]};
    else if(p.cmd==='ptz'){req.socket.destroy();return}else data={result:'success',data:[]};
    res.end(JSON.stringify(data));
  });await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{const client=new BlueIrisClient({id:'site',url:`http://127.0.0.1:${server.address().port}`,wanUrl:'http://127.0.0.1:1',username:'fixture',password:'test-only'});const camera=(await client.cameras())[0];assert.ok(camera.ptz&&camera.audio);assert.equal(camera.subWidth,640);
    await assert.rejects(client.ptz('cam',0));assert.equal(seen.filter(p=>p.cmd==='ptz').length,1);
    const connection=await client.exportConnection(),response=await connection.download('\\@clip test.mp4',new AbortController().signal);assert.equal((await response.arrayBuffer()).byteLength,mp4.length);assert.ok(seen.some(p=>typeof p==='string'&&p.startsWith('/clips/@clip%20test.mp4?')));
  }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
});
test('MP4 stitching retains audio and duration; export manager queues once, polls read-only, validates audio',async()=>{
  const folder=await mkdtemp(join(tmpdir(),'darkstar-media-'));
  try{
    const files=[join(folder,'clip-1.mp4'),join(folder,'clip-2.mp4')];for(const file of files)await copyFile(fixture('av-fixture.mp4'),file);
    const details=await stitchMp4(files,join(folder,'joined.mp4'));assert.ok(details.audio);assert.equal(details.width,320);assert.ok(details.duration>5.5);
    const bytes=await readFile(files[0]),start=Date.now()-100000;let queued=0,polls=0;
    const connection={queue:async params=>{queued++;assert.equal(params.audio,true);assert.equal(params.substream,1);return {path:'job',uri:'@export.mp4',status:'queued'}},status:async()=>{polls++;return {status:'done'}},download:async()=>({body:[bytes]})};
    const exports=new ClipExports(join(folder,'exports'),{pollMs:1});
    const job=exports.start({exportConnection:async()=>connection},{id:'cam'},{start,end:start+1000,stream:'sub'},async()=>({recordings:[{path:'a.bvr',start,end:start+10000}],events:[],eventsAvailable:true}));
    await exports.get(job.id).task;assert.equal(exports.get(job.id).status,'ready');assert.equal(queued,1);assert.equal(polls,1);assert.ok((await inspectMp4(exports.get(job.id).file)).audio);await exports.close();
  }finally{await rm(folder,{recursive:true,force:true})}
});
test('gateway authenticates native AV, separates stream metadata, and validates PTZ capability',async()=>{
  const bytes=await readFile(fixture('synthetic-blue.bin')),commands=[];
  const site={id:'fixture',name:'Fixture',url:'http://fixture.invalid',username:'viewer',password:'test-only',color:'#459bff'};
  const vault={state:{sites:[site],layouts:[]},async update(change){await change(this.state)}};
  const gateway=createGateway({vault,clientFactory:()=>({cameras:async()=>[{key:'fixture:cam',siteId:'fixture',id:'cam',name:'Camera',enabled:true,ptz:true,audio:true}],avMedia:async()=>({body:[bytes]}),ptz:async(...args)=>commands.push(args),logout:async()=>{}})});
  const origin=await gateway.listen(0);
  try {
    const root=await fetch(origin),cookie=root.headers.get('set-cookie').split(';')[0];await root.body.cancel();
    await fetch(origin+'/api/refresh',{method:'POST',headers:{Cookie:cookie,Origin:origin},body:'{}'}).then(r=>r.json());
    const sent=await fetch(origin+'/api/ptz',{method:'POST',headers:{Cookie:cookie,Origin:origin},body:JSON.stringify({key:'fixture:cam',button:0})});assert.equal(sent.status,200);assert.deepEqual(commands,[['cam',0]]);
    const ws=new WebSocket(origin.replace('http:','ws:')+'/live',{headers:{Cookie:cookie,Origin:origin}});await once(ws,'open');
    const packets=[];const ended=new Promise(resolve=>ws.on('message',(data,binary)=>{if(binary){const n=data.readUInt16BE(0);packets.push(JSON.parse(data.toString('utf8',2,2+n)))}else if(JSON.parse(data).type==='stream-ended')resolve()}));
    ws.send(JSON.stringify({type:'av',key:'fixture:cam',mode:'live',speed:100,requestId:'fixture-request'}));await ended;assert.equal(packets.length,60);assert.ok(packets.every(p=>p.av&&p.requestId==='fixture-request'));ws.close();await once(ws,'close');
  }finally{await gateway.close()}
});
test('grid previews prefer substream and cache only a successful main-stream compatibility fallback',async()=>{
  const seen=[];const server=http.createServer(async(req,res)=>{
    if(req.url.startsWith('/image/')){seen.push(req.url);if(req.url.includes('decode=-1')){res.writeHead(422);res.end();return}res.writeHead(200,{'Content-Type':'image/jpeg'});res.end(Buffer.from([255,216,1,255,217]));return}
    let text='';for await(const bytes of req)text+=bytes;const p=JSON.parse(text);res.end(JSON.stringify(p.response?{result:'success'}:{result:'fail',session:'fixture'}));
  });await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{const client=new BlueIrisClient({id:'site',url:`http://127.0.0.1:${server.address().port}`,username:'fixture',password:'test-only'});await client.snapshot('cam');await client.snapshot('cam');assert.equal(seen.length,3);assert.ok(seen[0].includes('decode=-1'));assert.ok(!seen[1].includes('decode=-1')&&!seen[2].includes('decode=-1'))}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
});
