import test from 'node:test';
import assert from 'node:assert/strict';
import {createGateway} from '../server/gateway.mjs';
import {configFromVault,encryptConfig,decryptConfig,applyConfig,selectSites} from '../server/transfer.mjs';
import {windowSettings} from '../src/multi-window.js';

test('large layouts, cross-site groups, filtering backups and legacy vaults remain compatible',async()=>{
 const sites=['north','south'].map(id=>({id,name:id,url:'http://fixture.test',wanUrl:'',username:'fixture',password:'fixture-only',color:'#459bff'}));
 const vault={state:{sites,layouts:[]},async update(change){const next=structuredClone(this.state);change(next);this.state=next;}};
 const gateway=createGateway({vault,clientFactory:site=>({async cameras(){return Array.from({length:600},(_,i)=>({key:`${site.id}:c${i}`,id:`c${i}`,siteId:site.id,name:`Camera ${i}`,enabled:true,online:true}))},async logout(){}})});
 const origin=await gateway.listen(0),root=await fetch(origin),cookie=root.headers.get('set-cookie').split(';')[0];await root.body.cancel();
 const request=async(path,body,method='POST')=>{const response=await fetch(`${origin}/api/${path}`,{method,headers:{Cookie:cookie,Origin:origin,'Content-Type':'application/json'},...(method==='GET'?{}:{body:JSON.stringify(body||{})})});return{status:response.status,value:await response.json()};};
 try{
  const initial=await request('refresh',{});assert.deepEqual(initial.value.groups,[]);
  const keys=initial.value.sites.flatMap(s=>s.cameras.map(c=>c.key));
  const layout=await request('layouts',{name:'Large view',cameras:keys.slice(0,1000),rows:12,columns:12});assert.equal(layout.status,200);assert.equal(layout.value.layouts[0].cameras.length,1000);assert.equal(layout.value.layouts[0].columns,12);
  assert.equal((await request('layouts',{name:'Too many',cameras:keys.slice(0,1001)})).status,400);
  const group=await request('groups',{name:'Entrances across sites',cameras:[keys[0],keys[600]]});assert.equal(group.status,200);const id=group.value.savedId;
  assert.equal((await request('groups',{name:'Bad reference',cameras:['unknown:camera']})).status,400);
  await request('groups',{id,name:'Priority entrances',cameras:[keys[600],keys[0]]});assert.deepEqual(vault.state.groups[0].cameras,[keys[600],keys[0]]);
  const config=configFromVault(vault.state,{rows:12,columns:12,groupFilter:id}),envelope=await encryptConfig(config,'a-long-fixture-passphrase');
  const restored=await decryptConfig(envelope,'a-long-fixture-passphrase');assert.equal(restored.settings.pwa.activeGroup,id);assert.deepEqual(restored.settings.pwa.groups[0].cameras,[keys[600],keys[0]]);
  const target={sites:[],layouts:[]};applyConfig(target,restored,true);assert.equal(target.groups[0].name,'Priority entrances');assert.equal(target.transferPreferences.groupFilter,id);
  const selected=selectSites(config,['north']);assert.deepEqual(selected.settings.pwa.groups[0].cameras,[keys[0]]);
  await request(`sites/north`,{},'DELETE');assert.deepEqual(vault.state.groups[0].cameras,[keys[600]]);
  assert.equal((await request(`groups/${id}`,{},'DELETE')).value.groups.length,0);
 }finally{await gateway.close();}
});

test('monitor windows isolate preferences and encode independent initial view/group choices',()=>{
 const local={activeId:'main',rows:4,columns:4,groupFilter:'main-group'};
 const main=windowSettings('',local);assert.equal(main.storage,'local');assert.equal(main.preferences,local);
 const child=windowSettings('?window=monitor-a&view=entrances&group=doors&wall=1',local);assert.equal(child.storage,'session');assert.equal(child.key,'darkstar-window-monitor-a');assert.equal(child.preferences.activeId,'entrances');assert.equal(child.preferences.groupFilter,'doors');assert.equal(child.preferences.wallMode,true);
 const second=windowSettings('?window=monitor-b',local);assert.equal(second.preferences.activeId,null);assert.equal(second.preferences.groupFilter,'all');assert.notEqual(second.key,child.key);
 const reopened=windowSettings('?window=monitor-a&view=entrances',local,{activeId:'yard',rows:8});assert.equal(reopened.preferences.activeId,'yard');assert.equal(reopened.preferences.rows,8);assert.equal(local.activeId,'main');
});
