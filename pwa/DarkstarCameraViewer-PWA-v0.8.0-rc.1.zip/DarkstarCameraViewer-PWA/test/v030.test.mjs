import {test} from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {parseBlueIrisSetup} from '../src/setup-qr.js';
import {TimelineAxis,motionAxis,draggedOffset,zoomedSpan} from '../src/timeline-axis.js';
import {BlueIrisClient,CameraError,cleanProfile} from '../server/blueiris.mjs';

test('native nine-field QR imports TLS routes and credentials without retaining directory identity',()=>{
  const raw=['Blue','Fixture','directory-private','0','127.0.0.1:81','1','wan.example.test','viewer','fixture-pass'].join('\r');
  for(const text of [raw,raw.replaceAll('\r','\n'),raw.replaceAll('\r','\r\n')+'\r\n']){
    const result=parseBlueIrisSetup(text);assert.equal(result.url,'http://127.0.0.1:81');assert.equal(result.wanUrl,'https://wan.example.test');assert.equal(result.password,'fixture-pass');assert.ok(!JSON.stringify(result).includes('directory-private'));
  }
  assert.throws(()=>parseBlueIrisSetup(raw.replace('wan.example.test','http://wan.example.test')));
  assert.throws(()=>parseBlueIrisSetup(raw.replace('127.0.0.1:81','user:pass@127.0.0.1:81')));
  assert.throws(()=>parseBlueIrisSetup('not a setup code'));
  assert.throws(()=>parseBlueIrisSetup('x'.repeat(8193)));
  const profile=cleanProfile({name:'WAN only',url:'',wanUrl:'https://wan.test',username:'viewer',password:'x'});assert.equal(profile.url,'');assert.equal(profile.wanUrl,'https://wan.test');
});
test('motion axis intersects coverage, merges context and maps joins to real timestamps',()=>{
  const bounds={start:100000,end:200000},data={eventsAvailable:true,recordings:[{start:100000,end:130000},{start:150000,end:200000}],events:[{start:110000,duration:1000,kind:'motion'},{start:114000,duration:2000,kind:'person'},{start:145000,duration:2000,kind:'motion'},{start:180000,duration:1000,kind:'alert'}]};
  const axis=motionAxis(data,bounds);assert.deepEqual(axis.sections,[{start:105000,end:121000,offset:0},{start:150000,end:152000,offset:16000}]);assert.equal(axis.duration,18000);assert.equal(axis.epochAt(16000),150000);assert.equal(axis.offsetOf(140000),16000);assert.equal(axis.snap(140000),150000);assert.equal(axis.epochAt(axis.duration),151999);assert.deepEqual(axis.project(115000,151000),[{start:10000,end:16000},{start:16000,end:17000}]);assert.equal(motionAxis({...data,eventsAvailable:false},bounds).duration,0);
});
test('drag direction, zoom bounds and full-day axes preserve fixed-center semantics',()=>{
  const axis=new TimelineAxis([{start:100000,end:200000}]);assert.equal(axis.epochAt(axis.offsetOf(150000)),150000);assert.equal(draggedOffset(50000,20,100,30000,100000),44000);assert.equal(draggedOffset(0,200,100,30000,100000),0);assert.equal(zoomedSpan(60000,2,100000),30000);assert.equal(zoomedSpan(60000,.5,100000),100000);assert.equal(zoomedSpan(60000,2,18000),18000);
});

async function fixture({identity='same',reject=false}={}){
  let available=true,logins=0,calls=0;
  const server=http.createServer(async(req,res)=>{calls++;if(!available){req.socket.destroy();return}let text='';for await(const chunk of req)text+=chunk;const body=JSON.parse(text);const value=body.cmd==='login'?body.response?(reject?{result:'fail'}:{result:'success',data:{license:identity}}):{result:'fail',session:'fixture-token'}:{result:'success',data:[]};if(body.response)logins++;res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value))});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));return {url:`http://127.0.0.1:${server.address().port}`,setAvailable:value=>available=value,get calls(){return calls},get logins(){return logins},async close(){await new Promise(resolve=>{server.close(resolve);server.closeAllConnections()})}};
}
test('real HTTP routing falls back, probes LAN again and resets preference after network change',async()=>{
  const local=await fixture(),wan=await fixture();let now=100000;const client=new BlueIrisClient({url:local.url,wanUrl:wan.url,username:'viewer',password:'fixture'}, {now:()=>now});
  try{local.setAvailable(false);await client.cameras();assert.equal(client.connectionLabel,'WAN');local.setAvailable(true);await client.cameras();assert.equal(client.connectionLabel,'WAN');now+=61000;await client.cameras();assert.equal(client.connectionLabel,'Local');client.networkChanged(false);await client.cameras();assert.equal(client.connectionLabel,'WAN');client.networkChanged(true);await client.cameras();assert.equal(client.connectionLabel,'Local')}finally{await client.logout();await local.close();await wan.close()}
});
test('authentication rejection never falls back and alternate server identity is rejected',async()=>{
  const local=await fixture({reject:true}),wan=await fixture();let client=new BlueIrisClient({url:local.url,wanUrl:wan.url,username:'viewer',password:'fixture'});
  try{await assert.rejects(client.cameras(),CameraError);assert.equal(wan.calls,0)}finally{await client.logout();await local.close();await wan.close()}
  const first=await fixture({identity:'first'}),second=await fixture({identity:'other'});client=new BlueIrisClient({url:first.url,wanUrl:second.url,username:'viewer',password:'fixture'});
  try{await client.cameras();first.setAvailable(false);await assert.rejects(client.cameras(),/different Blue Iris server/);assert.equal(second.calls,2)}finally{await client.logout();await first.close();await second.close()}
});
test('HTTP 503 and non-Blue-Iris endpoints permit route fallback',async()=>{
  const wan=await fixture();
  for(const status of [503,200]){
    const server=http.createServer((req,res)=>{req.resume();res.writeHead(status);res.end('Not a Blue Iris endpoint')});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    const client=new BlueIrisClient({url:`http://127.0.0.1:${server.address().port}`,wanUrl:wan.url,username:'viewer',password:'fixture'});
    try{await client.cameras();assert.equal(client.connectionLabel,'WAN')}finally{await client.logout();await new Promise(resolve=>{server.close(resolve);server.closeAllConnections()})}
  }
  await wan.close();
});
