import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
import { Vault } from '../server/storage.mjs';

test('Windows DPAPI vault encrypts data, persists updates, and serializes concurrent writes', { skip: process.platform !== 'win32' }, async () => {
  const root = fileURLToPath(new URL('../.local/tests/', import.meta.url));
  await mkdir(root, { recursive: true });
  const directory = await mkdtemp(join(root, 'vault-'));
  try {
    const vault = new Vault(directory); await vault.open();
    await vault.update(state => { state.sites.push({ id: 'fixture', password: 'private-fixture-sentinel', url: 'https://secret.example.test' }); });
    const raw = await readFile(vault.file, 'utf8'); assert.ok(!raw.includes('private-fixture-sentinel')); assert.ok(!raw.includes('secret.example.test'));
    await Promise.all([vault.update(state => { state.layouts.push({ id: 'a' }); }), vault.update(state => { state.layouts.push({ id: 'b' }); })]);
    const reopened = new Vault(directory); await reopened.open();
    assert.equal(reopened.state.sites[0].password, 'private-fixture-sentinel'); assert.equal(reopened.state.layouts.length, 2);
  } finally { if (!resolve(directory).startsWith(resolve(root) + '\\')) throw new Error('Unexpected test path'); await rm(directory, { recursive: true }); }
});
