import { test } from 'node:test';
import assert from 'node:assert/strict';
import { dayBounds, localDate, recordingAt, timelineWindow, parseRecordings, parseEvents, eventKind } from '../src/playback-model.js';
import { receiveRecovering, StreamInterrupted } from '../server/recovery.mjs';
import { CameraError } from '../server/blueiris.mjs';

test('recordings and events preserve real coverage gaps and server classifications',()=>{
  const clips=parseRecordings([{path:'a',date:1000,msec:10000},{path:'b',date:1020,msec:10000},{path:'a',date:1000,msec:10000},{path:'invalid',date:0,msec:0}], 'front');
  assert.equal(clips.length,2);assert.equal(recordingAt(clips,1005000).path,'a');assert.equal(recordingAt(clips,1015000),null);
  assert.equal(eventKind({flags:2**26}),'person');assert.equal(eventKind({flags:2**17}),'motion');assert.equal(eventKind({flags:2**26+2**23}),'alert');
  assert.equal(eventKind({memo:'person:0.00%'}),'alert');assert.equal(eventKind({memo:'no person detected'}),'alert');assert.equal(eventKind({memo:'a human detected'}),'person');assert.equal(eventKind({memo:'unclassified server alert'}),'alert');
  const events=parseEvents([{date:1,memo:'person'},{date:2,flags:2**17},{date:3,memo:'vehicle'}]);assert.deepEqual(events.map(event=>event.kind),['person','motion','alert']);assert.ok(events.every(event=>event.duration>=1000));
});

test('local recording days and full-day timeline include DST transitions',()=>{
  const old=process.env.TZ;process.env.TZ='America/Los_Angeles';
  try{assert.equal(dayBounds('2026-11-01').end-dayBounds('2026-11-01').start,25*3600000);assert.equal(dayBounds('2026-03-08').end-dayBounds('2026-03-08').start,23*3600000);assert.throws(()=>dayBounds('2026-02-31'));const bounds=dayBounds('2026-11-01');assert.equal(timelineWindow(bounds,bounds.start,'day').length,25*3600000);assert.equal(timelineWindow(bounds,bounds.end,'120').start,bounds.end-7200000)}finally{if(old===undefined)delete process.env.TZ;else process.env.TZ=old}
});

test('stream recovery resumes at last delivered position and excludes offline time at selected speed',async()=>{
  let now=0;const opened=[],retried=[],positions=[],abort=new AbortController(),start=1000000;
  await assert.rejects(receiveRecovering({signal:abort.signal,position:start,speed:200,clock:()=>now,backoff:async attempt=>{retried.push(attempt);now+=10000},open:async position=>{opened.push(position);return {body:{async *[Symbol.asyncIterator](){now+=50;yield Buffer.from([255,216,1,255,217]);throw new Error('controlled disconnect')}}}},onFrame:(frame,position)=>positions.push(position)}),error=>error instanceof StreamInterrupted&&error.hadFrames&&error.position===start+400);
  assert.deepEqual(opened,[start,start+100,start+200,start+300]);assert.deepEqual(positions,[start+100,start+200,start+300,start+400]);assert.deepEqual(retried,[1,2,3]);
});

test('access rejection is not repeatedly retried and intentional cancellation releases the stream',async()=>{
  let opens=0;const abort=new AbortController();
  await assert.rejects(receiveRecovering({signal:abort.signal,open:async()=>{opens++;throw new CameraError('Access rejected')},onFrame:()=>{},backoff:()=>{throw Error('must not retry')}}),error=>error instanceof StreamInterrupted&&!error.hadFrames);assert.equal(opens,1);
  let closed=false,frames=0;
  await receiveRecovering({signal:abort.signal,open:async()=>({body:{async *[Symbol.asyncIterator](){try{yield Buffer.from([255,216,1,255,217]);yield Buffer.from([255,216,2,255,217])}finally{closed=true}}}}),onFrame:()=>{frames++;abort.abort()}});
  assert.equal(frames,1);assert.equal(closed,true);
});
