export const transferPhrase = 'test-only-transfer-phrase';
export const transferFixture = {
  format: 'darkstar-viewer-config', version: 1,
  sites: [
    { id: 'fixture-north', name: 'North', url: 'http://north.example.test:81', wanUrl: 'https://north.example.test', username: 'viewer', password: ' fixture-secret é ', color: '#55b6ff' },
    { id: 'fixture-south', name: 'South', url: '', wanUrl: 'https://south.example.test', username: 'other', password: 'fixture-two', color: '#123abc' }
  ],
  settings: { rows: 6, columns: 4, selectedView: 'fixture-doors', siteOrder: ['fixture-south', 'fixture-north'], views: [{ id: 'fixture-doors', name: 'Entrances', rows: 2, columns: 2, cameras: ['fixture-south:cam1', 'fixture-north:cam2'] }], pwa: { mode: 'live', tileSizing: 'video' } }
};
