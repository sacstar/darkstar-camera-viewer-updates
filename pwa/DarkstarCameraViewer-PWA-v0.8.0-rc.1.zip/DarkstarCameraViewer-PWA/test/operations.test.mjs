import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createGateway} from '../server/gateway.mjs';
import {telemetry,maintenance,compareVersion,Operations} from '../server/operations.mjs';
import {parseCameras} from '../server/blueiris.mjs';

test('health preserves unknown telemetry and never exposes login metadata or license keys',()=>{
 const result=telemetry({metadata:{version:'6.1.5.5_x64',license:'PRIVATE-LICENSE',password:'PRIVATE-PASSWORD',support:'2030-01-01',admin:true},status:{cpu:0,mem:'1 GB',discs:[{name:'D',free:5,total:100,credentials:'PRIVATE-DISK'}]}});
 assert.equal(result.cpu,0);assert.equal(result.warnings,null);assert.equal(result.disks[0].freePercent,5);assert.equal(result.maintenance.state,'active');assert.equal(maintenance('11/12/26').state,'unknown');assert.equal(maintenance('Expired').state,'expired');assert.equal(compareVersion('6.1.5.5_x64','6.1.4.9'),1);assert.equal(compareVersion('unknown','6.1.5.5'),null);assert.doesNotMatch(JSON.stringify(result),/PRIVATE/);
 const cameras=parseCameras([{optionValue:'unknown'},{optionValue:'down',isNoSignal:true},{optionValue:'up',isOnline:true}], 'site');assert.deepEqual(cameras.map(c=>c.online),[null,false,true]);
});

test('operations API reports outages, deduplicates reads, protects actions and escapes reports',async()=>{
 const logRoot=await mkdtemp(join(tmpdir(),'darkstar-ops-'));
 const sites=[{id:'north',name:'North <script>',url:'http://private.invalid',username:'private-user',password:'private-password',color:'#459bff'},{id:'south',name:'South',url:'http://private.invalid',username:'private-user',password:'private-password',color:'#459bff'}];
 const vault={state:{sites,layouts:[]},async update(change){change(this.state)}};let name='Front Door',healthCalls=0,alertCalls=0;const commands=[];
 const gateway=createGateway({vault,diagnosticRoot:logRoot,clientFactory:site=>({async cameras(){if(site.id==='south')throw Error('offline');return parseCameras([{optionValue:'door',optionDisplay:name,isOnline:true},{optionValue:'yard',isNoSignal:true},{optionValue:'unknown'}],site.id)},async health(){healthCalls++;return{metadata:{version:'6.1.5.5',admin:true,support:'expired',license:'private-license'},status:{cpu:11,discs:[{name:'D',total:100,free:5}]}}},async recentAlerts(){alertCalls++;return[{camera:'door',path:'alert1',date:Date.now()/1000-30,msec:5000,memo:'person',flags:2**26}]},async administer(action,args){commands.push({action,args});if(action==='rename-camera')name=args.rename;},async logout(){}})});
 const origin=await gateway.listen(0),root=await fetch(origin),cookie=root.headers.get('set-cookie').split(';')[0];await root.body.cancel();
 const request=async(path,body)=>{const response=await fetch(origin+'/api/'+path,{method:body?'POST':'GET',headers:{Cookie:cookie,Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});return{status:response.status,value:await response.json()}};
 try{
  assert.equal((await fetch(origin+'/api/operations')).status,401);
  await request('refresh',{});const first=await request('operations');assert.equal(first.value.counts.sitesOffline,1);assert.equal(first.value.counts.camerasOffline,1);assert.equal(first.value.counts.camerasUnknown,1);assert.equal(first.value.alerts[0].key,'north:door');assert.equal(first.value.alerts[0].kind,'person');
  await Promise.all([request('operations'),request('operations')]);assert.equal(healthCalls,1);assert.equal(alertCalls,1);
  assert.equal((await request('admin/prepare',{siteId:'north',action:'raw-admin',value:'dangerous'})).status,400);
  const intent=(await request('admin/prepare',{siteId:'north',action:'rename-camera',key:'north:door',value:'New Door'})).value;
  assert.equal(commands.length,0);const committed=await request('admin/commit',{id:intent.id,confirmation:'North <script>'});assert.equal(committed.value.verified,true);assert.equal(commands.length,1);
  assert.equal((await request('admin/commit',{id:intent.id,confirmation:'North <script>'})).status,400);assert.equal(commands.length,1);
  const reboot=(await request('admin/prepare',{siteId:'north',action:'reboot-host'})).value;await request('admin/commit',{id:reboot.id,confirmation:'wrong site'});assert.equal(commands.length,1);
  const report=await request('diagnostics');assert.doesNotMatch(JSON.stringify(report.value),/private-user|private-password|private\.invalid|private-license/);assert.match(JSON.stringify(report.value),/admin-accepted/);
  const html=await (await fetch(origin+'/api/technician-report',{headers:{Cookie:cookie}})).text();assert.match(html,/North &lt;script&gt;/);assert.doesNotMatch(html,/<script>/);assert.match(html,/Low disk space/);
 }finally{await gateway.close();assert.doesNotMatch(await readFile(join(logRoot,'operations.jsonl'),'utf8'),/private-password|private-license/);await rm(logRoot,{recursive:true,force:true})}
});

test('uncertain admin results are consumed and never retried; read-only permissions are enforced',async()=>{
 const state={sites:[{id:'one',name:'One',status:'online',cameras:[]}]};let attempts=0;
 const ops=new Operations({state:()=>state,client:()=>({async administer(){attempts++;throw Error('connection lost')}}),locate:()=>null,refresh:async()=>{},now:()=>100000});
 ops.cache.set('one',{health:telemetry({metadata:{admin:false}})});assert.throws(()=>ops.prepare({siteId:'one',action:'reboot-host'}),/permission/);
 ops.cache.set('one',{health:telemetry({metadata:{admin:true}})});const intent=ops.prepare({siteId:'one',action:'reboot-host'});await assert.rejects(ops.commit({id:intent.id,confirmation:'One'}),/not retried/);await assert.rejects(ops.commit({id:intent.id,confirmation:'One'}),/already submitted/);assert.equal(attempts,1);
});
