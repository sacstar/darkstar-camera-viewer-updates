import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { BlueIrisClient, cleanProfile, normalizeUrl, parseCameras, JpegParser, publicError, CameraError } from '../server/blueiris.mjs';

test('validates user-specified site URLs and does not accept embedded credentials', () => {
  assert.equal(normalizeUrl(' https://example.test:81/bi/ '), 'https://example.test:81/bi');
  for (const value of ['example.test', 'file:///etc/passwd', 'http://user:pass@example.test', 'http://example.test?password=x', 'https://example.test/#x']) assert.throws(() => normalizeUrl(value), CameraError);
  assert.throws(() => cleanProfile({ name: '', url: 'http://example.test', username: 'a', password: 'x' }));
  assert.equal(cleanProfile({ name: 'Site', url: 'https://example.test', username: 'viewer', password: '' }, { id: 'one', password: 'fixture-secret' }).password, 'fixture-secret');
});

test('camera keys preserve site identity and filter groups and duplicates', () => {
  const data = [{ optionValue: 'index', optionDisplay: 'All cameras' }, { optionValue: 'group', optionDisplay: '+Outside' }, { optionValue: 'front', optionDisplay: 'Front', isEnabled: true }, { optionValue: 'front', optionDisplay: 'Front' }, { optionValue: 'disabled', optionDisplay: 'Offline', isEnabled: false }];
  const first = parseCameras(data, 'site-a'), second = parseCameras(data, 'site-b');
  assert.equal(first.length, 2); assert.notEqual(first[0].key, second[0].key); assert.equal(first[1].enabled, false);
});

test('MJPEG parser handles chunk boundaries and rejects unbounded input', () => {
  const frames = [], parser = new JpegParser(frame => frames.push(Buffer.from(frame)));
  parser.push(Buffer.from('--boundary\r\nContent-Type: image/jpeg\r\n\r\n'));
  parser.push(Buffer.from([255])); parser.push(Buffer.from([216, 1, 2, 255])); parser.push(Buffer.from([217, 13, 10, 255, 216, 3, 255, 217]));
  assert.deepEqual(frames, [Buffer.from([255, 216, 1, 2, 255, 217]), Buffer.from([255, 216, 3, 255, 217])]);
  assert.throws(() => new JpegParser(() => {}, 4).push(Buffer.from([255, 216, 1, 2, 3, 255, 217])));
  assert.throws(() => new JpegParser(() => {}).push(Buffer.alloc(65537)));
});

test('challenge-response authentication coalesces logins, recovers expiry, and keeps passwords out of media URLs', async () => {
  let challenges = 0, expires = true;
  const seen = [];
  const server = http.createServer(async (req, res) => {
    seen.push({ url: req.url, cookie: req.headers.cookie });
    if (req.url.startsWith('/image/')) { res.writeHead(200, { 'Content-Type': 'image/jpeg' }); res.end(Buffer.from([255, 216, 1, 255, 217])); return; }
    let text = ''; for await (const chunk of req) text += chunk;
    const body = JSON.parse(text); let response;
    if (body.cmd === 'login') {
      if (!body.response) { challenges++; response = { result: 'fail', session: `token-${challenges}` }; }
      else { assert.equal(body.response, createHash('md5').update(`viewer:token-${challenges}:fixture-secret`).digest('hex')); response = { result: 'success' }; }
    } else if (body.cmd === 'camlist') {
      assert.equal(body.session, `token-${challenges}`);
      if (expires) { expires = false; response = { result: 'fail' }; } else response = { result: 'success', data: [{ optionValue: 'front cam', optionDisplay: 'Front' }] };
    } else response = { result: 'success' };
    res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(response));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const client = new BlueIrisClient({ id: 'a', url: `http://127.0.0.1:${server.address().port}`, username: 'viewer', password: 'fixture-secret' });
    await Promise.all([client.token(), client.token(), client.token()]); assert.equal(challenges, 1);
    const cameras = await client.cameras(); assert.equal(challenges, 2); assert.equal(cameras.length, 1);
    const image = await client.snapshot(cameras[0].id); assert.equal(image[0], 255);
    const media = seen.find(item => item.url.startsWith('/image/'));
    assert.ok(media.url.includes('session=token-2')); assert.equal(media.cookie, 'Session=token-2'); assert.ok(!media.url.includes('fixture-secret')); assert.ok(!media.url.includes('viewer'));
    await client.logout();
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});

test('public connection errors do not expose arbitrary upstream content', () => {
  assert.ok(!publicError(new Error('fixture-secret private upstream address')).includes('fixture-secret'));
  assert.equal(publicError(new CameraError('Sign-in failed.')), 'Sign-in failed.');
});

test('read-only protocol requests recover from a transient dropped connection', async () => {
  let calls = 0;
  const server = http.createServer((req, res) => {
    calls++;
    if (calls === 1) { req.socket.destroy(); return; }
    req.resume(); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ result: 'fail', session: 'fixture-token' }));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const client = new BlueIrisClient({ url: `http://127.0.0.1:${server.address().port}` });
    assert.equal((await client.post({ cmd: 'login' })).session, 'fixture-token');
    assert.equal(calls, 2);
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});

test('recording permission failure leaves clip coverage available and time media uses isolated authenticated playback',async()=>{
  const commands=[],paths=[],start=Date.now()-3600000,end=Date.now(),image=Buffer.from([255,216,9,255,217]);
  const server=http.createServer(async(req,res)=>{
    if(req.url.startsWith('/time/')){paths.push(req.url);res.writeHead(200,{'Content-Type':'application/octet-stream'});res.end(image);return}
    let text='';for await(const chunk of req)text+=chunk;const body=JSON.parse(text);commands.push(body);
    let response=body.cmd==='login'?body.response?{result:'success'}:{result:'fail',session:'record-session'}:body.cmd==='cliplist'?{result:'success',data:[{path:'record-a',camera:'front',date:start/1000,msec:end-start}]}:{result:'fail'};
    res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(response));
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{
    const client=new BlueIrisClient({id:'site',url:`http://127.0.0.1:${server.address().port}`,username:'viewer',password:'fixture-only'});
    const day=await client.recordings('front',start,end);assert.equal(day.recordings.length,1);assert.equal(day.eventsAvailable,false);assert.equal(commands.find(item=>item.cmd==='cliplist').startdate,Math.floor((start-86400000)/1000));
    assert.deepEqual(await client.recordedFrame('front',start,new AbortController().signal),image);
    const response=await client.media('front',true,new AbortController().signal,{position:start,speed:200});await response.body.cancel();
    assert.ok(paths.some(path=>path.includes('mode=mjpg')&&path.includes('speed=200')&&path.includes('isolate=1')));assert.ok(paths.every(path=>!path.includes('fixture-only')&&!path.includes('viewer')));
  }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve))}
});
