import test from 'node:test';
import assert from 'node:assert/strict';
import {moveCamera} from '../src/layout-order.js';
test('camera moves preserve the full cross-site order including unavailable cameras',()=>{
 const keys=['north:door','missing:camera','south:yard','north:lobby'];
 assert.deepEqual(moveCamera(keys,'north:door','south:yard'),['missing:camera','south:yard','north:door','north:lobby']);
 assert.deepEqual(moveCamera(keys,'north:lobby','north:door'),['north:lobby','north:door','missing:camera','south:yard']);
 assert.deepEqual(keys,['north:door','missing:camera','south:yard','north:lobby']);
 for(const [from,to] of [['absent','north:door'],['north:door','absent'],['north:door','north:door']])assert.equal(moveCamera(keys,from,to),keys);
});
