import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFileSync} from 'node:fs';
const currentVersion=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8')).version;
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {isGatewayResponse} from '../gateway-health.mjs';

test('gateway detection accepts current and future versions, but not unrelated/error responses',()=>{
 for(const version of ['0.1.0','0.5.1','0.6.0','0.6.1','0.10.0','1.0.0','2.1.3-rc.1','2.1.3+build.12'])assert.equal(isGatewayResponse(new Response('',{headers:{'x-darkstar-gateway':version}})),true,version);
 for(const version of ['', 'nginx','0.6','0.6.0junk','0.6.0\n'])assert.equal(isGatewayResponse({ok:true,headers:{get:()=>version}}),false,version);
 assert.equal(isGatewayResponse(new Response('',{status:503,headers:{'x-darkstar-gateway':'0.6.1'}})),false);
});

test('launcher reuses a healthy gateway of the installed version without spawning another server',async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('X-Darkstar-Gateway',currentVersion);res.end('test gateway');});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  const result=await new Promise((resolve,reject)=>{
   const child=spawn(process.execPath,[fileURLToPath(new URL('../launch.mjs',import.meta.url)),'--no-browser'],{env:{...process.env,DARKSTAR_PORT:String(server.address().port)},windowsHide:true});
   let output='';child.stdout.on('data',data=>output+=data);child.stderr.on('data',data=>output+=data);child.on('error',reject);child.on('close',code=>resolve({code,output}));
  });
  assert.equal(result.code,0,result.output);assert.match(result.output,/Darkstar is ready:/);
 }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
});

test('launcher refuses an older gateway and directs the user to repair without stopping it',async()=>{
 let shutdowns=0;
 const server=http.createServer((req,res)=>{if(req.url==='/api/shutdown')shutdowns++;res.setHeader('X-Darkstar-Gateway','0.6.1');res.end('old gateway');});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  const result=await new Promise((resolve,reject)=>{
   const child=spawn(process.execPath,[fileURLToPath(new URL('../launch.mjs',import.meta.url)),'--no-browser'],{env:{...process.env,DARKSTAR_PORT:String(server.address().port)},windowsHide:true});
   let output='';child.stdout.on('data',data=>output+=data);child.stderr.on('data',data=>output+=data);child.on('error',reject);child.on('close',code=>resolve({code,output}));
  });
  assert.equal(result.code,1,result.output);assert.match(result.output,/Repair-Darkstar\.cmd/);assert.equal(shutdowns,0);assert.equal(server.listening,true);
 }finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
});

