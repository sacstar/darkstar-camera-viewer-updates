import {test} from 'node:test';
import assert from 'node:assert/strict';
import {RequestQueue} from '../src/request-queue.js';

test('preview concurrency stays at three and cancelled queued cameras never issue requests',async()=>{
  const queue=new RequestQueue(3),started=[],release=[];
  const first=[0,1,2].map(id=>queue.run(()=>{started.push(id);return new Promise(resolve=>release.push(resolve))}));
  const abort=new AbortController();
  const hidden=queue.run(()=>{started.push('hidden');return 4},abort.signal).catch(error=>error.name);
  const visible=queue.run(()=>{started.push('visible');return 5});
  await new Promise(resolve=>setImmediate(resolve));assert.equal(queue.active,3);assert.deepEqual(started,[0,1,2]);
  abort.abort();assert.equal(await hidden,'AbortError');release.shift()(1);assert.equal(await visible,5);assert.ok(!started.includes('hidden'));
  release.forEach(resolve=>resolve(1));await Promise.all(first);await new Promise(resolve=>setImmediate(resolve));assert.equal(queue.active,0);
});
