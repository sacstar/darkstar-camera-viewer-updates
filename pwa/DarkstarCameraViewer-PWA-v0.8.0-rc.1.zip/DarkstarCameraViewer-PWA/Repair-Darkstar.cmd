@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-Darkstar.ps1"
if errorlevel 1 pause
