#Requires -Version 5.1
[CmdletBinding()]
param([string]$RuntimeDirectory=(Join-Path $env:LOCALAPPDATA 'DarkstarCameraViewer\runtime\media'))
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$destination=Join-Path $RuntimeDirectory 'ffmpeg-win-x86_64-v7.1.exe'
if(Test-Path -LiteralPath $destination){Write-Output $destination;exit 0}
New-Item -ItemType Directory -Path $RuntimeDirectory -Force | Out-Null
$wheel=Join-Path $RuntimeDirectory ('download-'+[guid]::NewGuid().ToString()+'.whl')
try {
    Invoke-WebRequest 'https://files.pythonhosted.org/packages/2c/c6/fa760e12a2483469e2bf5058c5faff664acf66cadb4df2ad6205b016a73d/imageio_ffmpeg-0.6.0-py3-none-win_amd64.whl' -OutFile $wheel -UseBasicParsing -TimeoutSec 180
    if((Get-FileHash -LiteralPath $wheel -Algorithm SHA256).Hash -ne '02fa47c83703c37df6bfe4896aab339013f62bf02c5ebf2dce6da56af04ffc0a'){throw 'Media runtime checksum mismatch.'}
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive=[IO.Compression.ZipFile]::OpenRead($wheel)
    try {
        $entry=$archive.GetEntry('imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
        if(-not $entry){throw 'Media runtime binary was not found.'}
        [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$destination,$true)
        foreach($license in $archive.Entries | Where-Object { $_.FullName -match '(?i)(license|copying)' }) {
            [IO.Compression.ZipFileExtensions]::ExtractToFile($license,(Join-Path $RuntimeDirectory ($license.Name)), $true)
        }
    } finally {$archive.Dispose()}
    Write-Output $destination
} finally {if(Test-Path -LiteralPath $wheel){Remove-Item -LiteralPath $wheel -Force}}
