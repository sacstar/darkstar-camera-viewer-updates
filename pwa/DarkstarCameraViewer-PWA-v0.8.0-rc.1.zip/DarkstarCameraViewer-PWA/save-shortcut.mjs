import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('./', import.meta.url));
if (process.platform !== 'win32') throw new Error('This shortcut installer is for Windows.');
const script = String.raw`
$ErrorActionPreference = 'Stop'
$config = [Console]::In.ReadToEnd() | ConvertFrom-Json
$desktop = [Environment]::GetFolderPath('Desktop')
$file = Join-Path $desktop 'Darkstar Camera Viewer.lnk'
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($file)
$shortcut.TargetPath = Join-Path $config.root 'Start-Darkstar.cmd'
$shortcut.Arguments = ''
$shortcut.WorkingDirectory = $config.root
$shortcut.IconLocation = (Join-Path $config.root 'public\icon.ico') + ',0'
$shortcut.Description = 'Darkstar Camera Viewer - checks prerequisites, starts the private local gateway and opens the app'
$shortcut.WindowStyle = 1
$shortcut.Save()
[Console]::Out.Write($file)
`;
const result = await new Promise((resolve,reject)=>{
  const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{windowsHide:true,stdio:['pipe','pipe','pipe']});
  let output='';child.stdout.setEncoding('utf8');child.stdout.on('data',value=>output+=value);child.stderr.on('data',()=>{});child.on('error',reject);child.on('close',code=>code===0?resolve(output):reject(new Error('The desktop shortcut could not be saved.')));child.stdin.end(JSON.stringify({root}));
});
console.log(`Saved desktop shortcut: ${result}`);
