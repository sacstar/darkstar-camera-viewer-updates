Set-StrictMode -Version 2.0
# Windows PowerShell can inherit PowerShell 7 module paths from a parent launcher.
# Load its own utility module so hashing and HTTPS cmdlets resolve consistently.
if ($PSVersionTable.PSEdition -eq 'Desktop') {
    $env:PSModulePath = (Join-Path $PSHOME 'Modules') + ';' + $env:PSModulePath
    Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Utility\Microsoft.PowerShell.Utility.psd1') -Force -Global
}

function Get-CompatibleNode {
    param([string]$Root, [switch]$PrivateRuntime, [string]$RuntimeDirectory = (Join-Path $env:LOCALAPPDATA 'DarkstarCameraViewer\runtime'))
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    $private = $RuntimeDirectory
    if (Test-Path -LiteralPath $private) {
        Get-ChildItem -LiteralPath $private -Directory -Filter 'node-v*-win-*' | Sort-Object LastWriteTime -Descending | ForEach-Object { $candidates.Add((Join-Path $_.FullName 'node.exe')) }
    }
    if (-not $PrivateRuntime) {
        $command = Get-Command node.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command) { $candidates.Add($command.Source) }
        foreach ($folder in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
            if ($folder) { $candidates.Add((Join-Path $folder 'nodejs\node.exe')) }
        }
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $version = (& $candidate --version 2>$null | Out-String).Trim()
            if ($LASTEXITCODE -eq 0 -and (Test-CompatibleNodeVersion $version)) {
                $directory = Split-Path -Parent $candidate
                $npm = Join-Path $directory 'node_modules\npm\bin\npm-cli.js'
                if (Test-Path -LiteralPath $npm -PathType Leaf) {
                    $npmVersion = (& $candidate $npm --version 2>$null | Out-String).Trim()
                    if ($LASTEXITCODE -ne 0 -or $npmVersion -notmatch '^\d+\.\d+\.\d+$') { continue }
                    return [pscustomobject]@{ Node = $candidate; Npm = $npm; Version = $version; Directory = $directory }
                }
            }
        } catch { }
    }
    return $null
}

function Get-DarkstarBrowser {
    foreach ($candidate in @(
        @{ Name = 'Chrome'; Path = (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe') },
        @{ Name = 'Chrome'; Path = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe') },
        @{ Name = 'Edge'; Path = (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe') }
    )) { if (Test-Path -LiteralPath $candidate.Path -PathType Leaf) { return $candidate.Name } }
    if (${env:ProgramFiles(x86)} -and (Test-Path -LiteralPath (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe') -PathType Leaf)) { return 'Edge' }
    $choice = Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice' -ErrorAction SilentlyContinue
    if ($choice -and $choice.ProgId) {
        $key = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey(($choice.ProgId + '\shell\open\command'))
        if ($key) { try { if ($key.GetValue('')) { return 'Windows default browser' } } finally { $key.Dispose() } }
    }
    return $null
}

function Test-CompatibleNodeVersion {
    param([string]$Version)
    return $Version -match '^v(\d+)\.\d+\.\d+$' -and [int]$Matches[1] -ge 22
}

function Get-NodeArchitecture {
    $architecture = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
    switch ($architecture) {
        'AMD64' { return 'x64' }
        'ARM64' { return 'arm64' }
        default { throw 'Darkstar setup supports 64-bit Windows on x64 or ARM64.' }
    }
}

function Select-NodeRelease {
    param([object[]]$Releases, [ValidateSet('x64','arm64')][string]$Architecture)
    $release = $Releases | Where-Object { $_.lts -and $_.version -match '^v\d+\.\d+\.\d+$' -and (Test-CompatibleNodeVersion $_.version) -and $_.files -contains "win-$Architecture-zip" } | Sort-Object { [version]$_.version.TrimStart('v') } -Descending | Select-Object -First 1
    if (-not $release) { throw 'An official compatible Node.js LTS download could not be found.' }
    $name = "node-$($release.version)-win-$Architecture"
    return [pscustomobject]@{ Version = $release.version; Name = $name; File = "$name.zip"; Base = "https://nodejs.org/dist/$($release.version)/" }
}

function Assert-NodeChecksum {
    param([string]$Archive, [string]$Checksums, [string]$FileName)
    $line = @($Checksums -split '\r?\n' | Where-Object { $_ -match ('^[a-fA-F0-9]{64}\s+' + [regex]::Escape($FileName) + '$') })
    if ($line.Count -ne 1) { throw 'The official Node.js checksum entry was missing or ambiguous.' }
    $expected = ($line[0] -split '\s+')[0]
    $actual = (Get-FileHash -LiteralPath $Archive -Algorithm SHA256).Hash
    if ($actual -ine $expected) { throw 'Node.js download checksum verification failed. The archive will not be installed.' }
}

function Expand-NodeRuntime {
    param([string]$Archive, [string]$Destination, [string]$ExpectedFolder)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $root = [IO.Path]::GetFullPath($Destination).TrimEnd('\') + '\'
    $zip = [IO.Compression.ZipFile]::OpenRead($Archive)
    try {
        foreach ($entry in $zip.Entries) {
            $relative = $entry.FullName.Replace('/', '\')
            $target = [IO.Path]::GetFullPath((Join-Path $root $relative))
            if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or -not $relative.StartsWith(($ExpectedFolder + '\'), [StringComparison]::OrdinalIgnoreCase)) {
                throw 'The Node.js archive contained an unexpected path.'
            }
        }
    } finally { $zip.Dispose() }
    [IO.Compression.ZipFile]::ExtractToDirectory($Archive, $Destination)
}

function Install-PrivateNode {
    param([string]$Root, [string]$RuntimeDirectory = (Join-Path $env:LOCALAPPDATA 'DarkstarCameraViewer\runtime'))
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $architecture = Get-NodeArchitecture
    Write-Host 'Checking official Node.js LTS downloads...'
    $previousProgress = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'
    try {
        $releases = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -TimeoutSec 30
        $release = Select-NodeRelease -Releases $releases -Architecture $architecture
        $runtime = [IO.Path]::GetFullPath($RuntimeDirectory)
        $stage = Join-Path $runtime ('download-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stage -Force | Out-Null
        try {
            $archive = Join-Path $stage $release.File
            Write-Host "Downloading Node.js $($release.Version) for this app. No administrator rights needed."
            Invoke-WebRequest -Uri ($release.Base + $release.File) -OutFile $archive -UseBasicParsing -TimeoutSec 300
            $sums = Invoke-WebRequest -Uri ($release.Base + 'SHASUMS256.txt') -UseBasicParsing -TimeoutSec 30
            Assert-NodeChecksum -Archive $archive -Checksums $sums.Content -FileName $release.File
            Write-Host 'SHA-256 checksum verified. Installing the private runtime...'
            $extracted = Join-Path $stage 'extracted'
            Expand-NodeRuntime -Archive $archive -Destination $extracted -ExpectedFolder $release.Name
            # Validate the extracted executable before it becomes the selected runtime.
            $executable = Join-Path (Join-Path $extracted $release.Name) 'node.exe'
            $version = (& $executable --version | Out-String).Trim()
            if ($LASTEXITCODE -ne 0 -or $version -ne $release.Version) { throw 'The downloaded Node.js runtime could not run on this computer.' }
            $destination = Join-Path $runtime $release.Name
            if (Test-Path -LiteralPath $destination) { throw 'An incomplete private runtime already exists. Rename that runtime folder and try setup again.' }
            $source = [IO.Path]::GetFullPath((Split-Path -Parent $executable))
            $target = [IO.Path]::GetFullPath($destination)
            $runtimePrefix = [IO.Path]::GetFullPath($runtime).TrimEnd('\') + '\'
            $stagePrefix = [IO.Path]::GetFullPath($stage).TrimEnd('\') + '\'
            if (-not $source.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase) -or -not $target.StartsWith($runtimePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'The private runtime paths could not be validated.' }
            Move-Item -LiteralPath $source -Destination $target
        } finally {
            # Delete only this uniquely generated staging folder inside this app's runtime directory.
            $absoluteRuntime = [IO.Path]::GetFullPath($runtime).TrimEnd('\') + '\'
            $absoluteStage = [IO.Path]::GetFullPath($stage)
            if ($absoluteStage.StartsWith($absoluteRuntime, [StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $absoluteStage) -match '^download-[a-f0-9]{32}$' -and (Test-Path -LiteralPath $absoluteStage)) {
                Remove-Item -LiteralPath $absoluteStage -Recurse -Force
            }
        }
    } finally { $ProgressPreference = $previousProgress }
    $result = Get-CompatibleNode -Root $Root -PrivateRuntime -RuntimeDirectory $RuntimeDirectory
    if (-not $result) { throw 'The private Node.js installation did not pass its prerequisite check.' }
    return $result
}

Export-ModuleMember -Function Get-CompatibleNode, Test-CompatibleNodeVersion, Get-NodeArchitecture, Get-DarkstarBrowser, Select-NodeRelease, Assert-NodeChecksum, Expand-NodeRuntime, Install-PrivateNode
