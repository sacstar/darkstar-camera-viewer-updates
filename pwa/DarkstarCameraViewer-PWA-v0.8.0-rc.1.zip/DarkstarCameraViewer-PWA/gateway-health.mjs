// Identify the gateway by its dedicated header without a list of app versions.
// A new minor version must not make a healthy running gateway look offline.
export function isGatewayResponse(response) {
  return response.ok && /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(response.headers.get('x-darkstar-gateway') || '');
}
