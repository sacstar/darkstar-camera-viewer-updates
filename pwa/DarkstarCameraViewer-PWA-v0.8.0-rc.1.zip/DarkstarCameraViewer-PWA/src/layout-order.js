// Move within the complete saved order, including temporarily unavailable cameras.
export function moveCamera(keys, source, target) {
  const from=keys.indexOf(source), to=keys.indexOf(target);
  if(from<0||to<0||from===to)return keys;
  const next=[...keys];next.splice(from,1);next.splice(to,0,source);return next;
}
