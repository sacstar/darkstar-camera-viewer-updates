// Child windows use session storage; they never overwrite the main window's view.
export function windowSettings(search,local={},session={}) {
 const params=new URLSearchParams(search),id=params.get('window');
 if(!id)return {storage:'local',key:'darkstar-ui-v1',preferences:local};
 const preferences={...local,activeId:params.get('view')||null,groupFilter:params.get('group')||'all',wallMode:params.get('wall')==='1',...session};
 return {storage:'session',key:`darkstar-window-${id}`,preferences};
}

export function wallGrid(count,width=1280,height=850){
 const visible=Math.max(1,Math.min(144,Number(count)||1));
 const columns=Math.min(12,Math.max(1,Math.ceil(Math.sqrt(visible*Math.max(.5,width/Math.max(1,height))*9/16))));
 return {columns,rows:Math.min(12,Math.ceil(visible/columns))};
}
