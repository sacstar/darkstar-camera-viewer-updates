import { useEffect, useRef, useState } from 'react';
import { useDocumentVisible } from './hooks';

export function useViewerStream({ camera, mode, playing, position, revision, speed, onPosition }) {
  const [frame, setFrame] = useState({ url: null, status: 'connecting', error: null });
  const socket = useRef(null), objectUrl = useRef(null), requestId = useRef(null), cursor = useRef(position), current = useRef(null), connect = useRef(null), resetBudget = useRef(()=>{});
  const visible = useDocumentVisible();
  current.current = { camera, mode, playing, position, revision, speed, visible, onPosition };
  const display = (blob, extra = {}) => {
    const url = URL.createObjectURL(blob);
    if (objectUrl.current) URL.revokeObjectURL(objectUrl.current);
    objectUrl.current = url; setFrame({ url, status: 'ready', error: null, ...extra });
  };
  const send = () => {
    const state = current.current, ws = socket.current;
    if (ws?.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: 'playback-stop' })); ws.send(JSON.stringify({ type: 'subscribe', keys: [] }));
    if (!state.playing || !state.visible) return;
    setFrame(previous => ({ ...previous, status: 'connecting', error: null }));
    if (state.mode === 'playback') {
      requestId.current = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      ws.send(JSON.stringify({ type: 'playback', key: state.camera.key, position: Math.trunc(cursor.current), speed: state.speed, requestId: requestId.current }));
    } else ws.send(JSON.stringify({ type: 'subscribe', keys: [state.camera.key] }));
  };
  useEffect(() => {
    let disposed = false, timer, failures = 0;
    resetBudget.current = () => { failures = 0; clearTimeout(timer); };
    connect.current = async () => {
      if (failures) { try { await fetch('/', { cache: 'no-store', credentials: 'same-origin', signal: AbortSignal.timeout(5000) }); } catch {} }
      if (disposed) return;
      const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/live`);
      ws.binaryType = 'arraybuffer'; socket.current = ws;
      ws.onopen = send;
      ws.onmessage = event => {
        if (disposed) return;
        const state = current.current;
        if (typeof event.data === 'string') {
          try {
            const message = JSON.parse(event.data);
            if (message.key !== state.camera.key || (state.mode === 'playback' && message.requestId !== requestId.current)) return;
            if (Number.isFinite(message.position)) { cursor.current = message.position; state.onPosition(message.position); }
            if (message.type === 'stream-status') setFrame(previous => ({ ...previous, status: 'recovering', attempt: message.attempt, error: null }));
            if (message.type === 'stream-error') setFrame(previous => ({ ...previous, status: 'error', error: message.message }));
          } catch {}
          return;
        }
        try {
          const length = new DataView(event.data).getUint16(0), metadata = JSON.parse(new TextDecoder().decode(new Uint8Array(event.data, 2, length)));
          if (metadata.key !== state.camera.key || (metadata.mode || 'live') !== state.mode || (state.mode === 'playback' && metadata.requestId !== requestId.current) || !state.playing || !state.visible) return;
          if (Number.isFinite(metadata.position)) { cursor.current = metadata.position; state.onPosition(metadata.position); }
          display(new Blob([event.data.slice(2 + length)], { type: 'image/jpeg' })); failures = 0;
        } catch {}
      };
      ws.onerror = () => ws.close();
      ws.onclose = () => {
        if (disposed) return;
        if (failures >= 3) { setFrame(previous => ({ ...previous, status: 'error', error: 'The gateway connection was interrupted. Resume from here when it is available.' })); return; }
        const attempt = ++failures;
        setFrame(previous => ({ ...previous, status: 'recovering', attempt, error: null }));
        timer = setTimeout(connect.current, [500,1500,3000][attempt - 1]);
      };
    };
    connect.current();
    return () => { disposed = true; clearTimeout(timer); socket.current?.close(); if (objectUrl.current) URL.revokeObjectURL(objectUrl.current); };
  }, []);
  useEffect(() => { if (objectUrl.current) { URL.revokeObjectURL(objectUrl.current); objectUrl.current = null; } setFrame({url:null,status:'connecting',error:null}); }, [camera.key]);
  useEffect(() => {
    cursor.current = position;
    send();
    if (!playing) setFrame(previous => ({ ...previous, status: 'paused', error: null }));
    if (mode !== 'playback' || playing) return;
    const abort = new AbortController(); let disposed = false;
    fetch(`/api/sites/${encodeURIComponent(camera.siteId)}/cameras/${encodeURIComponent(camera.id)}/frame?position=${Math.trunc(position)}`, { cache: 'no-store', signal: abort.signal }).then(async response => {
      if (!response.ok) throw new Error('No recorded image is available at this time.');
      const blob = await response.blob(); if (!disposed) display(blob, { status: 'paused' });
    }).catch(error => { if (!disposed) setFrame(previous => ({ ...previous, status: 'error', error: error.message })); });
    return () => { disposed = true; abort.abort(); };
  }, [camera.key, mode, playing, revision, speed]);
  useEffect(() => { send(); }, [visible]);
  const reconnect = () => { if (!socket.current || socket.current.readyState === WebSocket.CLOSED) { resetBudget.current(); connect.current?.(); } };
  return { ...frame, reconnect, currentPosition: () => cursor.current };
}
