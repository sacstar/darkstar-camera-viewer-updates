import React, {useRef} from 'react';
import {draggedOffset,zoomedSpan} from './timeline-axis';
const time=(epoch,seconds)=>new Date(epoch).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',...(seconds?{second:'2-digit'}:{}),hour12:false});

export function GestureTimeline({data,axis,position,span,onBegin,onScrub,onFinish,onScale,motionOnly}){
  const gesture=useRef(null),center=axis.offsetOf(position),start=center-span/2;
  const begin=event=>{
    if(!axis.duration)return;event.preventDefault();event.currentTarget.setPointerCapture(event.pointerId);
    if(!gesture.current){gesture.current={points:new Map(),at:center,span,width:event.currentTarget.clientWidth,left:event.currentTarget.getBoundingClientRect().left,moved:false};onBegin()}
    gesture.current.points.set(event.pointerId,{x:event.clientX,y:event.clientY});
  };
  const move=event=>{
    const g=gesture.current;if(!g?.points.has(event.pointerId))return;event.preventDefault();
    const old=[...g.points.values()],previous=g.points.get(event.pointerId);g.points.set(event.pointerId,{x:event.clientX,y:event.clientY});const points=[...g.points.values()];
    if(points.length>=2){const distance=p=>Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);const before=distance(old),after=distance(points);if(before&&after){g.span=zoomedSpan(g.span,after/before,axis.duration);g.moved=true}}
    const delta=(event.clientX-previous.x)/points.length;
    if(Math.abs(delta)>0){g.at=draggedOffset(g.at,delta,g.width,g.span,axis.duration);g.moved=true}
    onScrub(axis.epochAt(g.at),g.span);
  };
  const finish=event=>{const g=gesture.current;if(!g)return;g.points.delete(event.pointerId);if(g.points.size)return;gesture.current=null;const at=g.moved?g.at:g.at+(event.clientX-g.left-g.width/2)/g.width*g.span;onFinish(axis.epochAt(at))};
  const cancel=()=>{if(gesture.current){const g=gesture.current;gesture.current=null;onFinish(axis.epochAt(g.at))}};
  const segment=(a,b)=>({left:`${(a-start)/span*100}%`,width:`${(b-a)/span*100}%`});
  const bands=(items,kind)=>items.flatMap((item,index)=>axis.project(item.start,item.end??item.start+item.duration).map((band,n)=><i key={`${index}:${n}`} className={kind||`event-segment ${item.kind}`} style={segment(band.start,band.end)}/>));
  return <><div className="gesture-timeline" role="slider" tabIndex={axis.duration?0:-1} aria-label="Recording timeline" aria-disabled={!axis.duration} aria-valuemin={0} aria-valuemax={Math.max(0,axis.duration-1)} aria-valuenow={Math.trunc(center)} aria-valuetext={`${time(position,true)}, ${motionOnly?'motion only':'all footage'}, ${Math.round(span/1000)} seconds visible`} onPointerDown={begin} onPointerMove={move} onPointerUp={finish} onPointerCancel={cancel} onLostPointerCapture={()=>{}} onKeyDown={event=>{let at;if(event.key==='ArrowLeft')at=center-span/5;if(event.key==='ArrowRight')at=center+span/5;if(event.key==='Home')at=0;if(event.key==='End')at=axis.duration-1;if(at!==undefined){event.preventDefault();onFinish(axis.epochAt(at))}if(['+','=','-'].includes(event.key)){event.preventDefault();onScale(zoomedSpan(span,event.key==='-'?.5:2,axis.duration))}}}>
    <div className="gesture-ticks">{[0,1,2,3,4].map(i=>{const offset=start+span*i/4;return <span key={i}>{offset>=0&&offset<axis.duration?time(axis.epochAt(offset),span<300000):''}</span>})}</div>
    <div className="gesture-lanes"><div className="coverage-lane">{bands(data.recordings,'coverage-segment')}</div><div className="event-lane">{bands(data.events.filter(e=>!motionOnly||e.kind!=='alert'))}</div></div><i className="fixed-playhead"/>
  </div><div className="timeline-tools"><span>Drag to seek · pinch to zoom</span><button aria-label="Zoom timeline in" onClick={()=>onScale(zoomedSpan(span,2,axis.duration))}>+</button><button aria-label="Zoom timeline out" onClick={()=>onScale(zoomedSpan(span,.5,axis.duration))}>−</button></div></>;
}
