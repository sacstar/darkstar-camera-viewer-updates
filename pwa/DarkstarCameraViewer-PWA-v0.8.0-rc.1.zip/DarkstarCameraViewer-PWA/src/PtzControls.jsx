import React,{useState} from 'react';
import {api} from './api';
export function PtzControls({camera}) {
  const [busy,setBusy]=useState(false),[error,setError]=useState('');
  const command=async button=>{if(busy)return;setBusy(true);setError('');try{await api('ptz',{method:'POST',body:{key:camera.key,button}})}catch(error){setError(error.message)}finally{setBusy(false)}};
  return <div className="ptz-controls" aria-label="PTZ camera controls"><div>{[['◀',0,'Pan left'],['▲',2,'Tilt up'],['▼',3,'Tilt down'],['▶',1,'Pan right'],['−',6,'Zoom out'],['+',5,'Zoom in']].map(([label,code,name])=><button key={code} disabled={busy} aria-label={name} onClick={()=>command(code)}>{label}</button>)}</div><div><button disabled={busy} onClick={()=>command(4)}>Home</button><button disabled={busy} onClick={()=>command(64)}>Stop</button><small>Tap to nudge</small></div>{error&&<p role="alert">{error}</p>}</div>;
}
