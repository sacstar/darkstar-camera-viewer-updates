export const APP_VERSION='0.8.0-rc.1';
