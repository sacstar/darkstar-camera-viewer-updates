export class TimelineAxis {
  constructor(ranges) {
    let offset=0;
    this.sections=ranges.filter(r=>r.end>r.start).map(range=>{const section={...range,offset};offset+=range.end-range.start;return section});this.duration=offset;
  }
  epochAt(offset){if(!this.sections.length)return 0;const at=Math.max(0,Math.min(this.duration-1,offset)),section=this.sections.find(s=>at<s.offset+s.end-s.start)||this.sections.at(-1);return section.start+Math.trunc(at-section.offset)}
  offsetOf(epoch){const s=this.sections.find(s=>s.end>epoch);return s?s.offset+Math.max(0,epoch-s.start):Math.max(0,this.duration-1)}
  sectionAt(epoch){return this.sections.find(s=>epoch>=s.start&&epoch<s.end)}
  snap(epoch){return this.sectionAt(epoch)?epoch:(this.sections.find(s=>s.start>=epoch)||this.sections.at(-1))?.start??epoch}
  project(start,end){return this.sections.filter(s=>s.end>start&&s.start<end).map(s=>({start:s.offset+Math.max(start,s.start)-s.start,end:s.offset+Math.min(end,s.end)-s.start}))}
}
export function motionAxis(data,bounds,context=5000){
  if(!data.eventsAvailable)return new TimelineAxis([]);
  const intervals=data.events.filter(e=>['motion','person'].includes(e.kind)).flatMap(e=>data.recordings.map(c=>({start:Math.max(bounds.start,c.start,e.start-context),end:Math.min(bounds.end,c.end,e.start+e.duration+context)})).filter(r=>r.end>r.start)).sort((a,b)=>a.start-b.start);
  const merged=[];for(const range of intervals){const last=merged.at(-1);if(last&&range.start<=last.end)last.end=Math.max(last.end,range.end);else merged.push({...range})}return new TimelineAxis(merged);
}
export const zoomedSpan=(span,factor,duration)=>Math.max(Math.min(30000,duration||1),Math.min(duration||1,span/Math.max(.1,Math.min(10,factor))));
export const draggedOffset=(center,delta,width,span,duration)=>Math.max(0,Math.min(Math.max(0,duration-1),center-delta/Math.max(1,width)*span));
