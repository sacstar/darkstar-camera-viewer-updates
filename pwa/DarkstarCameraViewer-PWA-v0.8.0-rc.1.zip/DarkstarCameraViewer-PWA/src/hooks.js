import { useEffect, useRef, useState } from 'react';
import { RequestQueue } from './request-queue';
const previewRequests = new RequestQueue(3);

export function useVisible() {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => { const observer = new IntersectionObserver(entries => { const entry=entries[0]; setVisible(entry.isIntersecting&&entry.intersectionRect.height>0&&entry.intersectionRect.width>0); }, { root:ref.current?.closest('.compact-camera-grid')||null, threshold: [0,0.000001] }); if (ref.current) observer.observe(ref.current); return () => observer.disconnect(); }, []);
  return [ref, visible];
}

export function useDocumentVisible() {
  const [visible, setVisible] = useState(!document.hidden);
  useEffect(() => { const change = () => setVisible(!document.hidden); document.addEventListener('visibilitychange', change); return () => document.removeEventListener('visibilitychange', change); }, []);
  return visible;
}

export function usePreview(camera, active) {
  const [value, setValue] = useState({ url: null, error: null });
  const currentUrl = useRef(null);
  useEffect(() => () => { if (currentUrl.current) URL.revokeObjectURL(currentUrl.current); }, []);
  useEffect(() => {
    if (!active) return;
    let disposed = false, timer;
    const controller = new AbortController();
    const load = async () => {
      try {
        const blob = await previewRequests.run(async()=>{
          const response = await fetch(`/api/sites/${encodeURIComponent(camera.siteId)}/cameras/${encodeURIComponent(camera.id)}/image`, { cache: 'no-store', signal: controller.signal });
          if (!response.ok) throw new Error('Preview unavailable');
          return response.blob();
        },controller.signal);
        if (disposed) return;
        const next = URL.createObjectURL(blob);
        if (currentUrl.current) URL.revokeObjectURL(currentUrl.current);
        currentUrl.current = next; setValue({ url: next, error: null });
      } catch (error) { if (!disposed) setValue(previous => ({ ...previous, error: 'Preview unavailable' })); }
      if (!disposed) timer = setTimeout(load, 5000);
    };
    load();
    return () => { disposed = true; controller.abort(); clearTimeout(timer); };
  }, [camera.siteId, camera.id, active]);
  return value;
}

export function useLive(keys) {
  const [frames, setFrames] = useState({});
  const [connected, setConnected] = useState(false);
  const socket = useRef(null), currentKeys = useRef(keys), urls = useRef(new Map());
  currentKeys.current = keys;
  const serialized = JSON.stringify(keys);
  const subscribe = () => { if (socket.current?.readyState === WebSocket.OPEN) socket.current.send(JSON.stringify({ type: 'subscribe', keys: currentKeys.current })); };
  useEffect(() => {
    let disposed = false, timer;
    const open = () => {
      const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/live`);
      ws.binaryType = 'arraybuffer'; socket.current = ws;
      ws.onopen = () => { setConnected(true); subscribe(); };
      ws.onmessage = event => {
        if (disposed) return;
        if (typeof event.data === 'string') {
          try { const message = JSON.parse(event.data); if (message.type === 'stream-error') setFrames(previous => ({ ...previous, [message.key]: { ...previous[message.key], status: 'error', error: message.message } })); if (message.type === 'stream-status') setFrames(previous => ({ ...previous, [message.key]: { ...previous[message.key], status: message.status, attempt: message.attempt, error: null } })); } catch {}
          return;
        }
        try {
          const view = new DataView(event.data), length = view.getUint16(0);
          const { key } = JSON.parse(new TextDecoder().decode(new Uint8Array(event.data, 2, length)));
          if (!currentKeys.current.includes(key)) return;
          const next = URL.createObjectURL(new Blob([event.data.slice(2 + length)], { type: 'image/jpeg' }));
          const previous = urls.current.get(key); if (previous) URL.revokeObjectURL(previous);
          urls.current.set(key, next);
          setFrames(value => ({ ...value, [key]: { url: next, at: Date.now(), error: null, status: 'ready' } }));
        } catch {}
      };
      ws.onclose = () => { if (!disposed) { setConnected(false); timer = setTimeout(open, 3000); } };
      ws.onerror = () => ws.close();
    };
    open();
    return () => { disposed = true; clearTimeout(timer); socket.current?.close(); for (const url of urls.current.values()) URL.revokeObjectURL(url); urls.current.clear(); };
  }, []);
  useEffect(() => {
    subscribe();
    if (!keys.length) return;
    const keep = new Set(keys);
    for (const [key, url] of urls.current) if (!keep.has(key)) { URL.revokeObjectURL(url); urls.current.delete(key); }
    setFrames(previous => Object.fromEntries(Object.entries(previous).filter(([key]) => keep.has(key))));
  }, [serialized]);
  return { frames, connected, reconnect: subscribe };
}
