import {useEffect,useRef,useState} from 'react';
import {useDocumentVisible} from './hooks';

export function useNativeAv({camera,mode,position,speed,revision,enabled,canvas,onPosition}) {
  const [state,setState]=useState({status:'connecting',error:null}),context=useRef(null),latest=useRef(null),cursor=useRef(position);
  const visible=useDocumentVisible();latest.current={onPosition};
  const prepareAudio=async()=>{context.current??=new AudioContext();await context.current.resume()};
  useEffect(()=>()=>{context.current?.close()},[]);
  useEffect(()=>{
    if(!enabled||!visible)return;
    cursor.current=position;
    if(!globalThis.VideoDecoder){setState({status:'error',error:'This browser needs WebCodecs H.264 support for audio/video. Use current Edge or Chrome, or turn audio off.'});return}
    let disposed=false,configured=false,needKey=true,base=null,decoder,ws;
    const timers=new Map(),sources=new Set(),timestamps=new Map(),requestId=crypto.randomUUID();
    let lastAudio=false;
    setState({status:'connecting',error:null});
    const fail=message=>{if(disposed)return;setState(previous=>({...previous,status:'error',error:message}));ws?.close()};
    const audio=context.current;
    if(!audio||audio.state!=='running'){setState({status:'error',error:'Audio is paused by the browser. Turn audio off and on to enable it.'});return}
    const clock=()=>audio.currentTime;
    const target=pts=>{base??=clock()+.2;return base+pts/1000000};
    decoder=new VideoDecoder({error:()=>fail('H.264 decoding failed. Reconnect or turn audio off to use previews.'),output:frame=>{
      if(disposed){frame.close();return}
      const utc=timestamps.get(frame.timestamp);timestamps.delete(frame.timestamp);
      const wait=(target(frame.timestamp)-clock())*1000;
      if(wait>6000){frame.close();fail('Audio/video fell behind. Reconnect to resume.');return}
      const timer=setTimeout(()=>{
        timers.delete(timer);
        if(!disposed&&canvas.current){const node=canvas.current;node.width=frame.displayWidth;node.height=frame.displayHeight;node.getContext('2d').drawImage(frame,0,0);setState({status:'ready',error:null,audio:lastAudio});if(mode==='playback'&&Number.isFinite(utc)){cursor.current=utc;latest.current.onPosition(utc)}}
        frame.close();
      },Math.max(0,wait));timers.set(timer,frame);
    }});
    ws=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/live`);ws.binaryType='arraybuffer';
    ws.onopen=()=>ws.send(JSON.stringify({type:'av',key:camera.key,mode,position,speed,requestId}));
    ws.onmessage=event=>{
      if(disposed)return;
      try {
        if(typeof event.data==='string'){const message=JSON.parse(event.data);if(message.requestId!==requestId)return;if(message.type==='stream-error')fail(message.message);return}
        const length=new DataView(event.data).getUint16(0),meta=JSON.parse(new TextDecoder().decode(new Uint8Array(event.data,2,length))),data=new Uint8Array(event.data,2+length);
        if(!meta.av||meta.key!==camera.key||meta.requestId!==requestId)return;
        if(meta.kind==='video') {
          if(!configured){if(!meta.codec||!meta.keyframe)return;decoder.configure({codec:meta.codec,codedWidth:meta.width,codedHeight:meta.height,optimizeForLatency:true});configured=true}
          if(needKey&&!meta.keyframe)return;needKey=false;
          if(decoder.decodeQueueSize>60)throw new Error('Video decoding fell behind. Reconnect.');
          target(meta.pts);timestamps.set(Math.trunc(meta.pts),meta.utc);decoder.decode(new EncodedVideoChunk({type:meta.keyframe?'key':'delta',timestamp:Math.trunc(meta.pts),data}));
        }else if(meta.kind==='audio'&&speed===100) {
          lastAudio=true;
          const count=data.byteLength/2/meta.channels,buffer=audio.createBuffer(meta.channels,count,meta.rate),samples=new DataView(data.buffer,data.byteOffset,data.byteLength);
          for(let channel=0;channel<meta.channels;channel++){const out=buffer.getChannelData(channel);for(let i=0;i<count;i++)out[i]=samples.getInt16((i*meta.channels+channel)*2,true)/32768}
          const when=target(meta.pts);if(when-clock()>6)throw new Error('Audio buffering fell behind. Reconnect.');
          // A stale network packet is skipped to retain synchronization with current video.
          if(when+buffer.duration<clock())return;
          const source=audio.createBufferSource();source.buffer=buffer;source.connect(audio.destination);sources.add(source);source.onended=()=>{sources.delete(source);source.disconnect()};source.start(Math.max(clock(),when),Math.max(0,clock()-when));
        }
      }catch(error){fail(error.message||'Audio/video was interrupted.')}
    };
    ws.onerror=()=>fail('The audio/video gateway connection was interrupted.');
    ws.onclose=()=>{if(!disposed)setState(previous=>({...previous,status:'error',error:previous.error||'Audio/video connection closed. Reconnect to resume.'}))};
    return()=>{disposed=true;ws.close();if(decoder.state!=='closed')decoder.close();for(const [timer,frame]of timers){clearTimeout(timer);frame.close()}for(const source of sources){try{source.stop();source.disconnect()}catch{}}};
  },[camera.key,mode,position,speed,revision,enabled,visible]);
  return {...state,prepareAudio,currentPosition:()=>cursor.current,reconnect:()=>{}};
}
