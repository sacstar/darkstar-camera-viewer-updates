#Requires -Version 5.1
[CmdletBinding()]
param([string]$TargetDirectory,[switch]$RestartOnly,[switch]$ConfirmRepair,[switch]$NoBrowser)
$ErrorActionPreference='Stop'
$sourceDirectory=[IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
try {
    if(-not $TargetDirectory){
        Write-Host 'Darkstar gateway repair'
        Write-Host '1. Update an existing PWA folder with this release (preserves its saved settings)'
        Write-Host '2. Restart the gateway from this folder (uses this folder settings)'
        Write-Host '3. Cancel'
        $choice=Read-Host 'Choose 1, 2 or 3'
        if($choice -eq '3'){exit 0}
        if($choice -eq '1'){
            Add-Type -AssemblyName System.Windows.Forms
            $picker=New-Object System.Windows.Forms.FolderBrowserDialog
            $picker.Description='Choose the ORIGINAL Darkstar PWA folder containing your saved .local settings'
            try {if($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){exit 0};$TargetDirectory=$picker.SelectedPath}finally{$picker.Dispose()}
        }elseif($choice -eq '2'){$TargetDirectory=$sourceDirectory;$RestartOnly=$true}else{throw 'No changes made. Choose a listed option.'}
    }
    $targetDirectoryResolved=[IO.Path]::GetFullPath($TargetDirectory).TrimEnd('\')
    $targetManifest=Join-Path $targetDirectoryResolved 'package.json'
    if(-not (Test-Path -LiteralPath $targetManifest -PathType Leaf)){throw 'Choose the existing PWA app folder, not a parent folder or .local itself.'}
    $manifest=Get-Content -LiteralPath $targetManifest -Raw|ConvertFrom-Json
    if($manifest.name -ne 'darkstar-camera-viewer-pwa'){throw 'This is not a Darkstar PWA installation. Nothing was changed.'}
    $vault=Join-Path $targetDirectoryResolved '.local\vault.json'
    Write-Host ('Target: '+$targetDirectoryResolved)
    Write-Host ('Saved settings found: '+(Test-Path -LiteralPath $vault))
    Write-Host 'This stops only the identified local Darkstar gateway. Other apps are not terminated.'
    if(-not $ConfirmRepair -and (Read-Host 'Type REPAIR to continue') -cne 'REPAIR'){Write-Host 'Cancelled. Nothing changed.';exit 0}
    $port=if($env:DARKSTAR_PORT){[int]$env:DARKSTAR_PORT}else{47831};$origin="http://127.0.0.1:$port"
    $running=$null
    try{$running=Invoke-WebRequest $origin -UseBasicParsing -SessionVariable gatewaySession -TimeoutSec 3}catch{if($_.Exception.Response){throw 'The port is occupied by an unrecognized service. Nothing was stopped.'}}
    if($running){
        if($running.Headers['X-Darkstar-Gateway'] -notmatch '^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$'){throw 'This port belongs to another app. Nothing was stopped.'}
        Invoke-RestMethod "$origin/api/shutdown" -Method Post -WebSession $gatewaySession -Headers @{Origin=$origin} -ContentType 'application/json' -Body '{}' -TimeoutSec 10|Out-Null
        $stopped=$false
        for($attempt=0;$attempt -lt 30;$attempt++){try{Invoke-WebRequest $origin -UseBasicParsing -TimeoutSec 1|Out-Null;Start-Sleep -Milliseconds 100}catch{$stopped=$true;break}}
        if(-not $stopped){throw 'The gateway did not stop. No app files were overwritten.'}
    }
    if(Test-Path -LiteralPath $vault){Copy-Item -LiteralPath $vault -Destination ($vault+'.before-repair-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))}
    if(-not $RestartOnly -and $sourceDirectory -ne $targetDirectoryResolved){
        foreach($name in @('src','server','public','dist','package.json','package-lock.json','launch.mjs','gateway-health.mjs','bootstrap.ps1','prerequisites.psm1','verify-dependencies.mjs','save-shortcut.mjs','Start-Darkstar.cmd','Stop-Darkstar.cmd','Setup-Darkstar.cmd','Save-to-Desktop.cmd','Check-Prerequisites.cmd','Repair-Darkstar.cmd','Repair-Darkstar.ps1','README.md','THIRD-PARTY-NOTICES.txt','ensure-media.ps1')){
            $item=Join-Path $sourceDirectory $name
            if(Test-Path -LiteralPath $item){$destination=Join-Path $targetDirectoryResolved $name;if(Test-Path -LiteralPath $item -PathType Container){New-Item -ItemType Directory -Path $destination -Force|Out-Null;Get-ChildItem -LiteralPath $item -Force|ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force}}else{Copy-Item -LiteralPath $item -Destination $destination -Force}}
        }
    }
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $targetDirectoryResolved 'bootstrap.ps1'),'-Action','Start')
    if($NoBrowser){$arguments+='-NoBrowser'}
    & powershell.exe @arguments
    if($LASTEXITCODE -ne 0){throw 'Updated files and settings backup are preserved, but startup failed. Check the target .local logs.'}
    Write-Host 'Gateway repaired. Refresh the browser to load the updated interface.'
}catch{Write-Host ('Repair stopped: '+$_.Exception.Message) -ForegroundColor Red;exit 1}

