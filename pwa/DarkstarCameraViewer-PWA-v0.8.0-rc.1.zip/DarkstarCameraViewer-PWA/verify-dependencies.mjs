import {readFile} from 'node:fs/promises';
const root=new URL('./',import.meta.url);
try {
  const manifest=JSON.parse(await readFile(new URL('package.json',root),'utf8'));
  for(const [name,version] of Object.entries(manifest.dependencies)) {
    const installed=JSON.parse(await readFile(new URL(`node_modules/${name}/package.json`,root),'utf8'));
    if(installed.version!==version)throw new Error('Package version mismatch');
  }
  await import('ws');
}catch{if(!process.argv.includes('--quiet'))console.error('Required app packages are missing, damaged, or out of date.');process.exitCode=1}
