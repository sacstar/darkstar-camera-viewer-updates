$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Security
    $request = [Console]::In.ReadToEnd() | ConvertFrom-Json
    $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
    if ($request.action -eq 'protect') {
        $bytes = [Text.Encoding]::UTF8.GetBytes($request.data)
        $result = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, $scope)
        [Console]::Out.Write([Convert]::ToBase64String($result))
    } elseif ($request.action -eq 'unprotect') {
        $bytes = [Convert]::FromBase64String($request.data)
        $result = [Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, $scope)
        [Console]::Out.Write([Text.Encoding]::UTF8.GetString($result))
    } else { throw 'Unsupported operation' }
} catch {
    [Console]::Error.Write('Windows could not open or protect the local settings vault.')
    exit 1
}
