import { spawn } from 'node:child_process';
import { access } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CameraError } from './blueiris.mjs';
let installing;
export function runMedia(executable,args,{signal,cwd}={}) {
  return new Promise((resolve,reject)=>{
    const child=spawn(executable,args,{cwd,signal,windowsHide:true,stdio:['ignore','ignore','pipe']});
    let diagnostics='';child.stderr.on('data',data=>{diagnostics=(diagnostics+data).slice(-16000)});
    child.once('error',reject);child.once('exit',code=>code===0?resolve(diagnostics):reject(new CameraError('Media stitching failed. Choose clips with matching codec, resolution and audio settings.')));
  });
}
export async function mediaRuntime() {
  if(process.env.DARKSTAR_FFMPEG)return process.env.DARKSTAR_FFMPEG;
  const executable=join(process.env.LOCALAPPDATA||'', 'DarkstarCameraViewer/runtime/media/ffmpeg-win-x86_64-v7.1.exe');
  try{await access(executable);return executable}catch{}
  if(process.platform!=='win32')throw new CameraError('Install FFmpeg and set DARKSTAR_FFMPEG to its executable for stitched exports.');
  installing??=runMedia('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',process.env.DARKSTAR_MEDIA_INSTALLER||fileURLToPath(new URL('../ensure-media.ps1',import.meta.url))]).finally(()=>{installing=null});
  await installing;return executable;
}
