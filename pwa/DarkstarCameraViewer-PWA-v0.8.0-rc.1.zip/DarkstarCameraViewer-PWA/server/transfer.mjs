import { randomBytes, pbkdf2 as derive, createCipheriv, createDecipheriv } from 'node:crypto';
import { promisify } from 'node:util';
import { CameraError, normalizeUrl } from './blueiris.mjs';
const pbkdf2 = promisify(derive);
const aad = Buffer.from('Darkstar Viewer Transfer v1');
const iterations = 210000;
export const transferLimit = 2 * 1024 * 1024;
const fail = () => { throw new CameraError('This backup contains invalid or unsupported settings.'); };
const check = value => { if (!value) fail(); };
const string = (value, max, empty = false) => { check(typeof value === 'string' && value.length <= max && (empty || value.trim())); return value; };
const id = value => { string(value, 100); check(/^[a-z0-9-]+$/i.test(value)); return value; };
const dimension = value => { check(Number.isInteger(value) && value >= 1 && value <= 12); return value; };
const array = (value, max) => { check(Array.isArray(value) && value.length <= max); return value; };
const unique = values => { check(new Set(values).size === values.length); return values; };

export function validateConfig(value) {
  check(value?.format === 'darkstar-viewer-config' && value.version === 1);
  const sites = array(value.sites, 24).map(site => {
    const url = string(site.url, 2048, true), wanUrl = string(site.wanUrl, 2048, true);
    check(url.trim() || wanUrl.trim()); if (url.trim()) normalizeUrl(url); if (wanUrl.trim()) normalizeUrl(wanUrl);
    check(/^#[a-f0-9]{6}$/i.test(site.color));
    return { id: id(site.id), name: string(site.name, 80), url, wanUrl, username: string(site.username, 200), password: string(site.password, 1000, true), color: site.color };
  });
  const ids = new Set(unique(sites.map(site => site.id)));
  const source = value.settings; check(source && typeof source === 'object');
  const siteOrder = unique(array(source.siteOrder, 24).map(key => { check(ids.has(key)); return key; }));
  const views = array(source.views, 50).map(view => ({ id: id(view.id), name: string(view.name, 80), rows: dimension(view.rows), columns: dimension(view.columns), cameras: unique(array(view.cameras, 1000).map(key => { string(key, 512); const colon = key.indexOf(':'); check(colon > 0 && colon < key.length - 1 && ids.has(key.slice(0, colon))); return key; })) }));
  unique(views.map(view => view.id));
  const selectedView = source.selectedView ?? null; check(selectedView === null || views.some(view => view.id === selectedView));
  const pwa = source.pwa || { mode: 'preview', tileSizing: 'fit' };
  const groups=array(pwa.groups||[],100).map(group=>({id:id(group.id),name:string(group.name,80),cameras:unique(array(group.cameras,1000).map(key=>{string(key,512);const colon=key.indexOf(':');check(colon>0&&colon<key.length-1&&ids.has(key.slice(0,colon)));return key;}))}));
  unique(groups.map(g=>g.id));const activeGroup=pwa.activeGroup??null;check(activeGroup===null||groups.some(g=>g.id===activeGroup));
  check(['preview', 'live'].includes(pwa.mode) && ['fit', 'video'].includes(pwa.tileSizing));
  return { format: 'darkstar-viewer-config', version: 1, sites, settings: { rows: dimension(source.rows), columns: dimension(source.columns), selectedView, siteOrder, views, pwa: { mode: pwa.mode, tileSizing: pwa.tileSizing, groups, activeGroup } } };
}
function phrase(value) { check(typeof value === 'string' && value.length >= 12 && value.length <= 256); return value; }
export async function encryptConfig(config, passphrase) {
  const plaintext = Buffer.from(JSON.stringify(validateConfig(config))); check(plaintext.length <= 1024 * 1024);
  const salt = randomBytes(16), iv = randomBytes(12), key = await pbkdf2(phrase(passphrase), salt, iterations, 32, 'sha256');
  try {
    const cipher = createCipheriv('aes-256-gcm', key, iv); cipher.setAAD(aad);
    const data = Buffer.concat([cipher.update(plaintext), cipher.final(), cipher.getAuthTag()]);
    return { format: 'darkstar-viewer-backup', version: 1, kdf: 'PBKDF2-HMAC-SHA256', iterations, cipher: 'AES-256-GCM', salt: salt.toString('base64'), iv: iv.toString('base64'), data: data.toString('base64') };
  } finally { key.fill(0); plaintext.fill(0); }
}
export async function decryptConfig(envelope, passphrase) {
  try {
    check(JSON.stringify(envelope).length <= transferLimit && envelope?.format === 'darkstar-viewer-backup' && envelope.version === 1 && envelope.kdf === 'PBKDF2-HMAC-SHA256' && envelope.iterations === iterations && envelope.cipher === 'AES-256-GCM');
    const decode = value => { check(typeof value === 'string' && /^[A-Za-z0-9+/]*={0,2}$/.test(value)); return Buffer.from(value, 'base64'); };
    const salt = decode(envelope.salt), iv = decode(envelope.iv), data = decode(envelope.data);
    check(salt.length === 16 && iv.length === 12 && data.length >= 16 && data.length <= 1024 * 1024 + 16);
    const key = await pbkdf2(phrase(passphrase), salt, iterations, 32, 'sha256');
    let plaintext;
    try { const cipher = createDecipheriv('aes-256-gcm', key, iv); cipher.setAAD(aad); cipher.setAuthTag(data.subarray(-16)); plaintext = Buffer.concat([cipher.update(data.subarray(0, -16)), cipher.final()]); return validateConfig(JSON.parse(plaintext.toString('utf8'))); }
    finally { key.fill(0); plaintext?.fill(0); }
  } catch { throw new CameraError('Could not open this backup. Check its passphrase, file integrity, and version.'); }
}
export function configFromVault(state, preferences = {}) {
  const sites = state.sites.map(({ id, name, url, wanUrl = '', username, password, color }) => ({ id, name, url, wanUrl, username, password, color }));
  const source = { ...state.transferPreferences, ...preferences };
  return validateConfig({ format: 'darkstar-viewer-config', version: 1, sites, settings: { rows: source.rows || 2, columns: source.columns || 2, selectedView: state.layouts.some(view => view.id === source.activeId) ? source.activeId : null, siteOrder: sites.map(site => site.id), views: state.layouts.map(view => ({ id: view.id, name: view.name, rows: view.rows || 2, columns: view.columns, cameras: view.cameras.filter(key => sites.some(site => key.startsWith(`${site.id}:`))) })), pwa: { mode: source.mode || 'preview', tileSizing: source.tileSizing || 'fit', groups:(state.groups||[]).map(g=>({...g,cameras:g.cameras.filter(key=>sites.some(s=>key.startsWith(`${s.id}:`)))})),activeGroup:(state.groups||[]).some(g=>g.id===source.groupFilter)?source.groupFilter:null } } });
}
export function applyConfig(state, incoming, replace) {
  const config = validateConfig(incoming);
  const sites = replace ? config.sites : [...state.sites.filter(old => !config.sites.some(site => old.id === site.id)), ...config.sites];
  const layouts = replace ? config.settings.views : [...state.layouts.filter(old => !config.settings.views.some(view => old.id === view.id)), ...config.settings.views];
  check(sites.length <= 24 && layouts.length <= 50);
  const order = [...new Set([...config.settings.siteOrder, ...config.sites.map(site => site.id), ...sites.map(site => site.id)])];
  state.sites = order.map(key => sites.find(site => site.id === key)).filter(Boolean);
  state.layouts = layouts.map(view => ({ ...view, updatedAt: Date.now() }));
  const groups=replace?config.settings.pwa.groups:[...(state.groups||[]).filter(old=>!config.settings.pwa.groups.some(g=>g.id===old.id)),...config.settings.pwa.groups];check(groups.length<=100);state.groups=groups;
  state.transferPreferences = { rows: config.settings.rows, columns: config.settings.columns, activeId: config.settings.selectedView, ...config.settings.pwa,groupFilter:config.settings.pwa.activeGroup||'all' };
}
export function selectSites(config,siteIds) {
  if(!Array.isArray(siteIds)||siteIds.some(id=>typeof id!=='string'||!config.sites.some(site=>site.id===id)))throw new CameraError('Choose valid sites for the backup.');
  const ids=new Set(siteIds),sites=config.sites.filter(site=>ids.has(site.id)),views=config.settings.views.map(view=>({...view,cameras:view.cameras.filter(key=>ids.has(key.slice(0,key.indexOf(':'))))})).filter(view=>view.cameras.length);
  const groups=(config.settings.pwa.groups||[]).map(g=>({...g,cameras:g.cameras.filter(key=>ids.has(key.slice(0,key.indexOf(':'))))})).filter(g=>g.cameras.length);
  return validateConfig({...config,sites,settings:{...config.settings,views,pwa:{...config.settings.pwa,groups,activeGroup:groups.some(g=>g.id===config.settings.pwa.activeGroup)?config.settings.pwa.activeGroup:null},siteOrder:config.settings.siteOrder.filter(id=>ids.has(id)),selectedView:views.some(view=>view.id===config.settings.selectedView)?config.settings.selectedView:null}});
}
