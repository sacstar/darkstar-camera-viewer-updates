import { setTimeout as delay } from 'node:timers/promises';
import { CameraError, JpegParser } from './blueiris.mjs';

export class StreamInterrupted extends Error {
  constructor(position, hadFrames, cause) { super('The video connection was interrupted.', { cause }); this.position = position; this.hadFrames = hadFrames; }
}

export async function receiveRecovering({ open, onFrame, onRetry = () => {}, signal, position = 0, speed = 100, clock = () => performance.now(), backoff = (attempt, signal) => delay([500,1500,3000][attempt - 1], undefined, { signal }), stallMs = 15000 }) {
  let cursor = position, hadFrames = false, failures = 0;
  while (!signal.aborted) {
    const requested = cursor, attempt = new AbortController();
    const combined = AbortSignal.any([signal, attempt.signal]);
    let lastFrame = clock();
    const watchdog = setInterval(() => { if (clock() - lastFrame > stallMs) attempt.abort(new DOMException('Video timed out', 'TimeoutError')); }, Math.min(stallMs, 3000));
    try {
      const response = await open(requested, combined);
      const began = clock(); let frames = 0;
      const parser = new JpegParser(frame => {
        if (combined.aborted) return;
        lastFrame = clock(); cursor = requested + Math.max(0, lastFrame - began) * speed / 100;
        onFrame(frame, Math.trunc(cursor)); hadFrames = true;
        if (++frames >= 50 && lastFrame - began >= 5000) failures = 0;
      });
      for await (const chunk of response.body) { if (combined.aborted) break; parser.push(chunk); }
      if (!signal.aborted) throw new Error('The video stream ended.');
    } catch (error) {
      if (signal.aborted) return;
      if ((error instanceof CameraError && !error.allowRouteFallback) || failures >= 3) throw new StreamInterrupted(cursor, hadFrames, error);
    } finally { clearInterval(watchdog); attempt.abort(); }
    if (signal.aborted) return;
    onRetry(++failures, Math.trunc(cursor));
    try { await backoff(failures, signal); } catch (error) { if (signal.aborted) return; throw error; }
  }
}
