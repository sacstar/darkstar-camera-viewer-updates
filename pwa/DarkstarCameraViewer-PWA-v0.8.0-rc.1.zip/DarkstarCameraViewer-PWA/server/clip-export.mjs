import { mkdir,open,writeFile,stat,rm,readdir,rename } from 'node:fs/promises';
import { randomUUID,createHash } from 'node:crypto';
import { join,resolve } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { CameraError,publicError } from './blueiris.mjs';
import { planExport } from '../src/export-plan.js';
import { mediaRuntime,runMedia } from './media-runtime.mjs';

function boxes(buffer) {
  const result=[];
  for(let at=0;at+8<=buffer.length;) {
    let size=buffer.readUInt32BE(at),header=8;if(size===1){if(at+16>buffer.length)throw new CameraError('Invalid MP4 box.');size=Number(buffer.readBigUInt64BE(at+8));header=16}else if(size===0)size=buffer.length-at;
    if(size<header||at+size>buffer.length)throw new CameraError('Invalid MP4 structure.');
    result.push({type:buffer.toString('ascii',at+4,at+8),data:buffer.subarray(at+header,at+size)});at+=size;
  }
  return result;
}
const child=(data,type)=>boxes(data).find(b=>b.type===type)?.data;
export async function inspectMp4(file) {
  const handle=await open(file,'r');let moov,mdat=false;
  try {
    const length=(await handle.stat()).size;
    for(let at=0;at+8<=length;) {
      const header=Buffer.alloc(16);await handle.read(header,0,Math.min(16,length-at),at);
      let size=header.readUInt32BE(0),skip=8;if(size===1){size=Number(header.readBigUInt64BE(8));skip=16}else if(size===0)size=length-at;
      if(!Number.isSafeInteger(size)||size<skip||at+size>length)throw new CameraError('Invalid exported MP4.');
      const type=header.toString('ascii',4,8);
      if(type==='moov'){if(size>32*1024*1024)throw new CameraError('MP4 index exceeds the size limit.');moov=Buffer.alloc(size-skip);await handle.read(moov,0,moov.length,at+skip)}
      if(type==='mdat'&&size>skip)mdat=true;at+=size;
    }
  }finally{await handle.close()}
  if(!moov||!mdat)throw new CameraError('Blue Iris did not return a playable MP4.');
  const mvhd=child(moov,'mvhd');let duration=0;
  if(mvhd){const version=mvhd[0];duration=version===1?Number(mvhd.readBigUInt64BE(24))/mvhd.readUInt32BE(20):mvhd.readUInt32BE(16)/mvhd.readUInt32BE(12)}
  const tracks=[];
  for(const track of boxes(moov).filter(b=>b.type==='trak')) {
    const mdia=child(track.data,'mdia');if(!mdia)continue;
    const hdlr=child(mdia,'hdlr'),kind=hdlr?.toString('ascii',8,12);if(!['vide','soun'].includes(kind))continue;
    const stbl=child(child(mdia,'minf')||Buffer.alloc(0),'stbl');if(!stbl)continue;
    const stsd=child(stbl,'stsd'),stsz=child(stbl,'stsz');if(!stsd||stsd.length<16)continue;
    const entry=boxes(stsd.subarray(8))[0];if(!entry)continue;
    const samples=stsz&&stsz.length>=12?stsz.readUInt32BE(8):0;
    const hasSamples=!!samples&&(stsz.readUInt32BE(4)>0||(stsz.length>=12+samples*4&&stsz.subarray(12).some(v=>v!==0)));
    let width=0,height=0,rate=0,channels=0,configuration='';
    if(kind==='vide'&&entry.data.length>=78){width=entry.data.readUInt16BE(24);height=entry.data.readUInt16BE(26);const config=boxes(entry.data.subarray(78)).filter(b=>['avcC','hvcC','av1C'].includes(b.type));configuration=createHash('sha256').update(Buffer.concat(config.map(b=>b.data))).digest('hex')}
    if(kind==='soun'&&entry.data.length>=28){channels=entry.data.readUInt16BE(16);rate=entry.data.readUInt32BE(24)/65536}
    tracks.push({kind,codec:entry.type,width,height,channels,rate,configuration,hasSamples});
  }
  const video=tracks.find(t=>t.kind==='vide'&&t.hasSamples&&t.width&&t.height);
  if(!video||!(duration>0))throw new CameraError('Export contains no playable video samples.');
  return {width:video.width,height:video.height,duration,audio:tracks.some(t=>t.kind==='soun'&&t.hasSamples),tracks};
}
export async function stitchMp4(files,output,{signal,executable}={}) {
  const details=await Promise.all(files.map(inspectMp4));
  const signature=d=>JSON.stringify(d.tracks.map(({hasSamples,...track})=>track));
  if(details.some(d=>signature(d)!==signature(details[0])))throw new CameraError('These recordings change codec, resolution or audio format. Choose matching recording settings to stitch without quality loss.');
  const list=join(resolve(output,'..'),'segments.txt');
  // Generated filenames only; user/server paths never enter the concat script.
  if(files.some(file=>!/^clip-\d+\.mp4$/.test(file.split(/[\\/]/).at(-1))))throw new CameraError('Invalid local clip name.');
  await writeFile(list,files.map(file=>`file '${file.split(/[\\/]/).at(-1)}'`).join('\n'));
  await runMedia(executable||await mediaRuntime(),['-nostdin','-hide_banner','-loglevel','error','-y','-f','concat','-safe','1','-i',list,'-map','0:v:0','-map','0:a?','-c','copy','-movflags','+faststart',output],{signal});
  const joined=await inspectMp4(output);
  if(details.every(d=>d.audio)&&!joined.audio)throw new CameraError('The stitched MP4 lost its audio track. Nothing was saved.');
  return joined;
}

export class ClipExports {
  constructor(root,options={}){this.root=resolve(root);this.jobs=new Map();this.options=options;}
  view(job){return {id:job.id,status:job.status,message:job.message,details:job.details,size:job.size,pieces:job.pieces}}
  get(id){return this.jobs.get(id)}
  async cleanup(){await mkdir(this.root,{recursive:true});for(const entry of await readdir(this.root,{withFileTypes:true})){if(!entry.isDirectory()||!/^[-a-f0-9]{36}$/.test(entry.name))continue;const folder=join(this.root,entry.name);if(Date.now()-(await stat(folder)).mtimeMs>86400000&&this.jobs.get(entry.name)?.status!=='active'){await rm(folder,{recursive:true,force:true});this.jobs.delete(entry.name)}}}
  start(connection,camera,input,loadRecordings) {
    if([...this.jobs.values()].filter(job=>job.status==='active').length>=2)throw new CameraError('Two exports are already running. Wait or cancel one.');
    if(!['main','sub'].includes(input.stream))throw new CameraError('Choose main or substream.');
    const id=randomUUID(),job={id,status:'active',message:'Loading source recordings…',abort:new AbortController()};this.jobs.set(id,job);
    job.task=this.build(job,connection,camera,input,loadRecordings).catch(error=>{job.status='error';job.message=job.abort.signal.aborted?'Local export cancelled; Blue Iris may finish an already queued job.':publicError(error);});
    return this.view(job);
  }
  async build(job,client,camera,input,loadRecordings) {
    await this.cleanup();const folder=join(this.root,job.id);await mkdir(folder,{recursive:true});
    const signal=job.abort.signal;
    try {
      if(!Number.isSafeInteger(input.start)||!Number.isSafeInteger(input.end)||input.end<=input.start||input.end-input.start>86400000||input.end>Date.now()+1000)throw new CameraError('Choose a valid export time range up to 24 hours.');
      const day=await loadRecordings(input.start,input.end);
      let pieces;try{pieces=planExport(day,input)}catch(error){throw new CameraError(error.message)}
      job.pieces=pieces.length;const connection=await client.exportConnection(),files=[];
      for(const [index,piece] of pieces.entries()) {
        signal.throwIfAborted();job.message=`Preparing clip ${index+1}/${pieces.length} on Blue Iris…`;
        const initial=await connection.queue({path:piece.clip.path,startms:piece.start-piece.clip.start,msec:piece.end-piece.start,audio:true,format:1,substream:input.stream==='main'?2:1,reencode:false,profile:0});
        if(!initial?.path)throw new CameraError('Blue Iris did not return an export job.');
        let result=initial;const deadline=Date.now()+20*60000;
        while(['queued','active'].includes(result.status)){
          if(Date.now()>deadline)throw new CameraError('Blue Iris export timed out. Check its export queue.');
          await delay(this.options.pollMs??2000,undefined,{signal});result=await connection.status(initial.path);job.message=`Clip ${index+1}/${pieces.length}: ${result.status}`;
        }
        if(result.status!=='done')throw new CameraError('Blue Iris could not export this recording. Check BVR support and export permission.');
        job.message=`Downloading and checking clip ${index+1}/${pieces.length}…`;
        const response=await connection.download(result.uri||initial.uri,signal),file=join(folder,`clip-${index+1}.mp4`),output=await open(file,'wx');let total=0;
        try{for await(const chunk of response.body){signal.throwIfAborted();total+=chunk.length;if(total>8*1024**3)throw new CameraError('A clip exceeds 8 GB. Narrow the export range.');await output.write(chunk)}}finally{await output.close()}
        const details=await inspectMp4(file);
        if(!input.allowSilent&&!details.audio)throw new CameraError('This source has no recorded audio. Nothing was saved. Check recording audio or explicitly allow video-only export.');
        files.push(file);
      }
      signal.throwIfAborted();const output=join(folder,'Darkstar-Export.mp4');
      if(files.length===1){await rename(files[0],output);job.details=await inspectMp4(output)}else{
        job.message=`Stitching ${files.length} pieces into one MP4 with audio. First use may download the media runtime…`;
        job.details=await stitchMp4(files,output,{signal,executable:this.options.executable});for(const file of files)await rm(file);
      }
      if(!input.allowSilent&&!job.details.audio)throw new CameraError('The stitched export has no audio. Nothing was saved.');
      job.file=output;job.size=(await stat(output)).size;job.status='ready';job.message=`MP4 ready • ${job.details.width}×${job.details.height} • ${job.details.audio?'audio verified':'video only'}`;
    }catch(error){await rm(folder,{recursive:true,force:true});throw error}
  }
  cancel(id){this.jobs.get(id)?.abort.abort()}
  async close(){for(const job of this.jobs.values())if(job.status==='active')job.abort.abort();await Promise.allSettled([...this.jobs.values()].map(j=>j.task))}
}
