import { CameraError } from './blueiris.mjs';

// Incremental Blue Iris 2.0 framing. Only H.264 and PCM/mu-law audio are accepted.
export class BlueParser {
  constructor(onPacket, speed=100) { this.onPacket=onPacket;this.speed=speed;this.buffer=Buffer.alloc(0);this.audioSamples=0;this.first=null;this.last=null;this.wrap=0;this.videoPts=0;this.ended=false; }
  push(chunk) {
    if(this.ended)return;
    this.buffer=Buffer.concat([this.buffer,chunk]);
    if(this.buffer.length>12*1024*1024)throw new CameraError('Audio/video packet exceeded the size limit.');
    if(!this.format) {
      if(this.buffer.length<6)return;
      const b=this.buffer,size=b[5];
      if(b.toString('ascii',0,4)!=='blue'||![1,2].includes(b[4])||size<40)throw new CameraError('Invalid Blue Iris audio/video header.');
      if(b.length<6+size)return;
      const h=b.subarray(6,6+size),bitmap=h.readUInt32LE(0),width=h.readInt32LE(4),height=Math.abs(h.readInt32LE(8));
      if(bitmap<40||bitmap>size||width<1||height<1||width>16384||height>16384||h.toString('ascii',16,20)!=='H264')throw new CameraError('Choose an H.264 Blue Iris web streaming profile for audio/video.');
      const audio=size-bitmap>=14,tag=audio?h.readUInt16LE(bitmap):0,channels=audio?h.readUInt16LE(bitmap+2):0,rate=audio?h.readUInt32LE(bitmap+4):0;
      if(audio&&(![1,7].includes(tag)||channels<1||channels>2||rate<8000||rate>192000))throw new CameraError('Unsupported Blue Iris audio format.');
      this.format={width,height,tag,channels,rate};this.buffer=b.subarray(6+size);
    }
    while(this.buffer.length>=5) {
      const b=this.buffer;if(b.toString('ascii',0,4)!=='Blue')throw new CameraError('Invalid audio/video packet.');
      const type=b[4];let total;
      if(type===4){this.ended=true;this.buffer=Buffer.alloc(0);return}
      if(type===2){if(b.length<6)return;total=b[5];if(total<6)throw new CameraError('Invalid status packet.');if(b.length<total)return;this.buffer=b.subarray(total);continue}
      const header=type===0?23:type===1?9:0;
      if(!header)throw new CameraError('Unknown audio/video packet.');
      if(b.length<header)return;
      const size=b.readUInt32BE(header-4);total=header+size;
      if(size<1||size>(type===0?10000000:2000000))throw new CameraError('Invalid audio/video packet size.');
      if(b.length<total)return;
      const data=Buffer.from(b.subarray(header,total));this.buffer=b.subarray(total);
      if(type===0) {
        const raw=b.readUInt32BE(7),utc=Number(b.readBigUInt64LE(11));
        this.first??=raw;
        if(this.last!==null&&raw<this.last)this.wrap+=this.last-raw>1000000000?4294967296:this.last-raw+1;
        this.last=raw;this.videoPts=Math.max(this.videoPts,(raw-this.first+this.wrap)*100000/this.speed);
        const nals=annexNals(data),sps=nals.find(n=>n[0]%32===7);
        if(sps)this.codec=`avc1.${sps.subarray(1,4).toString('hex')}`;
        this.onPacket({kind:'video',pts:this.videoPts,utc,keyframe:nals.some(n=>n[0]%32===5),codec:this.codec,...this.format},data);
      } else {
        const {tag,rate,channels}=this.format;
        if(!tag)throw new CameraError('Unexpected audio packet.');
        const pcm=tag===7?muLaw(data):data;
        if(pcm.length%(channels*2))throw new CameraError('Incomplete PCM sample.');
        const pts=this.audioSamples*1000000/rate;this.audioSamples+=pcm.length/(channels*2);
        this.onPacket({kind:'audio',pts,...this.format},pcm);
      }
    }
  }
}
export function muLaw(data) {
  const pcm=Buffer.alloc(data.length*2);
  for(let i=0;i<data.length;i++){const v=(~data[i])&255,m=(((v&15)<<3)+132)<<((v&112)>>4);pcm.writeInt16LE(v&128?132-m:m-132,i*2)}
  return pcm;
}
export function annexNals(data) {
  const starts=[];
  for(let i=0;i+3<data.length;i++)if(data[i]===0&&data[i+1]===0){const n=data[i+2]===1?3:data[i+2]===0&&data[i+3]===1?4:0;if(n){starts.push([i,i+n]);i+=n-1}}
  return starts.map(([,start],i)=>data.subarray(start,starts[i+1]?.[0]??data.length));
}
