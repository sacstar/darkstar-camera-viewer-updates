import { Vault } from './storage.mjs';
import { createGateway } from './gateway.mjs';

try {
  const vault = new Vault();
  await vault.open();
  const gateway = createGateway({ vault });
  const url = await gateway.listen(Number(process.env.DARKSTAR_PORT || 47831));
  console.log(`Darkstar Camera Viewer is ready at ${url}`);
  console.log('Private Windows gateway. Listening on this workstation only.');
  let stopping = false;
  const stop = async () => { if (stopping) return; stopping = true; await gateway.close(); process.exit(0); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
  gateway.server.on('darkstar-stop', stop);
} catch {
  console.error('Darkstar could not start. Check that its local port is available and the encrypted settings belong to this Windows account.');
  process.exitCode = 1;
}
