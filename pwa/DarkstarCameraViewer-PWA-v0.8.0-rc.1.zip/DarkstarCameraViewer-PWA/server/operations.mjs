import {randomUUID} from 'node:crypto';
import {mkdir,appendFile,stat,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {CameraError,publicError} from './blueiris.mjs';
import {eventKind} from '../src/playback-model.js';

const text=(v,max=160)=>typeof v==='string'?v.slice(0,max):typeof v==='number'?String(v):null;
const number=v=>v!==null&&v!==''&&Number.isFinite(Number(v))?Number(v):null;
const escape=v=>String(v??'Not reported').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function maintenance(value,now=Date.now()){
 const reported=text(value);if(!reported)return{reported:null,state:'unknown',expires:null};
 const iso=/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(reported)?Date.parse(reported):NaN;
 return{reported,state:Number.isFinite(iso)?(iso<now?'expired':'active'):/\bexpired\b/i.test(reported)?'expired':'unknown',expires:Number.isFinite(iso)?iso:null};
}
export function telemetry(result={}){
 const s=result.status||{},m=result.metadata||{};
 return{system:text(m.system),version:text(m.version,60),maintenance:maintenance(m.support),permissions:{admin:m.admin===true,changeprofile:m.changeprofile===true},profiles:Array.isArray(m.profiles)?m.profiles.slice(0,8).map(x=>text(x,80)):[],
  cpu:number(s.cpu),ram:text(s.mem??s.ram),physicalRam:text(s.memphys),memoryLoad:text(s.memload),uptime:text(s.uptime),connections:number(s.cxns),warnings:number(s.warnings),profile:number(s.profile),signal:number(s.signal),schedule:text(s.schedule),serverTime:number(s.time),
  disks:(Array.isArray(s.discs)?s.discs:[]).slice(0,24).map(d=>({name:text(d.name,80),allocated:text(d.allocated),used:text(d.used),free:text(d.free),total:text(d.total),freePercent:number(d.total)>0&&number(d.free)!==null&&Number(d.free)>=0&&Number(d.free)<=Number(d.total)?Math.round(Number(d.free)/Number(d.total)*1000)/10:null}))};
}
export function compareVersion(a,b){const parts=v=>/^\d+(?:\.\d+){1,3}(?:[_ -].*)?$/.test(v||'')?v.split(/[_ -]/)[0].split('.').map(Number):null;const x=parts(a),y=parts(b);if(!x||!y)return null;for(let i=0;i<4;i++)if((x[i]||0)!==(y[i]||0))return Math.sign((x[i]||0)-(y[i]||0));return 0;}

export class Operations {
 constructor({state,client,locate,refresh,logRoot,now=Date.now}){Object.assign(this,{state,client,locate,refresh,logRoot,now});this.cache=new Map();this.pending=new Map();this.intents=new Map();this.journal=[];this.tail=Promise.resolve();}
 record(event,fields={}){const row={at:new Date(this.now()).toISOString(),event,...fields};this.journal.push(row);if(this.journal.length>500)this.journal.shift();if(!this.logRoot)return;this.tail=this.tail.then(async()=>{await mkdir(this.logRoot,{recursive:true});const file=join(this.logRoot,'operations.jsonl');if((await stat(file).catch(()=>({size:0}))).size>512000)await rename(file,file+'.previous').catch(()=>{});await appendFile(file,JSON.stringify(row)+'\n');}).catch(()=>{});}
 async site(site){
  if(this.pending.has(site.id))return this.pending.get(site.id);
  const prior=this.cache.get(site.id)||{},now=this.now();
  if(now<(prior.nextAt||0))return prior;
  const task=(async()=>{
   const result={...prior,nextAt:now+15000};
   if(site.status!=='online'){result.error='Site connection unavailable. Camera state cannot be confirmed.';this.cache.set(site.id,result);return result;}
   const connection=this.client(site);
   try{
    if(!prior.healthAt||now-prior.healthAt>=60000){if(typeof connection.health!=='function')throw new CameraError('Health telemetry is not available on this connection.');result.health=telemetry(await connection.health());result.healthAt=now;this.record('health-sampled',{siteId:site.id,cpu:result.health.cpu,warnings:result.health.warnings});}
    result.error=null;result.failures=0;
   }catch(error){result.error=publicError(error);result.failures=(prior.failures||0)+1;result.nextAt=now+Math.min(300000,30000*2**Math.min(result.failures-1,4));this.record('health-unavailable',{siteId:site.id});}
   if(!result.error&&typeof connection.recentAlerts==='function')try{
    const rows=await connection.recentAlerts(now-86400000,now),cameras=new Map(site.cameras.map(c=>[c.id,c]));
    result.alerts=(Array.isArray(rows)?rows:[]).filter(a=>cameras.has(String(a.camera))&&Number.isFinite(Number(a.date))&&Number(a.date)>=946684800&&Number(a.date)*1000<=now+172800000).map(a=>({id:`${site.id}:${a.path||a.clip||a.camera}:${a.date}`,key:cameras.get(String(a.camera)).key,siteId:site.id,siteName:site.name,cameraName:cameras.get(String(a.camera)).name,start:Math.trunc(Number(a.date)*1000),duration:Math.max(1000,Math.min(86400000,Number(a.msec)||1000)),kind:eventKind(a),label:text(a.memo,180)||'Server alert'})).sort((a,b)=>b.start-a.start).slice(0,100);result.alertError=null;result.alertsAt=now;
   }catch(error){result.alertError=publicError(error);}
   this.cache.set(site.id,result);return result;
  })().finally(()=>this.pending.delete(site.id));this.pending.set(site.id,task);return task;
 }
 async snapshot(){const state=this.state();for(let i=0;i<state.sites.length;i+=2)await Promise.all(state.sites.slice(i,i+2).map(s=>this.site(s)));const sites=state.sites.map(s=>{const r=this.cache.get(s.id)||{};return{id:s.id,name:s.name,color:s.color,status:s.status,error:s.error||r.error||null,checkedAt:s.checkedAt||null,healthAt:r.healthAt||null,health:r.health||null,alertError:r.alertError||null,alertsAt:r.alertsAt||null,cameras:s.cameras.map(c=>({key:c.key,id:c.id,name:c.name,enabled:c.enabled,online:s.status==='online'?c.online:null,unreachable:s.status!=='online',fps:c.fps??null,recording:typeof c.recording==='boolean'?c.recording:null,ptz:c.ptz===true})),alerts:r.alerts||[]};});
  const versions=sites.map(s=>s.health?.version).filter(v=>compareVersion(v,v)!==null);const fleetVersion=versions.sort((a,b)=>compareVersion(b,a))[0]||null;
  const counts={sitesOffline:sites.filter(s=>s.status==='offline').length,camerasOffline:0,camerasUnknown:0,camerasUnreachable:0,camerasDisabled:0};for(const s of sites)for(const c of s.cameras){if(!c.enabled)counts.camerasDisabled++;else if(c.unreachable)counts.camerasUnreachable++;else if(c.online===false)counts.camerasOffline++;else if(c.online!==true)counts.camerasUnknown++;}
  for(const site of sites){const compared=compareVersion(site.health?.version,fleetVersion);site.versionState=compared===null?'unknown':compared<0?'behind fleet baseline':'at fleet baseline';}
  return{at:this.now(),counts,fleetVersion,sites,alerts:sites.flatMap(s=>s.alerts).sort((a,b)=>b.start-a.start).slice(0,200)};
 }
 prepare(input){
  const site=this.state().sites.find(s=>s.id===input.siteId);if(!site)throw new CameraError('Choose an existing site.');
  const health=this.cache.get(site.id)?.health;if(!health||site.status!=='online')throw new CameraError('Load current site health before administering this site.');
  const actions=['rename-camera','reset-camera','reboot-host','profile','shield','install-update','archive','schedule','manual-record-limit'];if(!actions.includes(input.action))throw new CameraError('Unsupported administrative action.');
  const profileAction=['profile','shield'].includes(input.action);if(!health.permissions.admin&&!(profileAction&&health.permissions.changeprofile))throw new CameraError('The Blue Iris account does not advertise permission for this action.');
  const args={};let description;
  if(input.action.endsWith('camera')){const found=this.locate(input.key);if(!found||found.site.id!==site.id)throw new CameraError('Choose a camera on this site.');args.camera=found.camera.id;args.key=found.camera.key;description=`${input.action==='rename-camera'?'Rename':'Reset video connection for'} ${found.camera.name} on ${site.name}`;if(input.action==='rename-camera'){args.rename=String(input.value||'').trim();if(!args.rename||args.rename.length>80)throw new CameraError('Camera names must contain 1–80 characters.');description+=` to “${args.rename}”`;}}
  else if(input.action==='profile'){args.profile=Number(input.value);if(!Number.isInteger(args.profile)||args.profile<0||args.profile>7)throw new CameraError('Choose a profile from 0 through 7.');description=`Set ${site.name} to profile ${args.profile}`;}
  else if(input.action==='shield'){args.signal=Number(input.value);if(![0,1,2].includes(args.signal))throw new CameraError('Choose a shield state.');description=`Change the surveillance shield on ${site.name} to ${['red','green','yellow'][args.signal]}`;}
  else if(input.action==='install-update'){const v=String(input.value||'');if(!/^\d{1,3}(\.\d{1,3}){3}$/.test(v)||v.split('.').some(n=>Number(n)>255))throw new CameraError('Enter the exact four-part Blue Iris version, with each part between 0 and 255.');args.update=`${v.split('.').reduce((n,p)=>n*256+Number(p),0)},0`;description=`Install Blue Iris ${v} on ${site.name}. This interrupts surveillance; verify maintenance eligibility and backups first`;}
  else if(input.action==='reboot-host'){args.reboot=true;description=`REBOOT the Windows Blue Iris host for ${site.name}. All cameras on this host will disconnect`;}
  else if(input.action==='manual-record-limit'){args.manrecsec=Number(input.value);if(!Number.isInteger(args.manrecsec)||args.manrecsec<0||args.manrecsec>86400)throw new CameraError('Use 0–86400 seconds; 0 means unlimited.');description=`Change manual recording limit on ${site.name} to ${args.manrecsec} seconds`;}
  else{if(typeof input.value!=='boolean')throw new CameraError('Choose enabled or disabled.');args[input.action]=input.value;description=`${input.value?'Enable':'Disable'} ${input.action==='archive'?'configured FTP backup':'global schedule'} on ${site.name}`;}
  for(const [id,intent]of this.intents)if(intent.expires<this.now())this.intents.delete(id);if(this.intents.size>=64)throw new CameraError('Too many pending actions. Close old confirmation dialogs and retry shortly.');
  const id=randomUUID(),intent={id,siteId:site.id,siteName:site.name,action:input.action,args,description,expires:this.now()+60000};this.intents.set(id,intent);return{id,description,expires:intent.expires};
 }
 async commit(input){const intent=this.intents.get(input.id);if(!intent)throw new CameraError('This action was already submitted or is no longer available.');this.intents.delete(input.id);if(intent.expires<this.now()||input.confirmation!==intent.siteName)throw new CameraError('Confirmation expired or the site name did not match. Prepare the action again.');const site=this.state().sites.find(s=>s.id===intent.siteId);if(!site||site.status!=='online')throw new CameraError('The site is no longer connected. No command was sent.');
  this.record('admin-submitted',{siteId:site.id,action:intent.action});
  try{await this.client(site).administer(intent.action,intent.args);this.cache.delete(site.id);let verified=false;if(intent.action==='rename-camera'){await this.refresh(site);verified=this.locate(intent.args.key)?.camera.name===intent.args.rename;}this.record('admin-accepted',{siteId:site.id,action:intent.action,verified});return{status:'accepted',verified,message:verified?'Camera name verified on Blue Iris. Other clients will see the server name when they refresh.':'Blue Iris accepted the request. Completion has not yet been verified; check the next health refresh.'};}
  catch{this.record('admin-outcome-unknown',{siteId:site.id,action:intent.action});throw new CameraError('The command outcome could not be confirmed. It was not retried. Check the host before submitting another action.');}
 }
 async report(){const state=await this.snapshot();return{format:'darkstar-diagnostics',version:1,...state,alerts:undefined,sites:state.sites.map(({alerts,...s})=>s),journal:[...this.journal],privacy:'No credentials, URLs, license keys, sessions, footage or alert memos are included. Site and camera names are included; review before sharing with AI or a technician.'};}
 async htmlReport(){const r=await this.report();return`<!doctype html><html><meta charset="utf-8"><title>Darkstar equipment health report</title><style>body{font:14px Segoe UI,sans-serif;color:#17273b;max-width:1100px;margin:36px auto;padding:0 24px}h1{border-bottom:3px solid #1680d9;padding-bottom:12px}h2{margin-top:30px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd6df;padding:10px;text-align:left}th{background:#eaf2f8}section{break-inside:avoid}.bad{color:#a02132}small{color:#516579}@media print{body{margin:0;font-size:11px}}</style><h1>Darkstar Technical · Equipment health report</h1><p>Generated ${escape(new Date(r.at).toISOString())}</p><p>${r.counts.sitesOffline} sites offline · ${r.counts.camerasOffline} cameras confirmed offline · ${r.counts.camerasUnreachable} cameras unreachable through offline sites · ${r.counts.camerasUnknown} unknown</p>${r.sites.map(s=>`<section><h2>${escape(s.name)}</h2><p>Connection: ${escape(s.status)} · Blue Iris: ${escape(s.health?.version)} · Maintenance: ${escape(s.health?.maintenance.reported)}</p>${s.error?`<p class="bad">${escape(s.error)}</p>`:''}<table><tr><th>Equipment / condition</th><th>Technician checks</th><th>Completed</th></tr>${s.status!=='online'?'<tr><td>Blue Iris host unreachable</td><td>Check host power, LAN/VPN route, web service, firewall and blocked connections. Verify credentials once before retrying.</td><td>☐</td></tr>':''}${s.cameras.filter(c=>!c.enabled||c.online!==true).map(c=>`<tr><td>${escape(c.name)} · ${!c.enabled?'Disabled':c.unreachable?'Status unconfirmed: host unreachable':c.online===false?'Offline / no signal':'State not reported'}</td><td>${!c.enabled?'Confirm intentional disablement.':c.unreachable?'Restore host connectivity, then recheck camera.':'Check PoE/power, switch link, camera address and stream credentials; inspect the Blue Iris camera status.'}</td><td>☐</td></tr>`).join('')}${s.health?.disks.filter(d=>d.freePercent!==null&&d.freePercent<10).map(d=>`<tr><td>Low disk space: ${escape(d.name)} · ${d.freePercent}% free</td><td>Review retention, archive/storage paths, drive health and capacity before deleting footage.</td><td>☐</td></tr>`).join('')}${s.health?.maintenance.state==='expired'?'<tr><td>Maintenance reported expired</td><td>Verify renewal eligibility in Blue Iris before installing an update.</td><td>☐</td></tr>':''}</table><p><small>Health sampled: ${escape(s.healthAt?new Date(s.healthAt).toISOString():null)}. Unknown telemetry is not proof of healthy equipment.</small></p></section>`).join('')}<p><small>${escape(r.privacy)}</small></p></html>`;}
 async close(){await this.tail;}
}
