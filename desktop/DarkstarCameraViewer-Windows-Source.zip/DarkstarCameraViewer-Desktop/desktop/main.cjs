const {pathToFileURL}=require('node:url');
const {WindowsUpdates}=require('./updates.cjs');

const {app,BrowserWindow,Menu,dialog,ipcMain,nativeTheme,screen,utilityProcess,shell}=require('electron');

const fs=require('node:fs'),path=require('node:path');

app.setName('Darkstar Camera Viewer');

const testData=process.argv.find(v=>v.startsWith('--darkstar-data='));

app.setPath('userData',testData?path.resolve(testData.split('=').slice(1).join('=')):path.join(app.getPath('appData'),'Darkstar Camera Viewer'));

const data=app.getPath('userData'),configFile=path.join(data,'desktop.json');fs.mkdirSync(data,{recursive:true});

let config={theme:'system',port:47841,windows:[]};try{config={...config,...JSON.parse(fs.readFileSync(configFile,'utf8'))}}catch{}

nativeTheme.themeSource=['system','light','dark'].includes(config.theme)?config.theme:'system';

let origin='',worker,quitting=false,shutdown=false,maintenance=false,mainWindow,restarts=[],saveTimer;

const windows=new Set();
const recoveryFile=path.join(__dirname,'recovery.html'),recoveryUrl=pathToFileURL(recoveryFile).href,backupFile=path.join(__dirname,'backup.html'),backupUrl=pathToFileURL(backupFile).href;let lastGatewayFailure=null,restartTimer;
function showRecovery(){for(const win of windows)if(!win.isDestroyed()){try{if(win.webContents.getURL()!==recoveryUrl)win.recoverySearch=new URL(win.webContents.getURL()||origin).search;win.loadFile(recoveryFile).catch(()=>{});}catch{}}}
function restoreWorkspace(){for(const win of windows)if(!win.isDestroyed()){if(win.webContents.getURL()===recoveryUrl)win.loadURL(origin+'/'+(win.recoverySearch||''));else win.webContents.reload();}}
function openBackup(){const win=new BrowserWindow({parent:mainWindow,modal:true,width:640,height:760,minWidth:480,minHeight:500,autoHideMenuBar:true,title:'Export Darkstar sites and settings',webPreferences:webPreferences()});win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',(event,url)=>{if(url!==backupUrl)event.preventDefault()});win.loadFile(backupFile);}
async function repairGateway(){clearTimeout(restartTimer);maintenance=true;try{const previous=worker;if(previous){try{previous.postMessage({type:'stop'})}catch{}await new Promise(resolve=>{const timer=setTimeout(()=>{previous.kill();resolve()},2000);previous.once('exit',()=>{clearTimeout(timer);resolve()})});}restarts=[];await startGateway();restoreWorkspace();log('gateway-repaired');return{ready:true};}finally{maintenance=false;}}

const updater=new WindowsUpdates({version:app.getVersion(),directory:path.join(data,'updates'),preferences:config.updates,save:value=>{config.updates=value;scheduleSave();},notify:value=>{for(const win of windows)if(!win.isDestroyed())win.webContents.send('darkstar:updates',value);}});

function log(event,detail={}){try{const dir=path.join(data,'logs');fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,'desktop.jsonl');if(fs.existsSync(file)&&fs.statSync(file).size>1048576){for(let i=3;i>=1;i--){const a=`${file}.${i}`,b=`${file}.${i+1}`;if(fs.existsSync(a)){if(fs.existsSync(b))fs.unlinkSync(b);fs.renameSync(a,b);}}fs.renameSync(file,`${file}.1`);}fs.appendFileSync(file,JSON.stringify({at:new Date().toISOString(),event,...detail})+'\n');}catch{}}

function persist(){try{config.windows=[...windows].filter(w=>!w.isDestroyed()).map(w=>({search:new URL(w.webContents.getURL()||origin).search,bounds:w.getNormalBounds(),maximized:w.isMaximized(),fullscreen:w.isFullScreen()}));fs.writeFileSync(configFile+'.tmp',JSON.stringify(config));fs.renameSync(configFile+'.tmp',configFile);}catch{}}

function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(persist,500);}

function fit(bounds){const display=screen.getDisplayMatching(bounds||screen.getPrimaryDisplay().workArea),area=display.workArea;return {x:Math.max(area.x,Math.min(bounds?.x??area.x,area.x+area.width-480)),y:Math.max(area.y,Math.min(bounds?.y??area.y,area.y+area.height-360)),width:Math.min(Math.max(bounds?.width||1440,480),area.width),height:Math.min(Math.max(bounds?.height||950,360),area.height)};}

const webPreferences=()=>({preload:path.join(__dirname,'preload.cjs'),sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true});

function attach(win){

 windows.add(win);win.setMenuBarVisibility(false);

 win.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith(origin+'/'))event.preventDefault();});

 win.webContents.setWindowOpenHandler(({url})=>{if(!url.startsWith(origin+'/')||windows.size>=16)return{action:'deny'};return{action:'allow',overrideBrowserWindowOptions:{backgroundColor:nativeTheme.shouldUseDarkColors?'#080e17':'#f4f6fa',autoHideMenuBar:true,webPreferences:webPreferences()}};});

 win.webContents.on('did-create-window',child=>attach(child));

 let failures=[];win.webContents.on('render-process-gone',(_event,details)=>{log('renderer-exit',{reason:details.reason});failures=failures.filter(t=>Date.now()-t<600000);if(!quitting&&failures.length<3){failures.push(Date.now());setTimeout(()=>{if(!win.isDestroyed())win.webContents.reload();},1000);}else if(!quitting)dialog.showMessageBox(win,{type:'error',message:'This camera window repeatedly failed. Other windows remain available. Close this window and use Diagnostics to investigate.'});});

 let hung;win.on('unresponsive',()=>{log('renderer-unresponsive');hung=setTimeout(()=>{if(!win.isDestroyed()&&!quitting)win.webContents.reload();},20000);});win.on('responsive',()=>clearTimeout(hung));

 win.on('resize',scheduleSave);win.on('move',scheduleSave);win.on('enter-full-screen',scheduleSave);win.on('leave-full-screen',scheduleSave);

 win.on('closed',()=>{clearTimeout(hung);windows.delete(win);if(!quitting)scheduleSave();});

}

function openWindow(saved={}){const win=new BrowserWindow({...fit(saved.bounds),minWidth:480,minHeight:360,show:false,title:'Darkstar Camera Viewer',backgroundColor:nativeTheme.shouldUseDarkColors?'#080e17':'#f4f6fa',autoHideMenuBar:true,icon:path.join(__dirname,'../dist/icon.ico'),webPreferences:webPreferences()});attach(win);win.once('ready-to-show',()=>{win.show();if(saved.maximized)win.maximize();if(saved.fullscreen)win.setFullScreen(true);});win.loadURL(origin+'/' +(saved.search||''));return win;}

async function startGateway(){return new Promise((resolve,reject)=>{

 const child=utilityProcess.fork(path.join(__dirname,'worker.mjs'),[],{serviceName:'Darkstar camera gateway',stdio:'pipe',env:{...process.env,DARKSTAR_DESKTOP_DATA:data,DARKSTAR_DESKTOP_PORT:String(config.port),DARKSTAR_MEDIA_INSTALLER:app.isPackaged?path.join(process.resourcesPath,'ensure-media.ps1'):path.join(__dirname,'../ensure-media.ps1')}});worker=child;child.stdout?.resume();child.stderr?.resume();

 const timeout=setTimeout(()=>reject(Error('Gateway startup timed out')),30000);let ready=false;

 child.on('message',message=>{if(message.type==='fatal'){lastGatewayFailure=message;log('gateway-fatal',{errorClass:message.errorClass,errorCode:message.errorCode,safeMessage:message.safeMessage,frames:message.frames});}if(message.type==='ready'){clearTimeout(timeout);ready=true;origin=message.origin;log('gateway-ready');resolve();}if(message.type==='failed'){clearTimeout(timeout);reject(Error(message.message));}});

 child.on('exit',code=>{clearTimeout(timeout);log('gateway-exit',{code});if(!ready){reject(Error('Gateway stopped during startup'));return;}if(quitting||maintenance||worker!==child)return;restarts=restarts.filter(t=>Date.now()-t<600000);if(restarts.length>=3){showRecovery();dialog.showMessageBox(mainWindow,{type:'error',buttons:['Open diagnostic folder','Restart gateway','Close'],defaultId:0,cancelId:2,message:'Darkstar gateway stopped',detail:'Automatic recovery paused after repeated failures. Saved settings are preserved. '+(lastGatewayFailure?.safeMessage||('Gateway exit code: '+code))}).then(async answer=>{if(answer.response===0)await shell.openPath(path.join(data,'logs'));if(answer.response===1)await repairGateway();}).catch(()=>{});return;}restarts.push(Date.now());showRecovery();restartTimer=setTimeout(async()=>{if(maintenance||quitting)return;try{await startGateway();restoreWorkspace();}catch{log('gateway-recovery-failed');}},1500);});

 });}

async function importSettings(){const choice=await dialog.showOpenDialog(mainWindow,{title:'Select the existing Darkstar PWA folder',properties:['openDirectory']});if(choice.canceled)return false;const root=choice.filePaths[0];const file=fs.existsSync(path.join(root,'.local','vault.json'))?path.join(root,'.local','vault.json'):path.join(root,'vault.json');

 try{const {Vault}=await import('../server/storage.mjs');const previous=new Vault(path.dirname(file));await previous.open();if(!fs.existsSync(file))throw Error();const target=path.join(data,'.local','vault.json');if(fs.existsSync(target)){const answer=await dialog.showMessageBox(mainWindow,{type:'warning',buttons:['Cancel','Replace desktop settings'],defaultId:0,cancelId:0,message:'Replace this desktop appâ€™s saved settings? The existing encrypted vault will be backed up. The PWA original stays unchanged.'});if(answer.response!==1)return false;fs.copyFileSync(target,target+'.before-import-'+Date.now());}fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(file,target);log('settings-imported');app.relaunch();await quit();return true;}catch{dialog.showErrorBox('Import did not complete','Choose the original PWA folder belonging to this Windows account. No settings were replaced.');return false;}}

async function quit(){if(quitting)return;persist();quitting=true;clearTimeout(saveTimer);clearTimeout(restartTimer);const previous=worker;worker=null;try{if(previous?.pid){previous.postMessage({type:'stop'});await new Promise(resolve=>{const timer=setTimeout(()=>{try{previous.kill()}catch{}resolve()},3000);previous.once('exit',()=>{clearTimeout(timer);resolve()})});}}catch{}shutdown=true;app.quit();}

if(!app.requestSingleInstanceLock()){app.quit();}else{

 app.on('second-instance',()=>{if(mainWindow&&!mainWindow.isDestroyed()){mainWindow.restore();mainWindow.show();mainWindow.focus();}});

 app.on('before-quit',event=>{if(!shutdown){event.preventDefault();quit();}});app.on('window-all-closed',()=>quit());

 app.whenReady().then(async()=>{

  const trusted=event=>{if(!event.senderFrame?.url.startsWith(origin+'/')&&event.senderFrame?.url!==recoveryUrl&&event.senderFrame?.url!==backupUrl)throw Error('Unavailable');};

  ipcMain.handle('darkstar:repair',event=>{trusted(event);return repairGateway();});
  ipcMain.handle('darkstar:open-logs',async event=>{trusted(event);await shell.openPath(path.join(data,'logs'));return true;});
  ipcMain.handle('darkstar:open-backup',event=>{trusted(event);openBackup();return true;});
  ipcMain.handle('darkstar:backup-summary',async event=>{trusted(event);const {Vault}=await import('../server/storage.mjs');const vault=new Vault(path.join(data,'.local'));if(!fs.existsSync(vault.file))throw Error('No saved settings vault was found for this Windows account.');await vault.open();return{sites:vault.state.sites.map(s=>({id:s.id,name:s.name})),views:vault.state.layouts.length};});
  ipcMain.handle('darkstar:export-settings',async(event,input)=>{trusted(event);if(typeof input?.passphrase!=='string'||input.passphrase.length<12||input.passphrase.length>256)throw Error('Invalid backup passphrase');const {Vault}=await import('../server/storage.mjs'),{configFromVault,selectSites,encryptConfig}=await import('../server/transfer.mjs');const vault=new Vault(path.join(data,'.local'));if(!fs.existsSync(vault.file))throw Error('No saved settings vault was found for this Windows account.');await vault.open();const config=selectSites(configFromVault(vault.state),input.siteIds);const encrypted=await encryptConfig(config,input.passphrase);const owner=BrowserWindow.fromWebContents(event.sender),choice=await dialog.showSaveDialog(owner,{title:'Save encrypted Darkstar settings',defaultPath:path.join(app.getPath('downloads'),'Darkstar-backup-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json'),filters:[{name:'Encrypted Darkstar backup',extensions:['json']}]});if(choice.canceled)return{cancelled:true};await fs.promises.writeFile(choice.filePath,JSON.stringify(encrypted),{mode:0o600});log('settings-exported');return{path:choice.filePath};});
  ipcMain.handle('darkstar:updates',event=>{trusted(event);return updater.state;});

  ipcMain.handle('darkstar:update-prefs',(event,input)=>{trusted(event);return updater.setPreferences(input||{});});

  ipcMain.handle('darkstar:check-updates',event=>{trusted(event);return updater.check();});

  ipcMain.handle('darkstar:download-update',event=>{trusted(event);return updater.download();});

  ipcMain.handle('darkstar:install-update',async event=>{trusted(event);const result=await updater.install();setTimeout(()=>quit(),500);return result;});

  ipcMain.handle('darkstar:screens',event=>{if(!event.senderFrame.url.startsWith(origin+'/'))throw Error('Unavailable');return screen.getAllDisplays().map(d=>({label:d.label||`Monitor ${d.id}`,nativeId:String(d.id),availLeft:d.workArea.x,availTop:d.workArea.y,availWidth:d.workArea.width,availHeight:d.workArea.height,isPrimary:d.id===screen.getPrimaryDisplay().id}));});

  ipcMain.handle('darkstar:version',()=>app.getVersion());ipcMain.handle('darkstar:theme',(_event,source)=>{if(!['system','light','dark'].includes(source))return;nativeTheme.themeSource=source;config.theme=source;scheduleSave();});ipcMain.handle('darkstar:import',event=>event.senderFrame.url.startsWith(origin+'/')?importSettings():false);

  Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'File',submenu:[{label:'Export sites and settings...',click:openBackup},{label:'Import existing PWA settingsâ€¦',click:importSettings},{label:'Repair local gatewayâ€¦',click:async()=>{const answer=await dialog.showMessageBox(mainWindow,{type:'question',buttons:['Cancel','Restart gateway'],defaultId:0,message:'Restart the local camera gateway? Saved sites, groups and layouts will be kept. Playback will briefly disconnect.'});if(answer.response!==1)return;maintenance=true;try{const previous=worker;previous.postMessage({type:'stop'});await new Promise(resolve=>{const timer=setTimeout(()=>{previous.kill();resolve();},5000);previous.once('exit',()=>{clearTimeout(timer);resolve();});});await startGateway();for(const win of windows)if(!win.isDestroyed())win.webContents.reload();log('gateway-repaired');}catch{dialog.showErrorBox('Repair did not finish','Settings were kept. Close and reopen Darkstar to retry.');}finally{maintenance=false;}}},{label:'Exit',click:quit}]},{label:'View',submenu:[{role:'reload'},{role:'togglefullscreen'},{label:'Theme',submenu:['system','light','dark'].map(theme=>({label:theme[0].toUpperCase()+theme.slice(1),type:'radio',checked:config.theme===theme,click:()=>{nativeTheme.themeSource=theme;config.theme=theme;scheduleSave();}}))}]}]));

  screen.on('display-removed',()=>{for(const win of windows)if(!win.isDestroyed())win.setBounds(fit(win.getNormalBounds()));});

  setTimeout(()=>{if(updater.preferences.autoCheck)void updater.check();},3000);setInterval(()=>{if(updater.preferences.autoCheck)void updater.check();},6*3600000).unref();
  try{await startGateway();const saved=config.windows.length?config.windows:[{}];mainWindow=openWindow(saved[0]);for(const state of saved.slice(1,16))openWindow(state);mainWindow.on('close',event=>{if(!quitting){event.preventDefault();quit();}});log('application-ready',{version:app.getVersion()});}catch{log('gateway-startup-failed');origin=origin||('http://127.0.0.1:'+config.port);mainWindow=new BrowserWindow({...fit(config.windows[0]?.bounds),show:true,title:'Darkstar recovery',autoHideMenuBar:true,webPreferences:webPreferences()});attach(mainWindow);mainWindow.loadFile(recoveryFile);mainWindow.on('close',event=>{if(!quitting){event.preventDefault();quit();}});}

 });

}



