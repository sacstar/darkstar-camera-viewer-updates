export function failureReport(error,sites=[]){
 let message=String(error?.message||'The gateway exited unexpectedly.').slice(0,2000);
 const secrets=sites.flatMap(s=>[s.password,s.username,s.url,s.wanUrl,...[s.url,s.wanUrl].flatMap(value=>{try{const url=new URL(value);return[url.host,url.hostname]}catch{return[]}})]).filter(v=>typeof v==='string'&&v.length>=3).sort((a,b)=>b.length-a.length);
 for(const value of secrets)message=message.split(value).join('[redacted]');
 message=message.replace(/(?:https?|rtsp):\/\/[^\s)]+/gi,'[address]').replace(/(?:session|password|response|token)\s*[=:]\s*[^\s,;]+/gi,'[credential redacted]');
 const frames=String(error?.stack||'').split('\n').slice(1,12).map(line=>/([\w.-]+\.(?:mjs|cjs|js)):(\d+):(\d+)/.exec(line)?.slice(1).join(':')).filter(Boolean).join(' > ');
 return{at:new Date().toISOString(),errorClass:/^[\w]+$/.test(error?.name||'')?error.name:'Error',errorCode:/^[\w-]+$/.test(String(error?.code||''))?String(error.code):null,safeMessage:message,frames};
}
