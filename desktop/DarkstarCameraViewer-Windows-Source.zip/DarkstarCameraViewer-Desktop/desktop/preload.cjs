const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('darkstarDesktop',{
 updates:()=>ipcRenderer.invoke('darkstar:updates'),
 checkUpdates:()=>ipcRenderer.invoke('darkstar:check-updates'),
 downloadUpdate:()=>ipcRenderer.invoke('darkstar:download-update'),
 installUpdate:()=>ipcRenderer.invoke('darkstar:install-update'),
 updatePreferences:input=>ipcRenderer.invoke('darkstar:update-prefs',input),
 onUpdates:callback=>{const listener=(_event,value)=>callback(value);ipcRenderer.on('darkstar:updates',listener);return()=>ipcRenderer.removeListener('darkstar:updates',listener);},
 onOpenUpdates:callback=>{const listener=()=>callback();ipcRenderer.on('darkstar:open-updates',listener);return()=>ipcRenderer.removeListener('darkstar:open-updates',listener);},
 screens:()=>ipcRenderer.invoke('darkstar:screens'),
 importSettings:()=>ipcRenderer.invoke('darkstar:import'),
 setTheme:source=>ipcRenderer.invoke('darkstar:theme',source),
 version:()=>ipcRenderer.invoke('darkstar:version')
});
