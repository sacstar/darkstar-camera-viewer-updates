import {failureReport} from './failure-report.mjs';
import {mkdirSync,appendFileSync,statSync,renameSync,unlinkSync} from 'node:fs';
import {Vault} from '../server/storage.mjs';

import {createGateway} from '../server/gateway.mjs';

import {join} from 'node:path';

const parent=process.parentPort;

let gateway,vault;
function recordFailure(error){const detail=failureReport(error,vault?.state.sites||[]);try{parent.postMessage({type:'fatal',...detail});}catch{}try{const root=join(process.env.DARKSTAR_DESKTOP_DATA,'logs');mkdirSync(root,{recursive:true});const file=join(root,'gateway-fatal.jsonl');if((()=>{try{return statSync(file).size>512000}catch{return false}})()){try{unlinkSync(file+'.previous')}catch{}renameSync(file,file+'.previous');}appendFileSync(file,JSON.stringify(detail)+'\n');}catch{}}
process.on('uncaughtExceptionMonitor',recordFailure);
process.on('unhandledRejection',reason=>{throw reason instanceof Error?reason:Error('An asynchronous gateway operation failed.');});

try{

 vault=new Vault(join(process.env.DARKSTAR_DESKTOP_DATA,'.local'));await vault.open();

 gateway=createGateway({vault,exportRoot:join(process.env.DARKSTAR_DESKTOP_DATA,'.local','exports'),diagnosticRoot:join(process.env.DARKSTAR_DESKTOP_DATA,'logs','operations')});

 const origin=await gateway.listen(Number(process.env.DARKSTAR_DESKTOP_PORT||47841));

 parent.postMessage({type:'ready',origin});

 parent.on('message',async event=>{if(event.data?.type==='stop'){await gateway.close();process.exit(0);}});

}catch(error){recordFailure(error);parent.postMessage({type:'failed',code:error?.code||'STARTUP',message:'The gateway could not start. Check its port and encrypted settings.'});process.exitCode=1;}

