import {Vault} from '../server/storage.mjs';
import {createGateway} from '../server/gateway.mjs';
import {join} from 'node:path';
const parent=process.parentPort;
let gateway;
try{
 const vault=new Vault(join(process.env.DARKSTAR_DESKTOP_DATA,'.local'));await vault.open();
 gateway=createGateway({vault,exportRoot:join(process.env.DARKSTAR_DESKTOP_DATA,'.local','exports'),diagnosticRoot:join(process.env.DARKSTAR_DESKTOP_DATA,'logs','operations')});
 const origin=await gateway.listen(Number(process.env.DARKSTAR_DESKTOP_PORT||47841));
 parent.postMessage({type:'ready',origin});
 parent.on('message',async event=>{if(event.data?.type==='stop'){await gateway.close();process.exit(0);}});
}catch(error){parent.postMessage({type:'failed',code:error?.code||'STARTUP',message:'The gateway could not start. Check its port and encrypted settings.'});process.exitCode=1;}
