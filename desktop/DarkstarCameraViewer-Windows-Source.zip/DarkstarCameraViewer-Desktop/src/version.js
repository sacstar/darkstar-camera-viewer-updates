export const APP_VERSION='0.8.2-rc.1';
