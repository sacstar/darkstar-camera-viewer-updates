const assert=require('node:assert/strict');
const path=require('node:path');
const {WindowsUpdates}=require('../desktop/updates.cjs');
const {version}=require('../package.json');
(async()=>{
 const updater=new WindowsUpdates({version:'0.0.0',directory:path.join(process.env.RUNNER_TEMP||process.cwd(),'darkstar-online-check'),preferences:{includePreview:true},fetcher:(url,options={})=>fetch(url,{...options,...(url.startsWith('https://api.github.com/')?{headers:{...options.headers,Authorization:'Bearer '+process.env.GH_TOKEN}}:{})})});
 let result;for(let attempt=0;attempt<4;attempt++){result=await updater.check();if(result.release?.version===version)break;await new Promise(resolve=>setTimeout(resolve,5000));}
 assert.equal(result.release?.version,version,'The published Windows release must be discoverable');
 result=await updater.download();assert.equal(result.status,'downloaded',result.message);
 console.log('Published Windows installer discovered, downloaded and SHA-256 verified:',version);
})().catch(error=>{console.error(error.message);process.exitCode=1});
