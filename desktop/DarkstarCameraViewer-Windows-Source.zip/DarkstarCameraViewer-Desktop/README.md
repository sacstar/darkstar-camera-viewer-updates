# Darkstar Windows 0.8.1-rc.1 authentication hotfix

Retains startup GitHub update checks and all 0.8.0 preview camera/operations features. Fixes repeated authentication requests that could contribute to Blue Iris auto-banning the viewer workstation.

Credentialed login responses are never replayed after a transport error. HTTP 403 or unexpected media content does not discard a valid session or trigger a new login. Permission-rejected status/clip requests no longer reauthenticate. One rejected or uncertain credentialed login pauses authentication for that site across previews, background polls, streams and LAN/WAN routing. The hold is stored in the encrypted vault and survives gateway/app restart. General Refresh does not clear it. After reviewing the site login and ban status, explicitly save its connection settings to allow one new attempt. Session renewal is bounded to one per minute; repeated session rejection requires review.

The exact cause of existing server-side bans still requires the Blue Iris Connections/Messages logs. No live Blue Iris login probes were used to diagnose or test this fix. The redesigned alert sidebar and additional features are being developed separately.

Validation: four new HTTP fixture regression tests plus the existing Windows updater tests. The ordinary desktop runtime and media-on-demand installation behavior are retained. This is an unsigned preview.
