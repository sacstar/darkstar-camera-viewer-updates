# Darkstar Camera Viewer for Windows 0.8.0-rc.1

This preview adds Ops Center, Admin, a live-updating Latest clips rail, technician HTML reports, AI-ready diagnostic JSON and Windows updates from GitHub. The camera grid owns scrolling; the page and its controls stay fixed. Existing sites/groups/layouts and encrypted portable import/export remain available.

Install the single Setup EXE. Camera viewing includes Electron/Chromium and Node; no separate browser or Node installation is required. The optional media tool for stitched MP4 exports downloads automatically on first use from its upstream distributor, with a pinned SHA-256 check. Internet access is required for that first media install and for updates. FFmpeg is not bundled in this installer.

Existing Windows settings remain in %APPDATA%/Darkstar Camera Viewer. To copy the original PWA configuration on the same Windows account, use File > Import existing PWA settings; it leaves the original vault intact. Use encrypted import/export to move settings to another device/account.

Latest clips lists server alerts from the past 24 hours, updates every 15 seconds while the app is visible, and defaults to motion/person filtering. Click an item to open that camera's playback at the event timestamp. Unavailable sites and alert access errors are identified. This is polling, not push notification delivery.

Ops Center shows server-reported CPU, memory, disk values, uptime, warnings, camera state/FPS, version and maintenance text where Blue Iris supplies them. Unknown fields remain unknown. Numeric disk values retain server units; percentages are derived only from compatible numeric values. Version comparison is against the highest comparable version in the fleet, not the vendor's latest release. Ambiguous maintenance dates remain unclassified.

Admin supports server camera rename, video connection reset, profile/shield selection, configured FTP backup/global schedule/manual recording limit, exact-version Blue Iris update requests and host reboot. The Blue Iris account must advertise permissions. Every command requires a single-use confirmation naming the exact site. Mutations are never automatically replayed after an uncertain response. Acceptance by Blue Iris does not prove reboot/update completion; check the subsequent health state. Real host reboots/updates were not performed during development.

File > App updates (or the header download icon) checks Windows releases from sacstar/darkstar-camera-viewer-updates. Automatic checks are enabled on startup and every six hours; preview builds include preview releases by default. Android and PWA release tags are ignored. Downloads must match a Windows-specific manifest, exact repository asset URL, expected file size and SHA-256. The checksum is checked again immediately before launching the installer. Installation requires the user's Install action. This preview is unsigned.

Validation: 46 gateway/protocol/storage tests and 5 Windows updater tests passed. Browser fixture checks covered 100 grid/sizing/display combinations, fixed controls and grid-only scrolling, clip playback timestamps, health page, private diagnostics and confirmed server rename. The packaged Windows executable passed launch, native update-settings/monitor bridge, renderer crash recovery, gateway crash recovery and manual gateway repair with an unchanged encrypted vault. Interactive/silent installer acceptance, physical multi-monitor/mixed-DPI and prolonged real-site qualification remain pending.

Matrix profiles, incident notebooks, full vendor-latest checks, automatic update policy controls for Blue Iris, local/API AI analysis and broader fleet management are not complete. AI analysis is disabled; reports may be reviewed and shared separately. This is a preview, not a production-qualified release.

Protocol reference: https://blueirissoftware.com/BlueIris.PDF

Build: npm ci --ignore-scripts; node node_modules/electron/install.js; node --test test/*.test.cjs; npm run dist:win.
