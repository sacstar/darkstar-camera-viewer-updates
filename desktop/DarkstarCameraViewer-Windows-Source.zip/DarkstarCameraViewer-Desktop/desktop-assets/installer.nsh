!ifndef BUILD_UNINSTALLER
  !define MUI_LICENSEPAGE_CHECKBOX
  !define MUI_LICENSEPAGE_CHECKBOX_TEXT "I have read and accept the test-version terms and notices."
!endif
