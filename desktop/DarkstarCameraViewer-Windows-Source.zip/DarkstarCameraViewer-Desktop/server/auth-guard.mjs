import {CameraError} from './blueiris.mjs';
// One gate is shared by every route, preview, stream and background task for a site.
export class AuthenticationGuard {
 constructor({blocked=false,onBlock,now=Date.now}={}){Object.assign(this,{blocked,onBlock,now});this.lastRenewal=-Infinity;this.pending=Promise.resolve();}
 error(){const error=new CameraError('Sign-in failed or was repeatedly rejected. Automatic authentication is paused. Verify this site login and any Blue Iris ban, then save corrected connection settings.');error.authBlocked=true;return error;}
 assert(){if(this.blocked)throw this.error();}
 fail(code){if(!this.blocked){this.blocked=true;this.pending=Promise.resolve(this.onBlock?.(code)).catch(()=>{});}return this.error();}
 renew(){this.assert();if(this.now()-this.lastRenewal<60000)throw this.fail('repeated-session-rejection');this.lastRenewal=this.now();}
}
