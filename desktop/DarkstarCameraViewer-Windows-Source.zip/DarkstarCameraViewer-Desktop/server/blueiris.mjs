import {AuthenticationGuard} from './auth-guard.mjs';
import { createHash } from 'node:crypto';

import { setTimeout as delay } from 'node:timers/promises';

import { parseRecordings, parseEvents } from '../src/playback-model.js';



export class CameraError extends Error { constructor(message,allowRouteFallback=false){super(message);this.allowRouteFallback=allowRouteFallback} }

export function normalizeUrl(value) {

  let url;

  try { url = new URL(String(value).trim()); } catch { throw new CameraError('Enter a full server address beginning with http:// or https://.'); }

  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new CameraError('Use an HTTP or HTTPS address without embedded credentials, query, or fragment.');

  return url.href.replace(/\/+$/, '');

}

export function cleanProfile(input, previous) {

  const name = String(input.name || '').trim();

  const username = String(input.username || '').trim();

  if (!name || name.length > 80) throw new CameraError('Enter a site name, up to 80 characters.');

  if (!username || username.length > 200) throw new CameraError('Enter a Blue Iris username.');

  const password = typeof input.password === 'string' && input.password.length ? input.password : previous?.password;

  if (typeof password !== 'string' || password.length > 1000) throw new CameraError('Enter a password for this site.');

  const url = String(input.url || '').trim(), wanUrl = String(input.wanUrl ?? previous?.wanUrl ?? '').trim();

  if (!url && !wanUrl) throw new CameraError('Enter a local or WAN server address.');

  return { id: previous?.id, name, url: url ? normalizeUrl(url) : '', wanUrl: wanUrl ? normalizeUrl(wanUrl) : '', username, password, color: /^#[0-9a-f]{6}$/i.test(input.color) ? input.color : '#459bff' };

}

export function publicError(error) {

  if (error instanceof CameraError) return error.message;

  if (error.name === 'TimeoutError' || error.name === 'AbortError') return 'The site did not respond. Check its address and network connection.';

  return 'Could not reach this site. Check its network, address, and HTTPS certificate.';

}

export function parseCameras(data, siteId) {

  if (!Array.isArray(data)) throw new CameraError('Blue Iris returned an invalid camera list.');

  const cameras = new Map();

  for (const item of data) {

    if (!item || typeof item !== 'object') continue;

    const id = String(item.optionValue || '');

    const name = String(item.optionDisplay || id);

    if (!id || id === 'index' || name.startsWith('+') || item.group === true || item.group === 'true' || Array.isArray(item.group)) continue;

    cameras.set(id, { key: `${siteId}:${id}`, siteId, id, name, enabled: item.isEnabled !== false, online: item.isOnline===false||item.isNoSignal===true?false:item.isOnline===true||item.isNoSignal===false?true:null, fps:Number.isFinite(Number(item.FPS??item.fps))?Number(item.FPS??item.fps):null, motion: item.isMotion === true, recording:typeof item.isRecording==='boolean'?item.isRecording:null, ptz: item.ptz===true, audio: item.audio===true, width:Number(item.width)||0,height:Number(item.height)||0,subWidth:Number(item.width2)||0,subHeight:Number(item.height2)||0 });

  }

  return [...cameras.values()];

}

export async function limitedBody(response, limit = 4 * 1024 * 1024) {

  const parts = []; let size = 0;

  for await (const part of response.body) {

    size += part.length;

    if (size > limit) { await response.body.cancel?.().catch(() => {}); throw new CameraError('The server response exceeded the size limit.'); }

    parts.push(part);

  }

  return Buffer.concat(parts);

}



export class BlueIrisEndpoint {

  constructor(profile,{auth=new AuthenticationGuard()}={}) {this.auth=auth;this.profile=profile;this.base=normalizeUrl(profile.url);this.session=null;this.loginPromise=null;this.loginRetryAt=0;}

  async post(body, retry=true) {

    let response;

    for (let attempt = 0; attempt < 2; attempt++) {

      try {

        response = await fetch(`${this.base}/json`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': 'DarkstarCameraViewer/0.3', Connection: 'close' }, body: JSON.stringify(body), redirect: 'error', signal: AbortSignal.timeout(this.profile.timeout || 8000) });

        break;

      } catch (error) { if(attempt||!retry||(body.cmd==='login'&&body.response))throw error; await delay(250); }

    }

    if(!response.ok){await response.body?.cancel();if(body.cmd==='login'&&[401,403].includes(response.status)){const denied=this.auth.fail('login-http-rejected');await this.auth.pending;throw denied;}const error=new CameraError(`Blue Iris returned HTTP ${response.status}. Check web-server access.`,response.status>=500||response.status===404);error.httpStatus=response.status;throw error;}

    try { return JSON.parse((await limitedBody(response)).toString('utf8')); }

    catch (error) { if (error instanceof CameraError) throw error; throw new CameraError('This address did not return a Blue Iris response.',true); }

  }

  async token() {

    this.auth.assert();
    if(this.session)return this.session;
    if(this.auth.now()<this.loginRetryAt)throw new CameraError('Connection attempts are cooling down after a transport failure.',true);

    if (!this.loginPromise) this.loginPromise = (async () => {

      const challenge = await this.post({ cmd: 'login' });

      if (typeof challenge.session !== 'string' || !challenge.session) throw new CameraError('Blue Iris did not provide a login session.',true);

      const response = createHash('md5').update(`${this.profile.username}:${challenge.session}:${this.profile.password}`).digest('hex');

      let result;try{result=await this.post({cmd:'login',session:challenge.session,response},false)}catch(error){const blocked=this.auth.fail('login-outcome-unconfirmed');await this.auth.pending;throw blocked;}

      if(result.result!=='success'){const blocked=this.auth.fail('credentials-rejected');await this.auth.pending;throw blocked;}

      this.metadata=Object.fromEntries(['system','version','support','admin','changeprofile','profiles'].filter(key=>result.data?.[key]!==undefined).map(key=>[key,result.data[key]]));

      if (result.data?.license) this.identity = createHash('sha256').update(String(result.data.license)).digest('hex');

      return (this.session = challenge.session);

    })().catch(error=>{if(!error.authBlocked)this.loginRetryAt=this.auth.now()+30000;throw error;}).finally(()=>{this.loginPromise=null});

    return this.loginPromise;

  }

  async command(cmd, data = {}) {

    for (let attempt = 0; attempt < 2; attempt++) {

      const token = await this.token();

      const result = await this.post({ ...data, cmd, session: token });

      if (result.result === 'success') return result.data;

      if(cmd!=='camlist'||/permission|denied|not authorized|unsupported|unknown command/i.test(String(result.data?.reason||result.reason||'')))throw new CameraError('The request was rejected. Check camera permissions. No new login was attempted.');
      if(this.session===token){this.auth.renew();this.session=null;}

    }

    throw new CameraError('The request was rejected. Check camera permissions.');

  }

  async cameras() { return parseCameras(await this.command('camlist'), this.profile.id); }

  async control(cmd,data) {

    const result=await this.post({...data,cmd,session:await this.token()},false);

    if(result.result!=='success')throw new CameraError(`Blue Iris rejected ${cmd}. Check user permissions and camera support.`);

    return result.data;

  }

  async avMedia(id,signal,position=null,speed=100) {

    const path=position===null?`/video/${encodeURIComponent(id)}/2.0?`:`/time/${encodeURIComponent(id)}?pos=${Math.trunc(position)}&speed=${speed}&isolate=1&`;

    return this.binary(`${path}audio=1&codec=H.264&stream=0&w=1280&fps=15&extend=2`,signal);

  }

  async binary(path,signal) {

    const token=await this.token();

    const response=await fetch(`${this.base}${path}&session=${encodeURIComponent(token)}`,{headers:{Cookie:`Session=${token}`,'User-Agent':'DarkstarCameraViewer/0.5.1'},redirect:'error',signal});

    if(!response.ok||!/^video\/|octet-stream/i.test(response.headers.get('content-type')||'')){await response.body?.cancel();throw new CameraError('Blue Iris did not return the requested media. Check its recording/export permissions.')}

    return response;

  }

  async exportStatus(path) {const queue=await this.command('export');if(!Array.isArray(queue))throw new CameraError('Invalid export queue response.');return queue.find(row=>row.path===path)||{status:'done'};}

  downloadExport(uri,signal) {

    if(typeof uri!=='string'||!uri||uri.includes(':')||uri.split(/[\\/]/).some(s=>s==='.'||s==='..'))throw new CameraError('Invalid export download path.');

    const path=uri.replaceAll('\\','/').replace(/^\/+/, '').split('/').map(s=>encodeURIComponent(s).replaceAll('%40','@')).join('/');

    return this.binary(`/clips/${path}?dl=1`,signal);

  }

  async recordings(cameraId, start, end) {

    const params = { camera: cameraId, startdate: Math.floor((start - 86400000) / 1000), enddate: Math.floor(end / 1000), tiles: false };

    const data = await this.command('cliplist', params);

    let alerts, eventsAvailable = true;

    try { alerts = await this.command('alertlist', params); } catch { alerts = []; eventsAvailable = false; }

    return { recordings: parseRecordings(data, cameraId).filter(clip => clip.end > start && clip.start < end), events: parseEvents(alerts).filter(event => event.start >= start && event.start < end), eventsAvailable };

  }

  async media(cameraId, streaming, signal, playback = null, previewSub = false) {

    for (let attempt = 0; attempt < 2; attempt++) {

      const token = await this.token();

      const path = playback ? `/time/${encodeURIComponent(cameraId)}?mode=${streaming ? 'mjpg' : 'jpeg&jpeg=1'}&pos=${Math.trunc(playback.position)}&speed=${playback.speed || 100}&isolate=1&w=1280&fps=10&q=65` : streaming ? `/mjpg/${encodeURIComponent(cameraId)}/video.mjpg?fps=6&q=55&w=960` : `/image/${encodeURIComponent(cameraId)}?q=60&w=640${previewSub?'&decode=-1':''}`;

      const response = await fetch(`${this.base}${path}&session=${encodeURIComponent(token)}`, { headers: { Cookie: `Session=${token}`, 'User-Agent': 'DarkstarCameraViewer/0.1' }, redirect: 'error', signal: streaming ? signal : AbortSignal.any([signal, AbortSignal.timeout(8000)]) });

      const type = response.headers.get('content-type') || '';

      if (response.ok && (streaming ? /multipart\//i.test(type) || (playback && (!type || /octet-stream/i.test(type))) : /image\/jpeg/i.test(type) || (playback && (!type || /octet-stream|multipart\//i.test(type))))) return response;

      await response.body?.cancel();

      if(attempt===0&&response.status===401){if(this.session===token){this.auth.renew();this.session=null;}}

      else {const error=new CameraError(`Video unavailable (HTTP ${response.status}). Check this camera's stream and permissions.`,response.status>=500||response.status===404);error.httpStatus=response.status;throw error;}

    }

    throw new CameraError('Video authentication failed.');

  }

  async snapshot(id, signal = new AbortController().signal) {

    this.mainPreview??=new Set();

    if(this.mainPreview.has(id))return limitedBody(await this.media(id,false,signal));

    try{return await limitedBody(await this.media(id,false,signal,null,true))}catch(error){

      if(![400,404,422].includes(error.httpStatus))throw error;

      const image=await limitedBody(await this.media(id,false,signal));this.mainPreview.add(id);return image;

    }

  }

  async recordedFrame(id, position, signal) {

    const response = await this.media(id, false, signal, { position, speed: 100 });

    let frame;

    const parser = new JpegParser(value => { frame ||= Buffer.from(value); });

    for await (const chunk of response.body) { parser.push(chunk); if (frame) return frame; }

    throw new CameraError('No recorded image was available at this time.');

  }

  async logout() { if (this.session) { try { await this.command('logout'); } finally { this.session = null; } } }

}



export class BlueIrisClient {

  constructor(profile,{endpointFactory=(value,options)=>new BlueIrisEndpoint(value,options),now=Date.now,auth=new AuthenticationGuard({now})}={}) {

    this.auth=auth;this.profile=profile;this.now=now;this.routes=[];this.active=null;this.failed=null;this.preferLocal=true;this.probeAt=0;this.generation=0;

    if(profile.url) this.routes.push({local:true,endpoint:endpointFactory({...profile,timeout:profile.wanUrl?1500:8000},{auth})});

    if(profile.wanUrl && (!profile.url || normalizeUrl(profile.wanUrl)!==normalizeUrl(profile.url)))this.routes.push({local:false,endpoint:endpointFactory({...profile,url:profile.wanUrl},{auth})});

    if(!this.routes.length)throw new CameraError('Enter a local or WAN server address.');

  }

  get connectionLabel(){return this.active?(this.active.local?'Local':'WAN'):'Auto'}

  networkChanged(preferLocal=true){this.preferLocal=preferLocal;this.active=null;this.failed=null;this.probeAt=0;this.generation++}

  async request(action, signal) {
    this.auth.assert();

    const generation=this.generation, retryLocal=this.preferLocal&&this.active?.local===false&&this.now()-this.probeAt>=60000;

    let routes=this.active&&!retryLocal?[this.active,...this.routes.filter(r=>r!==this.active)]:[...this.routes].sort((a,b)=>Number(b.local===this.preferLocal)-Number(a.local===this.preferLocal));

    if(retryLocal||(!this.active&&this.preferLocal))this.probeAt=this.now();

    if(this.failed)routes.sort((a,b)=>Number(a===this.failed)-Number(b===this.failed));

    let failure;

    for(const route of routes){

      if(signal?.aborted)throw signal.reason;

      try {

        await route.endpoint.token();

        const identity=route.endpoint.identity;

        if(this.identity&&identity&&identity!==this.identity)throw new CameraError('The alternate address belongs to a different Blue Iris server. Check local and WAN settings.');

        if(identity)this.identity=identity;

        const value=await action(route.endpoint);

        if(generation===this.generation){this.active=route;this.failed=null}

        return value;

      }catch(error){

        if(signal?.aborted || (error instanceof CameraError&&!error.allowRouteFallback))throw error;

        failure=error;if(this.active===route)this.active=null;

      }

    }

    throw failure||new CameraError('No server address is available.');

  }

  // These diagnostic entry points retain the protocol test surface.

  post(body){return this.routes[0].endpoint.post(body)}

  token(){return this.request(endpoint=>endpoint.token())}

  cameras(){return this.request(endpoint=>endpoint.cameras())}

  health(){return this.request(async endpoint=>({status:await endpoint.command('status'),metadata:endpoint.metadata||{}}))}

  recentAlerts(start,end){return this.request(endpoint=>endpoint.command('alertlist',{camera:'index',startdate:Math.floor(start/1000),enddate:Math.floor(end/1000),tiles:false}))}

  async administer(action,args){const endpoint=await this.controlEndpoint();

    if(action==='rename-camera')return endpoint.control('camconfig',{camera:args.camera,rename:args.rename});

    if(action==='reset-camera')return endpoint.control('camconfig',{camera:args.camera,reset:true});

    const status={profile:'profile',shield:'signal','install-update':'update','reboot-host':'reboot'},settings={archive:'archive',schedule:'schedule','manual-record-limit':'manrecsec'};

    if(status[action])return endpoint.control('status',{[status[action]]:args[status[action]]});

    if(settings[action])return endpoint.control('sysconfig',{[settings[action]]:args[settings[action]]});

    throw new CameraError('Unsupported administrative command.');

  }

  recordings(...args){return this.request(endpoint=>endpoint.recordings(...args))}

  snapshot(id,signal){return this.request(endpoint=>endpoint.snapshot(id,signal),signal)}

  recordedFrame(id,position,signal){return this.request(endpoint=>endpoint.recordedFrame(id,position,signal),signal)}

  avMedia(id,signal,position=null,speed=100){return this.request(endpoint=>endpoint.avMedia(id,signal,position,speed),signal)}

  async controlEndpoint(){if(!this.active)await this.cameras();if(!this.active)throw new CameraError('Connect to the site before sending commands.');return this.active.endpoint}

  async ptz(id,button){if(![0,1,2,3,4,5,6,64].includes(button))throw new CameraError('Invalid PTZ command.');return (await this.controlEndpoint()).control('ptz',{camera:id,button})}

  async exportConnection(){const endpoint=await this.controlEndpoint();return {queue:params=>endpoint.control('export',params),status:path=>endpoint.exportStatus(path),download:(uri,signal)=>endpoint.downloadExport(uri,signal)}}

  async media(id,streaming,signal,playback){

    let selected;

    const response=await this.request(endpoint=>{selected=this.routes.find(route=>route.endpoint===endpoint);return endpoint.media(id,streaming,signal,playback)},signal);

    if(!streaming)return response;

    const client=this;

    return {body:{cancel:reason=>response.body.cancel(reason),async *[Symbol.asyncIterator](){try{for await(const chunk of response.body)yield chunk;if(!signal.aborted){client.failed=selected;if(client.active===selected)client.active=null}}catch(error){if(!signal.aborted){client.failed=selected;if(client.active===selected)client.active=null}throw error}}}};

  }

  async logout(){await Promise.all(this.routes.map(route=>route.endpoint.logout().catch(()=>{})));this.active=null}

}



export class JpegParser {

  constructor(onFrame, limit = 4 * 1024 * 1024) { this.buffer = Buffer.alloc(0); this.onFrame = onFrame; this.limit = limit; }

  push(chunk) {

    this.buffer = Buffer.concat([this.buffer, chunk]);

    while (true) {

      const start = this.buffer.indexOf(Buffer.from([255, 216]));

      if (start < 0) {

        if (this.buffer.length > 65536) throw new CameraError('Invalid MJPEG stream header.');

        return;

      }

      if (start > 0) this.buffer = this.buffer.subarray(start);

      const end = this.buffer.indexOf(Buffer.from([255, 217]), 2);

      if (end < 0) { if (this.buffer.length > this.limit) throw new CameraError('Video frame exceeded the size limit.'); return; }

      if (end + 2 > this.limit) throw new CameraError('Video frame exceeded the size limit.');

      this.onFrame(this.buffer.subarray(0, end + 2));

      this.buffer = this.buffer.subarray(end + 2);

    }

  }

}

